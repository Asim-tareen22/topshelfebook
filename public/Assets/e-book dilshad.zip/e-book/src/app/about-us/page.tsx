'use client';

import { motion, useScroll, useTransform } from 'framer-motion';
import { useInView } from 'framer-motion';
import React, { useRef } from 'react';
import Link from 'next/link';
import {
  Sparkles,
  BookOpen,
  Users,
  Award,
  TrendingUp,
  CheckCircle,
  Star,
  Globe,
  Pen,
  Zap,
  Heart,
  Rocket,
  Crown,
  ChevronRight,
  PlayCircle,
  Mic,
  Palette,
  Monitor,
  Share2,
  Languages,
  BarChart,
  ShoppingCart
} from 'lucide-react';

export default function AboutPage() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <div className="bg-white overflow-hidden">
      
      {/* ============================================
          HERO SECTION - Who We Are
      ============================================ */}
      <motion.section
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-white via-red-50 to-white"
      >
        {/* Animated Background Elements */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{ duration: 20, repeat: Infinity }}
          className="absolute top-20 right-20 w-96 h-96 bg-maroon-500/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [90, 0, 90],
          }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute bottom-20 left-20 w-80 h-80 bg-red-600/10 rounded-full blur-3xl"
        />

        {/* Floating Particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            animate={{
              y: [0, -30, 0],
              x: [0, Math.random() * 20 - 10, 0],
              opacity: [0.3, 1, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
            className="absolute w-2 h-2 bg-red-800 rounded-full"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
          />
        ))}

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 bg-gradient-to-r from-red-800 to-red-900 text-white px-6 py-3 rounded-full mb-6"
              >
                <Crown className="w-5 h-5" />
                <span className="font-bold">Who We Are</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-5xl lg:text-7xl font-black mb-6 leading-tight"
              >
                <span className="bg-gradient-to-r from-red-800 via-red-900 to-red-800 bg-clip-text text-transparent">
                  Skilled Top Shelf
                </span>
                <br />
                <span className="text-gray-900">Ebook to Ensure</span>
                <br />
                <motion.span
                  animate={{
                    backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                  className="bg-gradient-to-r from-red-600 via-red-800 to-red-600 bg-clip-text text-transparent bg-[length:200%_auto]"
                >
                  Perfection In Every Page
                </motion.span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-gray-600 text-lg lg:text-xl mb-8 leading-relaxed"
              >
                Our team comprises imaginative minds who can spare you the need to pick up a pen, as you're just one idea away from becoming an impactful author. Our ghostwriters help individuals with their literature, give life to biographies, and craft captivating fictional characters.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                className="flex flex-wrap gap-4"
              >
                <Link href="/contact-us">
                  <motion.button
                    whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(153, 27, 27, 0.3)' }}
                    whileTap={{ scale: 0.95 }}
                    className="group relative px-8 py-4 bg-gradient-to-r from-red-800 to-red-900 text-white font-bold rounded-full overflow-hidden"
                  >
                    <motion.div
                      animate={{ x: ['-200%', '200%'] }}
                      transition={{ duration: 3, repeat: Infinity, repeatDelay: 1 }}
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
                    />
                    <span className="relative z-10 flex items-center gap-2">
                      Get Started <Rocket className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </motion.button>
                </Link>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 border-2 border-red-800 text-red-800 font-bold rounded-full hover:bg-red-800 hover:text-white transition-all"
                >
                  <span className="flex items-center gap-2">
                    Live Chat <Zap className="w-5 h-5" />
                  </span>
                </motion.button>
              </motion.div>
            </motion.div>

            {/* Right - Animated Book Illustration */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="relative"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
                className="absolute inset-0 bg-gradient-to-r from-red-800/20 to-red-900/20 rounded-full blur-3xl"
              />
              
              <motion.div
                animate={{ y: [0, -20, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="relative bg-white rounded-3xl shadow-2xl p-12"
              >
                <div className="grid grid-cols-2 gap-6">
                  {[
                    { icon: BookOpen, label: 'Stories', color: 'from-red-600 to-red-800' },
                    { icon: Pen, label: 'Writing', color: 'from-red-700 to-red-900' },
                    { icon: Heart, label: 'Passion', color: 'from-red-800 to-red-950' },
                    { icon: Star, label: 'Quality', color: 'from-red-600 to-red-900' },
                  ].map((item, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.8 + i * 0.1 }}
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      className={`bg-gradient-to-br ${item.color} p-6 rounded-2xl text-white text-center`}
                    >
                      <item.icon className="w-12 h-12 mx-auto mb-3" />
                      <p className="font-bold">{item.label}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <div className="w-6 h-10 border-2 border-red-800 rounded-full flex justify-center pt-2">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1.5 h-1.5 bg-red-800 rounded-full"
            />
          </div>
        </motion.div>
      </motion.section>

      {/* ============================================
          HOW WE MAKE CONTENT SHINE
      ============================================ */}
      <Section>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="A Glimpse Of Our Brilliance"
            title="How We Make Your Content Shine!"
            subtitle="From creating sentences that keep you hooked to spinning plots with unexpected twists, our content is designed to grab attention and keep you engaged."
          />

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="bg-gradient-to-br from-red-800 to-red-900 rounded-3xl p-8 lg:p-16 text-white relative overflow-hidden"
          >
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff10_1px,transparent_1px),linear-gradient(to_bottom,#ffffff10_1px,transparent_1px)] bg-[size:40px_40px]" />
            </div>

            <motion.div
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.3, 0.6, 0.3],
              }}
              transition={{ duration: 8, repeat: Infinity }}
              className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"
            />

            <div className="relative z-10 grid lg:grid-cols-3 gap-8">
              {[
                { icon: Sparkles, title: 'Expert Writers', desc: 'Among the finest in the industry' },
                { icon: CheckCircle, title: 'Quality Assured', desc: 'Detailed editing services included' },
                { icon: TrendingUp, title: 'Affordable Pricing', desc: 'Competitive rates in the market' },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  whileHover={{ y: -10, scale: 1.05 }}
                  className="text-center"
                >
                  <motion.div
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                    className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-xl rounded-2xl mb-4"
                  >
                    <item.icon className="w-10 h-10" />
                  </motion.div>
                  <h3 className="text-2xl font-bold mb-2">{item.title}</h3>
                  <p className="text-white/80">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </Section>

      {/* ============================================
          ACHIEVEMENTS - STATS
      ============================================ */}
      <Section className="bg-gradient-to-b from-white to-red-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Our Achievement"
            title="Here's What Makes Us Different"
            subtitle="Our success is attributed to our exceptional team of professionals, who are among the finest in the industry."
          />

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { number: '12+', label: 'Years of Experience', icon: Award },
              { number: '18000+', label: 'Books Written', icon: BookOpen },
              { number: '450+', label: 'Books Internationally Acclaimed', icon: Globe },
              { number: '750+', label: 'Native Writers', icon: Users },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, type: 'spring' }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="relative group"
              >
                <motion.div
                  animate={{
                    boxShadow: [
                      '0 0 0 0 rgba(153, 27, 27, 0)',
                      '0 0 0 20px rgba(153, 27, 27, 0)',
                    ],
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="bg-white rounded-2xl p-8 text-center border-2 border-red-100 group-hover:border-red-800 transition-all"
                >
                  <motion.div
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                    className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-red-800 to-red-900 text-white rounded-xl mb-4"
                  >
                    <stat.icon className="w-8 h-8" />
                  </motion.div>

                  <motion.h3
                    initial={{ scale: 1 }}
                    whileInView={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.5 }}
                    className="text-5xl font-black bg-gradient-to-r from-red-800 to-red-900 bg-clip-text text-transparent mb-2"
                  >
                    {stat.number}
                  </motion.h3>
                  <p className="text-gray-600 font-semibold">{stat.label}</p>

                  {/* Animated Border */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl border-2 border-red-800 opacity-0 group-hover:opacity-100"
                    animate={{
                      scale: [1, 1.05, 1],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ============================================
          BOOK COLLECTION - CATEGORIES
      ============================================ */}
      <Section>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Our Book Collection"
            title="Seize the Power of Words with TopShelf Ebook Squad"
            subtitle="Whether it's a tale of enduring challenges, a tribute to unrequited love, an exploration of distant galaxies, or a harrowing account of abuse, everyone longs to have their stories shared."
          />

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {[
              { name: 'Science', gradient: 'from-blue-600 to-blue-800', icon: '🔬' },
              { name: 'Children', gradient: 'from-yellow-500 to-orange-600', icon: '🎨' },
              { name: 'Fiction', gradient: 'from-purple-600 to-purple-800', icon: '📖' },
              { name: 'Non-Fiction', gradient: 'from-green-600 to-green-800', icon: '📚' },
              { name: 'Romance', gradient: 'from-pink-600 to-red-600', icon: '💖' },
            ].map((category, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -15, scale: 1.05 }}
                className="group cursor-pointer"
              >
                <div className={`relative bg-gradient-to-br ${category.gradient} rounded-2xl p-8 h-64 flex flex-col items-center justify-center text-white overflow-hidden`}>
                  {/* Background Animation */}
                  <motion.div
                    animate={{
                      scale: [1, 1.5, 1],
                      rotate: [0, 180, 360],
                    }}
                    transition={{ duration: 20, repeat: Infinity }}
                    className="absolute inset-0 bg-white/10 rounded-full blur-2xl"
                  />

                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    transition={{ delay: i * 0.1 + 0.3, type: 'spring' }}
                    className="text-6xl mb-4 relative z-10"
                  >
                    {category.icon}
                  </motion.div>

                  <h3 className="text-2xl font-black relative z-10">{category.name}</h3>

                  {/* Hover Effect */}
                  <motion.div
                    initial={{ scaleY: 0 }}
                    whileHover={{ scaleY: 1 }}
                    className="absolute inset-0 bg-black/20 origin-bottom"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ============================================
          CTA BANNER
      ============================================ */}
      <Section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative bg-gradient-to-r from-red-800 via-red-900 to-red-800 rounded-3xl p-12 lg:p-20 text-center text-white overflow-hidden"
          >
            {/* Animated Background */}
            <motion.div
              animate={{
                backgroundPosition: ['0% 0%', '100% 100%', '0% 0%'],
              }}
              transition={{ duration: 10, repeat: Infinity }}
              className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1),transparent)] opacity-50"
            />

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-4xl lg:text-5xl font-black mb-6 relative z-10"
            >
              We Enhance Your Online Presence To Help You Stand Out From The Crowd!
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl mb-8 text-white/90 relative z-10"
            >
              Don't wait any longer to talk about your content requirements with our friendly team. We're here round the clock to listen!
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-wrap gap-4 justify-center relative z-10"
            >
              <Link href="/contact-us">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-10 py-5 bg-white text-red-900 font-black rounded-full text-lg shadow-2xl"
                >
                  Get Started
                </motion.button>
              </Link>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 border-2 border-white text-white font-black rounded-full text-lg"
              >
                Live Chat
              </motion.button>
            </motion.div>
          </motion.div>
        </div>
      </Section>

      {/* ============================================
          HOW WE WORK - PROCESS
      ============================================ */}
      <Section className="bg-gradient-to-b from-white to-red-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="How We Work"
            title="The Top Shelf Ebook Process for Your Global Success"
          />

          <div className="relative">
            {/* Connecting Line */}
            <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-red-200 via-red-800 to-red-200 -translate-y-1/2" />

            <div className="grid lg:grid-cols-4 gap-8 relative">
              {[
                {
                  step: '01',
                  title: 'Your Brief',
                  desc: 'Share your vision using our questionnaire. Our representative will discuss your ideas to ensure we capture your vision.',
                  icon: Pen,
                },
                {
                  step: '02',
                  title: 'The Initial Outline',
                  desc: 'Once we understand your vision, we\'ll craft an initial outline for your approval. This step ensures we\'re aligned before proceeding further.',
                  icon: BookOpen,
                },
                {
                  step: '03',
                  title: 'Writing & Refinement',
                  desc: 'Our skilled ghostwriters will bring your vision to life in the form of a draft. We\'ll share this draft with you for feedback and make any necessary changes.',
                  icon: Sparkles,
                },
                {
                  step: '04',
                  title: 'Polishing & Publication',
                  desc: 'Our expert editing team will refine your draft to give it a polished finish. Then, we\'ll handle the formatting, design, and publishing of your book.',
                  icon: Rocket,
                },
              ].map((process, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  className="relative"
                >
                  <motion.div
                    whileHover={{ y: -10 }}
                    className="bg-white rounded-2xl p-8 shadow-xl border-2 border-red-100 hover:border-red-800 transition-all relative z-10"
                  >
                    {/* Step Number */}
                    <motion.div
                      initial={{ scale: 0 }}
                      whileInView={{ scale: 1 }}
                      transition={{ delay: i * 0.2 + 0.3, type: 'spring' }}
                      className="absolute -top-6 -right-6 w-16 h-16 bg-gradient-to-br from-red-800 to-red-900 text-white font-black text-2xl rounded-full flex items-center justify-center shadow-xl"
                    >
                      {process.step}
                    </motion.div>

                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-red-100 to-red-200 rounded-xl mb-4"
                    >
                      <process.icon className="w-8 h-8 text-red-800" />
                    </motion.div>

                    <h3 className="text-2xl font-black text-gray-900 mb-3">{process.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{process.desc}</p>
                  </motion.div>

                  {/* Connector Dot */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    transition={{ delay: i * 0.2 + 0.5 }}
                    className="hidden lg:block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 bg-red-800 rounded-full border-4 border-white shadow-lg z-20"
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* ============================================
          SERVICES GRID
      ============================================ */}
      <Section>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Comprehensive Ghostwriting Agency"
            title="Captivating Ghostwriting, Editing, and Publishing Services"
            subtitle="At Ghostwriting Squad, we're all about bringing your ideas to life with a dash of creativity and skill."
          />

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { name: 'Video Trailer', icon: PlayCircle, color: 'from-red-600 to-red-800' },
              { name: 'Audio Book', icon: Mic, color: 'from-red-700 to-red-900' },
              { name: 'Book Cover Designing', icon: Palette, color: 'from-red-800 to-red-950' },
              { name: 'Author Website', icon: Monitor, color: 'from-red-600 to-red-900' },
              { name: 'Book Publishing', icon: BookOpen, color: 'from-red-700 to-red-800' },
              { name: 'Social Media Marketing', icon: Share2, color: 'from-red-800 to-red-900' },
              { name: 'Book Translation', icon: Languages, color: 'from-red-600 to-red-800' },
              { name: 'Marketing Consultation', icon: BarChart, color: 'from-red-700 to-red-950' },
              { name: 'Amazon Marketing', icon: ShoppingCart, color: 'from-red-800 to-red-900' },
            ].map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="group cursor-pointer"
              >
                <div className={`relative bg-gradient-to-br ${service.color} rounded-2xl p-6 text-white overflow-hidden`}>
                  {/* Background Animation */}
                  <motion.div
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.2, 0.4, 0.2],
                    }}
                    transition={{ duration: 5, repeat: Infinity }}
                    className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full blur-3xl"
                  />

                  <div className="relative z-10 flex items-center gap-4">
                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className="flex-shrink-0 w-14 h-14 bg-white/20 backdrop-blur-xl rounded-xl flex items-center justify-center"
                    >
                      <service.icon className="w-7 h-7" />
                    </motion.div>
                    <h3 className="font-bold text-lg">{service.name}</h3>
                  </div>

                  {/* Hover Arrow */}
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    whileHover={{ x: 0, opacity: 1 }}
                    className="absolute bottom-4 right-4"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ============================================
          TESTIMONIALS
      ============================================ */}
      <Section className="bg-gradient-to-b from-red-50 to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="Client Success Stories"
            title="What Our Authors Say"
          />

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                name: 'Ava L',
                role: 'First-Time Author',
                review: 'I had a story in my heart for years, but no clue how to turn it into a book. This team made it real — from draft to publication, they handled everything like pros!',
                rating: 5,
              },
              {
                name: 'James',
                role: 'Entrepreneur & Author',
                review: 'Their ghostwriting and editing services exceeded all expectations. The final eBook was clean, compelling, and exactly how I envisioned it — maybe even better!',
                rating: 5,
              },
              {
                name: 'Rina',
                role: 'Motivational Speaker',
                review: 'From formatting to publishing, they took care of it all. I just focused on my ideas while they did the heavy lifting. The process was seamless and stress-free.',
                rating: 5,
              },
            ].map((testimonial, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="bg-white rounded-2xl p-8 shadow-xl border-2 border-red-100 hover:border-red-800 transition-all"
              >
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.2 + index * 0.1 }}
                    >
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    </motion.div>
                  ))}
                </div>

                <p className="text-gray-700 mb-6 italic leading-relaxed">"{testimonial.review}"</p>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-red-800 to-red-900 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ============================================
          FAQ SECTION
      ============================================ */}
      <FAQSection />

      {/* ============================================
          FINAL CTA
      ============================================ */}
      <Section className="py-32 bg-gradient-to-br from-red-900 via-red-800 to-red-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl lg:text-6xl font-black mb-6">
              Ready to Start Your Journey?
            </h2>
            <p className="text-xl text-white/90 mb-12 max-w-3xl mx-auto">
              Let Our Experts Bring Your Valuable Thoughts to Life and Make You the Next Best-Seller!
            </p>

            <motion.button
              whileHover={{ scale: 1.1, boxShadow: '0 30px 60px rgba(0,0,0,0.3)' }}
              whileTap={{ scale: 0.95 }}
              className="px-12 py-6 bg-white text-red-900 font-black text-xl rounded-full shadow-2xl"
            >
              <Link href="/contact-us">
                Let's Get Started! 🚀
              </Link>
            </motion.button>
          </motion.div>
        </div>
      </Section>
    </div>
  );
}

// ============================================
// REUSABLE COMPONENTS
// ============================================

function Section({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <section className={`py-20 lg:py-32 relative ${className}`}>
      {children}
    </section>
  );
}

function SectionHeader({ badge, title, subtitle }: { badge: string; title: string; subtitle?: string }) {
  return (
    <div className="text-center mb-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="inline-flex items-center gap-2 bg-gradient-to-r from-red-800 to-red-900 text-white px-6 py-3 rounded-full mb-6"
      >
        <Sparkles className="w-5 h-5" />
        <span className="font-bold">{badge}</span>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.2 }}
        className="text-4xl lg:text-6xl font-black text-gray-900 mb-6"
      >
        {title}
      </motion.h2>

      {subtitle && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="text-xl text-gray-600 max-w-4xl mx-auto"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}

function FAQSection() {
  const faqs = [
    {
      q: 'What makes Top Shelf eBook different from other writing services?',
      a: 'At Top Shelf eBook, we offer an all-inclusive, premium experience — from ghostwriting and editing to publishing and promotion. Our team is dedicated to quality, confidentiality, and creating eBooks that stand out in both content and presentation.',
    },
    {
      q: 'Can I hire you even if I\'m not a writer?',
      a: 'Absolutely! That\'s exactly what we\'re here for. Our expert ghostwriters will transform your ideas into a professionally written book.',
    },
    {
      q: 'How much input do I have during the process?',
      a: 'You have complete control. We collaborate with you at every stage, ensuring your vision is perfectly captured.',
    },
    {
      q: 'Will my eBook be ready for Amazon and other major platforms?',
      a: 'Yes! We format and prepare your eBook for all major platforms including Amazon Kindle, Apple Books, and more.',
    },
    {
      q: 'Is everything I share kept confidential?',
      a: 'Absolutely. We sign NDAs and maintain strict confidentiality throughout the entire process.',
    },
  ];

  const [openIndex, setOpenIndex] = React.useState<number | null>(null);

  return (
    <Section>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <SectionHeader
          badge="Frequently Asked Questions"
          title="Explore the ins and outs of hiring a ghostwriter for your book"
        />

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-white rounded-2xl border-2 border-red-100 overflow-hidden"
            >
              <motion.button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                whileHover={{ backgroundColor: 'rgba(153, 27, 27, 0.05)' }}
                className="w-full p-6 text-left flex items-center justify-between gap-4"
              >
                <span className="font-bold text-lg text-gray-900">{faq.q}</span>
                <motion.div
                  animate={{ rotate: openIndex === i ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronRight className="w-6 h-6 text-red-800 rotate-90" />
                </motion.div>
              </motion.button>

              <motion.div
                initial={false}
                animate={{
                  height: openIndex === i ? 'auto' : 0,
                  opacity: openIndex === i ? 1 : 0,
                }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-6 pb-6 text-gray-600 leading-relaxed">
                  {faq.a}
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}