'use client';

import React from "react";
import { motion } from "framer-motion";
import { MacbookScroll } from "@/components/ui/macbook-scroll";
import { BookOpen, Sparkles, Star, Zap, Book } from "lucide-react";

export function BookShelfSection() {
  return (
    <section className="relative h-screen overflow-hidden flex items-center" style={{ backgroundColor: '#FFFAE8' }}>
      
      {/* Animated Floating Books */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          animate={{
            y: [0, -30, 0],
            x: [0, Math.random() * 20 - 10, 0],
            rotate: [0, Math.random() * 10 - 5, 0],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 4 + Math.random() * 3,
            repeat: Infinity,
            delay: i * 0.5,
          }}
          style={{
            position: 'absolute',
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          className="pointer-events-none"
        >
          <Book className="w-8 h-8 text-red-900/10" />
        </motion.div>
      ))}

      {/* Animated Background Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          animate={{
            y: [0, -100, 0],
            opacity: [0, 1, 0],
            scale: [0, 1.5, 0],
          }}
          transition={{
            duration: 5 + Math.random() * 5,
            repeat: Infinity,
            delay: i * 0.3,
          }}
          style={{
            position: 'absolute',
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          className="w-2 h-2 bg-red-900/20 rounded-full pointer-events-none"
        />
      ))}

      {/* Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.3, 0.5, 0.3],
          x: [0, 100, 0],
        }}
        transition={{ duration: 15, repeat: Infinity }}
        className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-r from-red-200/40 to-orange-200/40 rounded-full blur-3xl pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1.3, 1, 1.3],
          opacity: [0.4, 0.6, 0.4],
          x: [0, -100, 0],
        }}
        transition={{ duration: 18, repeat: Infinity }}
        className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-yellow-200/40 to-red-200/40 rounded-full blur-3xl pointer-events-none"
      />

      {/* Main Content - Vertically Centered */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Side - Content */}
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, type: "spring" }}
            className="space-y-8 lg:pr-8 z-10"
          >
            {/* Animated Badge */}
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              whileInView={{ scale: 1, rotate: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, type: 'spring', damping: 10 }}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-red-900/80 to-red-950/80 border-2 border-red-800/60 shadow-xl"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="w-5 h-5 text-yellow-300" />
              </motion.div>
              <span className="text-white font-black text-sm tracking-wide">
                DIGITAL LIBRARY
              </span>
            </motion.div>

            {/* Main Heading with Glitch Effect */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              <motion.h1
                whileHover={{ scale: 1.02 }}
                className="text-5xl sm:text-6xl lg:text-7xl font-black leading-tight"
              >
                <span className="text-gray-900">Your Gateway to </span>
                <motion.span
                  animate={{
                    backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                  className="bg-gradient-to-r from-red-800 via-red-600 to-red-900 bg-clip-text text-transparent bg-[length:200%_auto]"
                >
                  Endless Knowledge
                </motion.span>
              </motion.h1>
            </motion.div>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-gray-700 text-lg lg:text-xl leading-relaxed"
            >
              Discover thousands of premium ebooks across all genres. From bestselling fiction to cutting-edge technology, your next favorite read is just a click away.
            </motion.p>

            {/* Animated Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="grid grid-cols-3 gap-6"
            >
              {[
                { icon: BookOpen, value: '1000+', label: 'Books', color: 'from-red-500 to-red-700' },
                { icon: Star, value: '4.9', label: 'Rating', color: 'from-yellow-500 to-orange-600' },
                { icon: Zap, value: '24/7', label: 'Access', color: 'from-blue-500 to-purple-600' }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.7 + index * 0.1, type: 'spring', damping: 10 }}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="text-center lg:text-left bg-white/60 backdrop-blur-sm rounded-2xl p-4 shadow-lg border border-gray-200"
                >
                  <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                      className={`bg-gradient-to-r ${stat.color} p-2 rounded-lg`}
                    >
                      <stat.icon className="w-5 h-5 text-white" fill={stat.label === 'Rating' ? 'white' : 'none'} />
                    </motion.div>
                    <h3 className="text-3xl font-black text-gray-900">{stat.value}</h3>
                  </div>
                  <p className="text-gray-600 text-sm font-semibold">{stat.label}</p>
                </motion.div>
              ))}
            </motion.div>

            {/* Animated Features List */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="space-y-4"
            >
              {[
                'Instant digital downloads',
                'Multi-device sync support',
                'Regular new releases',
                'Exclusive member discounts'
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.9 + index * 0.1 }}
                  whileHover={{ x: 10 }}
                  className="flex items-center gap-3 group cursor-pointer"
                >
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: 360 }}
                    transition={{ type: 'spring', stiffness: 300 }}
                    className="w-8 h-8 rounded-full bg-gradient-to-r from-red-900 to-red-950 flex items-center justify-center flex-shrink-0 shadow-lg"
                  >
                    <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </motion.div>
                  <span className="text-gray-800 text-lg font-semibold group-hover:text-red-900 transition-colors">{feature}</span>
                </motion.div>
              ))}
            </motion.div>

            {/* Animated CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 1, duration: 0.8 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(127, 29, 29, 0.4)" }}
                whileTap={{ scale: 0.95 }}
                animate={{
                  boxShadow: [
                    "0 10px 30px rgba(127, 29, 29, 0.3)",
                    "0 15px 40px rgba(127, 29, 29, 0.5)",
                    "0 10px 30px rgba(127, 29, 29, 0.3)",
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity }}
                className="px-10 py-5 bg-gradient-to-r from-red-900 to-red-950 text-white font-black text-lg rounded-2xl shadow-xl relative overflow-hidden group"
              >
                <motion.div
                  animate={{ x: ['-100%', '200%'] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
                />
                <span className="relative z-10">Browse Library</span>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05, backgroundColor: "rgba(255, 255, 255, 0.9)" }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 bg-white/60 backdrop-blur-sm text-gray-900 font-black text-lg rounded-2xl border-2 border-gray-900/20 shadow-xl hover:border-red-900 transition-all"
              >
                Learn More
              </motion.button>
            </motion.div>
          </motion.div>

          {/* Right Side - MacbookScroll - Vertically Centered with Top Padding */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotateY: -30 }}
            whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, type: "spring", damping: 15 }}
            className="relative z-10 flex items-center justify-center pt-[500px]"
          >
            {/* Glow Effect Behind Laptop */}
            <motion.div
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.5, 0.8, 0.5],
              }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute inset-0 bg-gradient-to-r from-red-400/30 via-yellow-400/30 to-orange-400/30 blur-3xl rounded-full"
            />
            
            <div className="scale-75 lg:scale-100">
              <MacbookScroll
                src={`/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg`}
                showGradient={false}
              />
            </div>
          </motion.div>

        </div>
      </div>

      {/* Bottom Decorative Wave */}
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
        <svg viewBox="0 0 1440 120" className="w-full h-24 fill-red-900/5">
          <motion.path
            animate={{
              d: [
                "M0,64L48,69.3C96,75,192,85,288,80C384,75,480,53,576,48C672,43,768,53,864,58.7C960,64,1056,64,1152,58.7C1248,53,1344,43,1392,37.3L1440,32L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z",
                "M0,32L48,37.3C96,43,192,53,288,58.7C384,64,480,64,576,58.7C672,53,768,43,864,48C960,53,1056,75,1152,80C1248,85,1344,75,1392,69.3L1440,64L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z",
              ]
            }}
            transition={{ duration: 4, repeat: Infinity, repeatType: "reverse" }}
          />
        </svg>
      </div>

    </section>
  );
}