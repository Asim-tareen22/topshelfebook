'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import Link from 'next/link';
import { 
  BookOpen, 
  Home, 
  Briefcase, 
  Image as ImageIcon, 
  DollarSign, 
  Mail, 
  Star,
  Menu,
  X
} from 'lucide-react';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { label: 'Home', icon: Home, href: '/' },
    { label: 'Services', icon: Briefcase, href: '/services' },
    { label: 'About', icon: ImageIcon, href: '/about-us' },
    { label: 'Blog', icon: DollarSign, href: '/blog' },
    { label: 'Reviews', icon: Star, href: '/reviews' },
    { label: 'Contact', icon: Mail, href: '/contact-us' },
  ];

  return (
    <>
      {/* Full Width Navbar - Not Sticky */}
      <div className="w-full px-3 sm:px-4 lg:px-6 pt-4 sm:pt-6 pb-4">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="relative w-full"
        >
          {/* Main Navbar Container - FULL WIDTH */}
          <motion.nav
            initial={{
              y: -800,
              scaleX: 0.05,
              scaleY: 0.5,
              opacity: 0,
            }}
            animate={{
              y: 0,
              scaleX: 1,
              scaleY: 1,
              opacity: 1,
            }}
            transition={{
              y: {
                type: 'spring',
                damping: 25,
                stiffness: 120,
                duration: 1.2,
              },
              scaleX: {
                type: 'spring',
                damping: 30,
                stiffness: 100,
                delay: 0.5,
                duration: 1.2,
              },
              scaleY: {
                type: 'spring',
                damping: 20,
                stiffness: 150,
                duration: 0.8,
              },
              opacity: {
                duration: 0.6,
              },
            }}
            className="relative w-full bg-black/80 backdrop-blur-2xl rounded-2xl lg:rounded-3xl border border-white/20 shadow-2xl overflow-hidden"
          >
            {/* Inner Glow Animation */}
            <motion.div
              animate={{
                opacity: [0.3, 0.7, 0.3],
                scale: [0.8, 1.2, 0.8],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-red-600/30 via-orange-600/40 to-red-600/30 rounded-full blur-3xl pointer-events-none"
            />

            {/* Inner Glow - Top Left */}
            <motion.div
              animate={{
                opacity: [0.2, 0.5, 0.2],
                x: [0, 50, 0],
                y: [0, 30, 0],
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-red-500/30 to-transparent rounded-full blur-3xl pointer-events-none"
            />

            {/* Inner Glow - Bottom Right */}
            <motion.div
              animate={{
                opacity: [0.2, 0.5, 0.2],
                x: [0, -50, 0],
                y: [0, -30, 0],
              }}
              transition={{
                duration: 6,
                repeat: Infinity,
                ease: 'easeInOut',
                delay: 1,
              }}
              className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-tl from-orange-500/30 to-transparent rounded-full blur-3xl pointer-events-none"
            />

            {/* Grid Background */}
            <div className="absolute inset-0 opacity-5">
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff10_1px,transparent_1px),linear-gradient(to_bottom,#ffffff10_1px,transparent_1px)] bg-[size:20px_20px]" />
            </div>

            {/* Top Border - Moving Animation */}
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 1.2, duration: 1 }}
              className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent overflow-hidden"
            >
              <motion.div
                animate={{ x: ['-100%', '200%'] }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity, 
                  ease: 'linear',
                  repeatDelay: 0.5,
                }}
                className="h-full w-1/2 bg-gradient-to-r from-transparent via-white to-transparent"
              />
            </motion.div>

            {/* Bottom Border - Moving Animation */}
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 1.3, duration: 1 }}
              className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-orange-500 to-transparent overflow-hidden"
            >
              <motion.div
                animate={{ x: ['200%', '-100%'] }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity, 
                  ease: 'linear',
                  repeatDelay: 0.5,
                }}
                className="h-full w-1/2 bg-gradient-to-r from-transparent via-white to-transparent"
              />
            </motion.div>

            {/* Left Border - Moving Animation */}
            <motion.div
              initial={{ scaleY: 0 }}
              animate={{ scaleY: 1 }}
              transition={{ delay: 1.4, duration: 1 }}
              className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-red-500 to-transparent overflow-hidden"
            >
              <motion.div
                animate={{ y: ['-100%', '200%'] }}
                transition={{ 
                  duration: 5, 
                  repeat: Infinity, 
                  ease: 'linear',
                  repeatDelay: 0.5,
                }}
                className="w-full h-1/2 bg-gradient-to-b from-transparent via-white to-transparent"
              />
            </motion.div>

            {/* Right Border - Moving Animation */}
            <motion.div
              initial={{ scaleY: 0 }}
              animate={{ scaleY: 1 }}
              transition={{ delay: 1.5, duration: 1 }}
              className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-orange-500 to-transparent overflow-hidden"
            >
              <motion.div
                animate={{ y: ['200%', '-100%'] }}
                transition={{ 
                  duration: 5, 
                  repeat: Infinity, 
                  ease: 'linear',
                  repeatDelay: 0.5,
                }}
                className="w-full h-1/2 bg-gradient-to-b from-transparent via-white to-transparent"
              />
            </motion.div>

            <div className="relative px-4 sm:px-6 lg:px-12 xl:px-16 py-4 sm:py-5 lg:py-6 z-10">
              <div className="flex items-center justify-between gap-4">
                
                {/* Logo - Left Side */}
                <motion.a
                  as={Link}
                  href="/"
                  initial={{ scale: 0, rotate: -540, opacity: 0 }}
                  animate={{ scale: 1, rotate: 0, opacity: 1 }}
                  transition={{
                    type: 'spring',
                    damping: 20,
                    stiffness: 200,
                    delay: 1.5,
                  }}
                  whileHover={{
                    scale: 1.05,
                    rotate: [0, -5, 5, 0],
                  }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 sm:gap-3 shrink-0"
                >
                  <div className="relative">
                    <motion.div
                      animate={{
                        rotate: 360,
                        scale: [1, 1.15, 1],
                      }}
                      transition={{
                        rotate: { duration: 8, repeat: Infinity, ease: 'linear' },
                        scale: { duration: 2, repeat: Infinity },
                      }}
                      className="absolute -inset-1.5 sm:-inset-2 bg-gradient-to-r from-red-500 via-orange-500 to-red-500 rounded-xl sm:rounded-2xl opacity-50 blur-lg"
                    />

                    <motion.div
                      animate={{
                        boxShadow: [
                          '0 0 20px rgba(239, 68, 68, 0.5)',
                          '0 0 40px rgba(249, 115, 22, 0.8)',
                          '0 0 20px rgba(239, 68, 68, 0.5)',
                        ],
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="relative w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-gradient-to-br from-red-600 via-orange-500 to-red-700 rounded-xl sm:rounded-2xl flex items-center justify-center overflow-hidden"
                    >
                      <BookOpen className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-white relative z-10" />

                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
                        className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/40 to-transparent"
                      />
                    </motion.div>
                  </div>

                  <motion.div
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 1.7 }}
                  >
                    <span className="text-white font-black text-xl sm:text-2xl lg:text-3xl tracking-tight">
                      TOP SHELF
                    </span>
                    <motion.div
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ delay: 2 }}
                      className="text-[10px] sm:text-xs text-orange-400 font-bold tracking-widest"
                    >
                      PREMIUM BOOKS
                    </motion.div>
                  </motion.div>
                </motion.a>

                {/* Desktop Menu - Icon + Text */}
                <div className="hidden lg:flex items-center gap-2 xl:gap-6">
                  {navLinks.map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <motion.a
                        as={Link}
                        key={item.label}
                        href={item.href}
                        initial={{ 
                          scale: 0,
                          y: -50,
                          opacity: 0,
                        }}
                        animate={{ 
                          scale: 1,
                          y: 0,
                          opacity: 1,
                        }}
                        transition={{
                          type: 'spring',
                          damping: 15,
                          stiffness: 200,
                          delay: 1.7 + (index * 0.1),
                        }}
                        whileHover={{ 
                          y: -5,
                          scale: 1.05,
                        }}
                        whileTap={{ scale: 0.95 }}
                        className="relative px-4 xl:px-5 py-3 group"
                      >
                        {/* Hover Background */}
                        <motion.div
                          initial={{ scale: 0, opacity: 0 }}
                          whileHover={{ scale: 1, opacity: 1 }}
                          className="absolute inset-0 bg-gradient-to-r from-red-600/10 via-orange-600/20 to-red-600/10 rounded-xl"
                        />
                        
                        {/* Icon + Text */}
                        <div className="relative flex items-center gap-2.5">
                          <Icon className="w-4 h-4 xl:w-5 xl:h-5 text-gray-400 group-hover:text-orange-500 transition-colors" />
                          <span className="text-gray-300 group-hover:text-white font-bold text-sm xl:text-base transition-colors">
                            {item.label}
                          </span>
                        </div>
                        
                        {/* Animated Underline */}
                        <motion.div
                          className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 bg-gradient-to-r from-red-500 via-orange-500 to-red-500 rounded-full"
                          initial={{ width: 0 }}
                          whileHover={{ width: '85%' }}
                          transition={{ duration: 0.3 }}
                        />

                        {/* Glow on Hover */}
                        <motion.div
                          className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"
                          style={{
                            boxShadow: '0 0 20px rgba(239, 68, 68, 0.3)',
                          }}
                        />
                      </motion.a>
                    );
                  })}
                </div>

                {/* CTA Button - Desktop */}
                <motion.button
                  initial={{ scale: 0, rotate: 360, opacity: 0 }}
                  animate={{ scale: 1, rotate: 0, opacity: 1 }}
                  transition={{
                    type: 'spring',
                    damping: 15,
                    stiffness: 200,
                    delay: 2.3,
                  }}
                  whileHover={{
                    scale: 1.05,
                    boxShadow: '0 15px 50px rgba(239, 68, 68, 0.6)',
                  }}
                  whileTap={{ scale: 0.95 }}
                  className="hidden lg:block relative px-6 xl:px-10 py-3 xl:py-4 rounded-xl xl:rounded-2xl font-black text-white text-sm xl:text-base overflow-hidden flex-shrink-0"
                >
                  <motion.div
                    animate={{
                      backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                    }}
                    transition={{ duration: 5, repeat: Infinity }}
                    className="absolute inset-0 bg-gradient-to-r from-red-600 via-orange-500 to-red-600 bg-[length:200%_100%]"
                  />

                  <motion.div
                    animate={{ x: ['-200%', '200%'] }}
                    transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12"
                  />

                  <span className="relative z-10">Get Started</span>
                </motion.button>

                {/* Mobile Menu Button */}
                <motion.button
                  initial={{ scale: 0, rotate: -360 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{
                    type: 'spring',
                    damping: 15,
                    delay: 2,
                  }}
                  whileTap={{ scale: 0.85, rotate: 180 }}
                  onClick={() => setIsOpen(!isOpen)}
                  className="lg:hidden relative p-2.5 text-white rounded-xl overflow-hidden flex-shrink-0"
                >
                  <motion.div
                    animate={{
                      scale: [1, 1.15, 1],
                      opacity: [0.3, 0.5, 0.3],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="absolute inset-0 bg-gradient-to-r from-red-600 to-orange-600 rounded-xl"
                  />
                  
                  <motion.div
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.4 }}
                    className="relative z-10"
                  >
                    {isOpen ? <X size={26} /> : <Menu size={26} />}
                  </motion.div>
                </motion.button>
              </div>
            </div>

            {/* Mobile Menu Dropdown */}
            {isOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.4 }}
                className="lg:hidden border-t border-white/10 backdrop-blur-xl overflow-hidden relative z-10"
              >
                <div className="px-4 sm:px-6 py-6 space-y-2">
                  {navLinks.map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <motion.a
                        as={Link}
                        key={item.label}
                        href={item.href}
                        initial={{ x: -100, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        transition={{ 
                          delay: index * 0.1,
                          type: 'spring',
                          stiffness: 200,
                        }}
                        onClick={() => setIsOpen(false)}
                        whileTap={{ scale: 0.97, x: 10 }}
                        className="flex items-center gap-4 px-5 py-4 text-gray-300 hover:text-white rounded-xl transition-all relative overflow-hidden group"
                      >
                        {/* Hover Gradient */}
                        <motion.div
                          className="absolute inset-0 bg-gradient-to-r from-red-600/10 via-orange-600/20 to-red-600/10"
                          initial={{ x: '-100%' }}
                          whileHover={{ x: 0 }}
                          transition={{ duration: 0.3 }}
                        />
                        
                        <Icon className="w-6 h-6 relative z-10 text-gray-400 group-hover:text-orange-500 transition-colors flex-shrink-0" />
                        <span className="font-bold text-lg relative z-10">{item.label}</span>
                      </motion.a>
                    );
                  })}
                  
                  <motion.button
                    initial={{ y: 30, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: navLinks.length * 0.1 + 0.2 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-full mt-4 px-6 py-4 bg-gradient-to-r from-red-600 to-orange-600 text-white font-black rounded-xl shadow-xl shadow-red-600/50 text-lg"
                  >
                    Get Started
                  </motion.button>
                </div>
              </motion.div>
            )}
          </motion.nav>
        </motion.div>
      </div>
    </>
  );
}
