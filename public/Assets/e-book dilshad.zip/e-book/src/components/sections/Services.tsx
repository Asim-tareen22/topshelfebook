'use client';

import { motion } from 'framer-motion';
import { 
  Pen, 
  BookText, 
  Palette, 
  Rocket, 
  Users, 
  Award,
  Sparkles,
  TrendingUp 
} from 'lucide-react';

export function Services() {
  const services = [
    {
      id: 1,
      icon: Pen,
      title: 'Ghostwriting',
      description: 'Professional writers bring your story to life with expert craftsmanship and creativity',
      gradient: 'from-[#600806] via-[#7f1d1d] to-[#600806]',
      borderGlow: 'shadow-[0_0_30px_rgba(96,8,6,0.6)]',
    },
    {
      id: 2,
      icon: BookText,
      title: 'Book Editing',
      description: 'Polish your manuscript to perfection with our expert editing team',
      gradient: 'from-[#7f1d1d] via-[#991b1b] to-[#7f1d1d]',
      borderGlow: 'shadow-[0_0_30px_rgba(127,29,29,0.6)]',
    },
    {
      id: 3,
      icon: Palette,
      title: 'Cover Design',
      description: 'Eye-catching book covers that make your book stand out on shelves',
      gradient: 'from-[#600806] via-[#881414] to-[#600806]',
      borderGlow: 'shadow-[0_0_30px_rgba(96,8,6,0.6)]',
    },
    {
      id: 4,
      icon: Rocket,
      title: 'Publishing',
      description: 'Full-service publishing to get your book into readers hands worldwide',
      gradient: 'from-[#7f1d1d] via-[#600806] to-[#7f1d1d]',
      borderGlow: 'shadow-[0_0_30px_rgba(127,29,29,0.6)]',
    },
    {
      id: 5,
      icon: Users,
      title: 'Marketing',
      description: 'Strategic book marketing to maximize your reach and sales potential',
      gradient: 'from-[#600806] via-[#7f1d1d] to-[#600806]',
      borderGlow: 'shadow-[0_0_30px_rgba(96,8,6,0.6)]',
    },
    {
      id: 6,
      icon: Award,
      title: 'Consulting',
      description: 'Expert guidance throughout your entire book publishing journey',
      gradient: 'from-[#7f1d1d] via-[#991b1b] to-[#7f1d1d]',
      borderGlow: 'shadow-[0_0_30px_rgba(127,29,29,0.6)]',
    },
    {
      id: 7,
      icon: Sparkles,
      title: 'Formatting',
      description: 'Professional book formatting for both print and digital editions',
      gradient: 'from-[#600806] via-[#881414] to-[#600806]',
      borderGlow: 'shadow-[0_0_30px_rgba(96,8,6,0.6)]',
    },
    {
      id: 8,
      icon: TrendingUp,
      title: 'Distribution',
      description: 'Worldwide distribution to major retailers and online platforms',
      gradient: 'from-[#7f1d1d] via-[#600806] to-[#7f1d1d]',
      borderGlow: 'shadow-[0_0_30px_rgba(127,29,29,0.6)]',
    },
  ];

  return (
    <section id="services" className="relative py-20 lg:py-32 overflow-hidden" style={{ backgroundColor: '#FFFAE8' }}>
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 opacity-[0.03]">
          <div 
            className="absolute inset-0" 
            style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, #600806 1px, transparent 0)`,
              backgroundSize: '40px 40px',
            }}
          />
        </div>
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.05, 0.1, 0.05],
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-20 left-20 w-[500px] h-[500px] bg-[#600806]/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.3, 1, 1.3],
            opacity: [0.1, 0.05, 0.1],
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute bottom-20 right-20 w-[500px] h-[500px] bg-[#7f1d1d]/10 rounded-full blur-3xl"
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 lg:mb-20"
        >
          <motion.div
            initial={{ scale: 0, rotate: -360 }}
            whileInView={{ scale: 1, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, type: 'spring', damping: 12 }}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#600806] to-[#7f1d1d] border-2 border-[#600806]/60 mb-8 relative overflow-hidden shadow-xl"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            >
              <Sparkles className="w-5 h-5 text-yellow-300" />
            </motion.div>
            <span className="text-white font-black text-sm tracking-wide">WHAT WE OFFER</span>
            
            {/* Badge Glow */}
            <motion.div
              animate={{
                opacity: [0.5, 1, 0.5],
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 bg-gradient-to-r from-[#600806]/20 to-[#7f1d1d]/20 blur-xl"
            />
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-5xl sm:text-6xl lg:text-7xl font-black text-gray-900 mb-6 leading-tight"
          >
            Our Premium{' '}
            <span className="relative inline-block">
              <span className="relative z-10 bg-gradient-to-r from-[#600806] via-[#7f1d1d] to-[#600806] bg-clip-text text-transparent">
                Services
              </span>
              <motion.div
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5, duration: 0.8 }}
                className="absolute bottom-2 left-0 right-0 h-4 bg-gradient-to-r from-[#600806]/30 to-[#7f1d1d]/30 -z-0 blur-sm"
              />
            </span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-gray-700 text-lg lg:text-xl max-w-3xl mx-auto leading-relaxed"
          >
            Complete publishing solutions from concept to bestseller
          </motion.p>
        </motion.div>

        {/* Enhanced Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 60, scale: 0.8 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true }}
                transition={{ 
                  delay: index * 0.1, 
                  duration: 0.7,
                  type: 'spring',
                  damping: 15 
                }}
                className="group relative"
              >
                {/* ANIMATED MOVING BORDER - Like Button */}
                <div className="absolute -inset-[3px] rounded-2xl overflow-hidden">
                  {/* Rotating Conic Gradient Border */}
                  <motion.div
                    className="absolute inset-0"
                    style={{
                      background: `conic-gradient(from 0deg, transparent, #600806, #7f1d1d, transparent, transparent)`,
                    }}
                    animate={{
                      rotate: 360,
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                  />
                  
                  {/* Moving Linear Gradient Border */}
                  <motion.div
                    className="absolute inset-0 opacity-75"
                    style={{
                      background: 'linear-gradient(90deg, transparent, #600806, #7f1d1d, transparent)',
                      backgroundSize: '200% 100%',
                    }}
                    animate={{
                      backgroundPosition: ['0% 0%', '200% 0%'],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                  />

                  {/* Pulsing Glow */}
                  <motion.div
                    className="absolute inset-0"
                    animate={{
                      boxShadow: [
                        '0 0 20px rgba(96, 8, 6, 0.4)',
                        '0 0 40px rgba(127, 29, 29, 0.8)',
                        '0 0 20px rgba(96, 8, 6, 0.4)',
                      ],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                    }}
                  />
                </div>

                {/* Main Card - DARK BACKGROUND */}
                <motion.div
                  whileHover={{ y: -15, scale: 1.02 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                  className="relative h-full bg-gradient-to-b from-gray-900 via-gray-900/95 to-black backdrop-blur-2xl rounded-2xl p-8 overflow-hidden shadow-2xl"
                >
                  {/* Top Corner Animated Gradient */}
                  <motion.div
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.1, 0.3, 0.1],
                    }}
                    transition={{ duration: 4, repeat: Infinity }}
                    className={`absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br ${service.gradient} opacity-20 blur-3xl`}
                  />

                  {/* Enhanced Icon */}
                  <motion.div
                    whileHover={{ 
                      rotate: [0, -15, 15, -15, 0],
                      scale: 1.2,
                    }}
                    transition={{ duration: 0.6 }}
                    className="relative mb-8"
                  >
                    {/* Icon Outer Ring */}
                    <motion.div
                      animate={{
                        rotate: 360,
                        scale: [1, 1.1, 1],
                      }}
                      transition={{
                        rotate: { duration: 8, repeat: Infinity, ease: 'linear' },
                        scale: { duration: 2, repeat: Infinity },
                      }}
                      className={`absolute -inset-2 rounded-2xl bg-gradient-to-br ${service.gradient} opacity-30 blur-md`}
                    />

                    {/* Icon Container */}
                    <div className={`relative w-16 h-16 rounded-2xl bg-gradient-to-br ${service.gradient} flex items-center justify-center overflow-hidden shadow-xl`}>
                      <Icon className="w-8 h-8 text-white relative z-10" />
                      
                      {/* Multi-layer Shine */}
                      <motion.div
                        animate={{ x: ['-200%', '200%'] }}
                        transition={{ 
                          duration: 2.5, 
                          repeat: Infinity, 
                          repeatDelay: 3,
                          ease: 'easeInOut' 
                        }}
                        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12"
                      />
                      <motion.div
                        animate={{ x: ['200%', '-200%'] }}
                        transition={{ 
                          duration: 3, 
                          repeat: Infinity, 
                          repeatDelay: 2,
                          ease: 'easeInOut' 
                        }}
                        className="absolute inset-0 bg-gradient-to-l from-transparent via-white/20 to-transparent -skew-x-12"
                      />
                    </div>

                    {/* Pulsing Glow */}
                    <motion.div
                      animate={{
                        scale: [1, 1.3, 1],
                        opacity: [0.3, 0.6, 0.3],
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className={`absolute inset-0 w-16 h-16 rounded-2xl bg-gradient-to-br ${service.gradient} blur-xl`}
                    />
                  </motion.div>

                  {/* Content */}
                  <div className="relative z-10 space-y-4">
                    <motion.h3 
                      className="text-2xl lg:text-3xl font-black text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-white group-hover:to-gray-200 transition-all duration-300"
                    >
                      {service.title}
                    </motion.h3>
                    
                    <p className="text-gray-400 text-base leading-relaxed group-hover:text-gray-300 transition-colors">
                      {service.description}
                    </p>
                  </div>

                  {/* Animated Learn More */}
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileHover={{ opacity: 1, y: 0 }}
                    className="absolute bottom-8 right-8 flex items-center gap-2 text-transparent bg-gradient-to-r bg-clip-text from-[#600806] to-[#7f1d1d] font-bold text-sm opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <span>Learn More</span>
                    <motion.svg 
                      className="w-5 h-5 text-[#600806]"
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </motion.svg>
                  </motion.div>

                  {/* Bottom Animated Line */}
                  <div className="absolute bottom-0 left-0 right-0 h-1 overflow-hidden rounded-b-2xl">
                    <motion.div
                      className={`h-full bg-gradient-to-r ${service.gradient}`}
                      initial={{ x: '-100%' }}
                      whileHover={{ x: '100%' }}
                      transition={{ duration: 0.8, ease: 'easeInOut' }}
                    />
                  </div>

                  {/* Corner Decoration */}
                  <motion.div
                    animate={{
                      rotate: [0, 90, 0],
                      scale: [1, 1.2, 1],
                    }}
                    transition={{ duration: 4, repeat: Infinity }}
                    className="absolute top-4 right-4 w-2 h-2 bg-[#600806] rounded-full opacity-50 group-hover:opacity-100"
                  >
                    <motion.div
                      animate={{ scale: [1, 2, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute inset-0 bg-[#600806] rounded-full blur-sm"
                    />
                  </motion.div>
                </motion.div>
              </motion.div>
            );
          })}
        </div>

        {/* Enhanced CTA */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8 }}
          className="text-center mt-20"
        >
          <motion.button
            whileHover={{ scale: 1.08, y: -8 }}
            whileTap={{ scale: 0.95 }}
            className="relative px-12 py-6 bg-gradient-to-r from-[#600806] via-[#7f1d1d] to-[#600806] bg-[length:200%_100%] text-white font-black text-lg rounded-2xl overflow-hidden group shadow-2xl"
          >
            {/* Animated Background */}
            <motion.div
              animate={{ backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'] }}
              transition={{ duration: 5, repeat: Infinity }}
              className="absolute inset-0 bg-gradient-to-r from-[#600806] via-[#7f1d1d] to-[#600806] bg-[length:200%_100%]"
            />

            {/* Shine Effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
            />

            {/* Border Glow */}
            <motion.div
              animate={{
                boxShadow: [
                  '0 0 20px rgba(96, 8, 6, 0.5)',
                  '0 0 60px rgba(127, 29, 29, 0.8)',
                  '0 0 20px rgba(96, 8, 6, 0.5)',
                ],
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 rounded-2xl"
            />

            <span className="relative z-10 flex items-center gap-3">
              Get Started Today
              <motion.span
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                →
              </motion.span>
            </span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}