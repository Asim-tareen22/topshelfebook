'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { Plus, Minus, HelpCircle, Sparkles } from 'lucide-react';

const FAQS = [
  {
    id: 1,
    question: 'What is TopShelf eBook?',
    answer: 'TopShelf eBook is a premium digital library platform offering unlimited access to thousands of bestselling books across all genres. Our AI-powered recommendation system helps you discover your next favorite read effortlessly.',
  },
  {
    id: 2,
    question: 'How does the free trial work?',
    answer: 'Start with a 14-day free trial on any plan - no credit card required! Experience all premium features including unlimited books, HD downloads, and priority support. Cancel anytime during the trial period at no cost.',
  },
  {
    id: 3,
    question: 'Can I switch plans anytime?',
    answer: 'Absolutely! You can upgrade or downgrade your plan at any time. Changes take effect immediately, and we\'ll prorate the difference. Your reading progress and collections are preserved across all plan changes.',
  },
  {
    id: 4,
    question: 'How many devices can I use?',
    answer: 'Device limits vary by plan: Basic (1 device), Professional (5 devices), Enterprise (unlimited). All plans support automatic sync across devices, so you can start reading on one device and continue on another seamlessly.',
  },
  {
    id: 5,
    question: 'Is offline reading available?',
    answer: 'Yes! Professional and Enterprise plans include offline reading mode. Download books to your device and read them anywhere without an internet connection. Perfect for traveling or commuting.',
  },
  {
    id: 6,
    question: 'What payment methods do you accept?',
    answer: 'We accept all major credit cards (Visa, Mastercard, American Express), PayPal, and digital wallets. All transactions are encrypted and secure. For Enterprise plans, we also offer invoice billing.',
  },
  {
    id: 7,
    question: 'Can I cancel my subscription?',
    answer: 'Yes, you can cancel anytime with just one click from your account settings. Your access continues until the end of your billing period. We offer a 30-day money-back guarantee if you\'re not satisfied.',
  },
  {
    id: 8,
    question: 'Do you offer student or team discounts?',
    answer: 'Yes! We offer 25% off for verified students and educators. Team discounts start at 15% for 5+ users. Contact our sales team for custom pricing for organizations and educational institutions.',
  },
  {
    id: 9,
    question: 'How often is new content added?',
    answer: 'We add new books weekly, including bestsellers, new releases, and exclusive titles. Professional and Enterprise members get early access to new releases. Our library grows by 100+ books every month.',
  },
  {
    id: 10,
    question: 'Is there customer support available?',
    answer: 'Basic plan includes email support (24-48 hour response). Professional and Enterprise plans get 24/7 priority support via email, live chat, and phone. Enterprise customers also get a dedicated account manager.',
  },
];

export function FAQs() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="relative py-24 overflow-hidden" style={{ backgroundColor: '#FFFAE8' }}>
      
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div 
          className="absolute inset-0" 
          style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, #7f1d1d 1px, transparent 0)`,
            backgroundSize: '40px 40px',
          }}
        />
      </div>

      {/* Gradient Orbs */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-gradient-to-r from-red-900/10 to-red-800/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-gradient-to-r from-orange-900/10 to-red-900/10 rounded-full blur-3xl" />

      {/* Floating Particles */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          animate={{
            y: [0, -50, 0],
            opacity: [0, 0.4, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 4 + Math.random() * 3,
            repeat: Infinity,
            delay: i * 0.3,
          }}
          style={{
            position: 'absolute',
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          className="w-2 h-2 bg-red-900/20 rounded-full pointer-events-none"
        />
      ))}

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block mb-4"
          >
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-red-900 to-red-800 rounded-full shadow-lg">
              <HelpCircle className="w-4 h-4 text-yellow-300" />
              <span className="text-white text-sm font-black tracking-wide">FAQS</span>
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl lg:text-6xl font-black mb-4"
          >
            <span className="text-gray-900">Frequently Asked </span>
            <span className="bg-gradient-to-r from-red-900 via-red-700 to-red-900 bg-clip-text text-transparent">
              Questions
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-gray-700 max-w-2xl mx-auto"
          >
            Got questions? We've got answers! Find everything you need to know about TopShelf eBook.
          </motion.p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {FAQS.map((faq, index) => (
            <FAQItem
              key={faq.id}
              faq={faq}
              index={index}
              isOpen={openIndex === index}
              onClick={() => toggleFAQ(index)}
            />
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mt-16 text-center"
        >
          <div className="bg-white p-8 rounded-2xl shadow-xl border-2 border-red-100">
            <Sparkles className="w-12 h-12 text-red-900 mx-auto mb-4" />
            <h3 className="text-2xl font-black text-gray-900 mb-2">
              Still have questions?
            </h3>
            <p className="text-gray-600 mb-6">
              Our support team is here to help you 24/7
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-red-900 to-red-800 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition-all"
            >
              Contact Support
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function FAQItem({ 
  faq, 
  index, 
  isOpen, 
  onClick 
}: { 
  faq: typeof FAQS[0]; 
  index: number; 
  isOpen: boolean; 
  onClick: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.05 }}
    >
      <motion.div
        whileHover={{ scale: 1.01 }}
        className={`bg-white rounded-2xl overflow-hidden transition-all ${
          isOpen
            ? 'border-2 border-red-800 shadow-xl shadow-red-900/10'
            : 'border-2 border-gray-200 shadow-lg hover:border-red-300'
        }`}
      >
        {/* Question Button */}
        <button
          onClick={onClick}
          className="w-full px-6 py-5 flex items-center justify-between gap-4 text-left group"
        >
          <div className="flex items-center gap-4 flex-1">
            {/* Number Badge */}
            <motion.div
              animate={isOpen ? { scale: 1.1 } : { scale: 1 }}
              className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-black text-sm ${
                isOpen
                  ? 'bg-gradient-to-br from-red-900 to-red-800 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-600 group-hover:bg-red-50 group-hover:text-red-900'
              }`}
            >
              {index + 1}
            </motion.div>

            {/* Question Text */}
            <h3 className={`text-lg md:text-xl font-bold transition-colors ${
              isOpen ? 'text-red-900' : 'text-gray-900 group-hover:text-red-900'
            }`}>
              {faq.question}
            </h3>
          </div>

          {/* Toggle Icon */}
          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.3 }}
            className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
              isOpen
                ? 'bg-gradient-to-br from-red-900 to-red-800 text-white'
                : 'bg-gray-100 text-gray-600 group-hover:bg-red-50 group-hover:text-red-900'
            }`}
          >
            {isOpen ? (
              <Minus className="w-5 h-5" strokeWidth={3} />
            ) : (
              <Plus className="w-5 h-5" strokeWidth={3} />
            )}
          </motion.div>
        </button>

        {/* Answer */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="px-6 pb-6 pl-20">
                <motion.div
                  initial={{ y: -10 }}
                  animate={{ y: 0 }}
                  className="pt-2 border-t-2 border-red-100"
                >
                  <p className="text-gray-700 leading-relaxed text-base">
                    {faq.answer}
                  </p>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}