'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { 
  BookOpen, 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Youtube,
  Send,
  Heart,
  ArrowUp,
  Sparkles,
  Award,
  Users,
  TrendingUp,
  Check
} from 'lucide-react';
import { useState } from 'react';

export function Footer() {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubscribed(true);
    setTimeout(() => {
      setEmail('');
      setIsSubscribed(false);
    }, 3000);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const footerLinks = {
    company: [
      { label: 'About Us', href: '/about-us' },
      { label: 'Our Story', href: '/about-us' },
      { label: 'Careers', href: '/contact-us' },
      { label: 'Press Kit', href: '/blog' },
      { label: 'Partners', href: '/contact-us' },
    ],
    services: [
      { label: 'Ghostwriting', href: '/services/ghostwriting' },
      { label: 'Book Editing', href: '/services/editing' },
      { label: 'Publishing', href: '/services' },
      { label: 'Marketing', href: '/services/marketing' },
      { label: 'Distribution', href: '/services' },
    ],
    resources: [
      { label: 'Blog', href: '/blog' },
      { label: 'Case Studies', href: '/blog' },
      { label: 'FAQs', href: '/#faqs' },
      { label: 'Support', href: '/contact-us' },
      { label: 'Contact', href: '/contact-us' },
    ],
    legal: [
      { label: 'Privacy Policy', href: '#privacy' },
      { label: 'Terms of Service', href: '#terms' },
      { label: 'Cookie Policy', href: '#cookies' },
      { label: 'Refund Policy', href: '#refund' },
      { label: 'Disclaimer', href: '#disclaimer' },
    ],
  };

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook', color: 'from-blue-600 to-blue-500' },
    { icon: Twitter, href: '#', label: 'Twitter', color: 'from-sky-600 to-sky-500' },
    { icon: Instagram, href: '#', label: 'Instagram', color: 'from-pink-600 to-purple-500' },
    { icon: Linkedin, href: '#', label: 'LinkedIn', color: 'from-blue-700 to-blue-600' },
    { icon: Youtube, href: '#', label: 'YouTube', color: 'from-red-600 to-red-500' },
  ];

  const stats = [
    { icon: BookOpen, value: '500+', label: 'Books Published' },
    { icon: Users, value: '1000+', label: 'Happy Authors' },
    { icon: Award, value: '50+', label: 'Awards Won' },
    { icon: TrendingUp, value: '98%', label: 'Success Rate' },
  ];

  return (
    <footer className="relative bg-black overflow-hidden">
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#ff000010,transparent_50%)]" />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute top-0 left-0 w-[500px] h-[500px] bg-red-600/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.3, 1, 1.3],
            opacity: [0.25, 0.15, 0.25],
          }}
          transition={{ duration: 12, repeat: Infinity }}
          className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-orange-600/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.1, 1.4, 1.1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-red-600/10 to-orange-600/10 rounded-full blur-3xl"
        />
      </div>

      {/* Stats Section */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative border-b border-white/10"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="relative group"
              >
                <div className="text-center space-y-3">
                  <motion.div
                    whileHover={{ rotate: 360, scale: 1.2 }}
                    transition={{ duration: 0.6 }}
                    className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-red-600/20 to-orange-600/20 border border-red-500/30 backdrop-blur-sm relative overflow-hidden"
                  >
                    <stat.icon className="w-8 h-8 text-red-400 relative z-10" />
                    <motion.div
                      animate={{
                        scale: [1, 1.5, 1],
                        opacity: [0.3, 0.6, 0.3],
                      }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-orange-500/20 blur-xl"
                    />
                  </motion.div>
                  <div>
                    <motion.h4
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      viewport={{ once: true }}
                      className="text-4xl font-black bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent"
                    >
                      {stat.value}
                    </motion.h4>
                    <p className="text-gray-400 text-sm font-semibold mt-1">{stat.label}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Main Footer Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12 lg:gap-8 mb-16">
          
          {/* Brand Section - Larger */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2 space-y-6"
          >
            {/* Enhanced Logo */}
            <motion.div 
              className="flex items-center gap-3 group cursor-pointer"
              whileHover={{ scale: 1.05 }}
            >
              <div className="relative">
                <motion.div
                  animate={{
                    rotate: 360,
                  }}
                  transition={{
                    duration: 20,
                    repeat: Infinity,
                    ease: 'linear',
                  }}
                  className="absolute -inset-2 bg-gradient-to-r from-red-500 via-orange-500 to-red-500 rounded-2xl opacity-50 blur-lg"
                />
                <motion.div
                  animate={{
                    boxShadow: [
                      '0 0 20px rgba(239, 68, 68, 0.4)',
                      '0 0 40px rgba(249, 115, 22, 0.6)',
                      '0 0 20px rgba(239, 68, 68, 0.4)',
                    ],
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="relative w-16 h-16 bg-gradient-to-br from-red-600 to-orange-600 rounded-2xl flex items-center justify-center overflow-hidden"
                >
                  <BookOpen className="w-8 h-8 text-white relative z-10" />
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
                    className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/30 to-transparent"
                  />
                </motion.div>
              </div>
              <div>
                <h3 className="text-3xl font-black text-white">TOP SHELF</h3>
                <p className="text-xs text-orange-400 font-bold tracking-widest">PREMIUM BOOKS</p>
              </div>
            </motion.div>

            <p className="text-gray-400 leading-relaxed text-base">
              Transform your ideas into bestselling books with our world-class ghostwriting, editing, and publishing services trusted by authors worldwide.
            </p>

            {/* Enhanced Contact Info */}
            <div className="space-y-4">
              {[
                { icon: Mail, text: 'contact@topshelf.com', href: 'mailto:contact@topshelf.com' },
                { icon: Phone, text: '+1 (555) 123-4567', href: 'tel:+15551234567' },
                { icon: MapPin, text: 'New York, NY 10001, USA', href: '#' },
              ].map((item, index) => (
                <motion.a
                  key={index}
                  href={item.href}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ x: 8 }}
                  className="flex items-center gap-4 text-gray-400 hover:text-red-400 transition-all cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-red-600/10 group-hover:border-red-500/30 transition-all">
                    <item.icon className="w-5 h-5 text-red-500" />
                  </div>
                  <span className="text-sm font-medium">{item.text}</span>
                </motion.a>
              ))}
            </div>
          </motion.div>

          {/* Links Sections */}
          {Object.entries(footerLinks).map(([title, links], sectionIndex) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: sectionIndex * 0.1 }}
              className="lg:col-span-1"
            >
              <h4 className="text-white font-black text-lg mb-6 capitalize relative inline-block">
                {title}
                <motion.div
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + sectionIndex * 0.1 }}
                  className="absolute -bottom-2 left-0 h-1 w-full bg-gradient-to-r from-red-500 to-orange-500 rounded-full origin-left"
                />
              </h4>
              <ul className="space-y-3">
                {links.map((link, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.4 + index * 0.05 }}
                  >
                    <motion.a
                      as={Link}
                      href={link.href}
                      whileHover={{ x: 8 }}
                      className="text-gray-400 hover:text-red-400 transition-all text-sm flex items-center gap-2 group"
                    >
                      <motion.span
                        initial={{ width: 0 }}
                        whileHover={{ width: 8 }}
                        className="h-px bg-gradient-to-r from-red-500 to-orange-500"
                      />
                      <span className="group-hover:font-semibold transition-all">{link.label}</span>
                    </motion.a>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Newsletter Section - Enhanced */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative rounded-3xl overflow-hidden mb-16"
        >
          {/* Animated Background */}
          <motion.div
            animate={{
              backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
            }}
            transition={{ duration: 10, repeat: Infinity }}
            className="absolute inset-0 bg-gradient-to-r from-red-600/10 via-orange-600/10 to-red-600/10 bg-[length:200%_100%]"
          />
          
          <div className="relative backdrop-blur-xl bg-white/5 border border-white/10 p-8 sm:p-12">
            <div className="max-w-3xl mx-auto text-center space-y-8">
              <div className="space-y-3">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  whileInView={{ scale: 1, rotate: 0 }}
                  viewport={{ once: true }}
                  transition={{ type: 'spring', damping: 15 }}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-red-600/20 to-orange-600/20 border border-red-500/40 mb-4"
                >
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                  >
                    <Sparkles className="w-5 h-5 text-red-400" />
                  </motion.div>
                  <span className="text-red-400 font-black text-sm tracking-wide">JOIN OUR COMMUNITY</span>
                </motion.div>
                
                <h3 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white leading-tight">
                  Get{' '}
                  <span className="relative inline-block">
                    <span className="relative z-10 bg-gradient-to-r from-red-500 via-orange-500 to-red-600 bg-clip-text text-transparent">
                      Exclusive Updates
                    </span>
                    <motion.div
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      className="absolute bottom-1 left-0 right-0 h-3 bg-gradient-to-r from-red-500/30 to-orange-500/30 blur-sm -z-0"
                    />
                  </span>
                </h3>
                <p className="text-gray-400 text-lg">Subscribe to receive publishing tips, author success stories, and exclusive offers</p>
              </div>

              <form onSubmit={handleSubscribe} className="max-w-xl mx-auto">
                <div className="relative group">
                  {/* Animated Border */}
                  <motion.div
                    animate={{
                      rotate: 360,
                    }}
                    transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                    className="absolute -inset-1 bg-gradient-to-r from-red-600 via-orange-500 to-red-600 rounded-2xl opacity-0 group-hover:opacity-30 blur-lg transition-opacity"
                  />
                  
                  <div className="relative flex items-center gap-2 bg-white/10 backdrop-blur-xl border-2 border-white/20 rounded-2xl p-2 focus-within:border-red-500/50 transition-all">
                    <Mail className="w-5 h-5 text-gray-400 ml-4" />
                    <motion.input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      required
                      whileFocus={{ scale: 1.01 }}
                      className="flex-1 px-4 py-4 bg-transparent text-white placeholder:text-gray-500 focus:outline-none"
                    />
                    <motion.button
                      type="submit"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-8 py-4 bg-gradient-to-r from-red-600 to-orange-600 text-white font-black rounded-xl flex items-center gap-2 shadow-lg shadow-red-600/30 relative overflow-hidden group"
                    >
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/30 to-white/0"
                        animate={{ x: ['-100%', '200%'] }}
                        transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                      />
                      <span className="relative z-10">{isSubscribed ? <Check className="w-5 h-5" /> : <Send className="w-5 h-5" />}</span>
                      <span className="relative z-10 hidden sm:inline">
                        {isSubscribed ? 'Subscribed!' : 'Subscribe'}
                      </span>
                    </motion.button>
                  </div>
                </div>
              </form>

              {isSubscribed && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-green-600/20 border border-green-500/30 rounded-xl text-green-400 text-sm font-bold backdrop-blur-sm"
                >
                  <Check className="w-4 h-4" />
                  Thank you for subscribing! Check your inbox.
                </motion.div>
              )}
            </div>
          </div>
        </motion.div>

        {/* Social Links - Enhanced */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap items-center justify-center gap-4 mb-16"
        >
          {socialLinks.map((social, index) => (
            <motion.a
              as={Link}
              key={index}
              href={social.href}
              initial={{ opacity: 0, scale: 0 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, type: 'spring', damping: 12 }}
              whileHover={{ scale: 1.15, y: -8 }}
              whileTap={{ scale: 0.9 }}
              className="relative group"
              aria-label={social.label}
            >
              {/* Glow Effect */}
              <motion.div
                className={`absolute -inset-2 bg-gradient-to-r ${social.color} rounded-2xl opacity-0 group-hover:opacity-50 blur-xl transition-opacity`}
              />
              
              <div className="relative w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 group-hover:bg-white/10 group-hover:border-white/30 transition-all backdrop-blur-sm overflow-hidden">
                <social.icon className="w-6 h-6 relative z-10 group-hover:text-white transition-colors" />
                
                {/* Hover Gradient */}
                <motion.div
                  className={`absolute inset-0 bg-gradient-to-br ${social.color} opacity-0 group-hover:opacity-100 transition-opacity`}
                  initial={{ scale: 0 }}
                  whileHover={{ scale: 1 }}
                />
              </div>
            </motion.a>
          ))}
        </motion.div>

        {/* Bottom Bar - Enhanced */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="border-t border-white/10 pt-8"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <motion.p
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-gray-400 text-sm flex items-center gap-2"
            >
              © 2024 <span className="font-bold text-white">TOP SHELF</span>. Crafted with
              <motion.span
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <Heart className="w-4 h-4 text-red-500 fill-current inline-block" />
              </motion.span>
              by our team. All rights reserved.
            </motion.p>

            <div className="flex items-center gap-8 text-sm">
              {['Privacy', 'Terms', 'Cookies', 'Sitemap'].map((item, index) => (
                <motion.a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.1, color: '#ef4444' }}
                  className="text-gray-400 hover:text-red-400 font-medium transition-colors"
                >
                  {item}
                </motion.a>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll to Top - Enhanced */}
      <motion.button
        initial={{ opacity: 0, scale: 0 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        whileHover={{ scale: 1.15, y: -8 }}
        whileTap={{ scale: 0.9 }}
        onClick={scrollToTop}
        className="fixed bottom-8 right-8 w-16 h-16 bg-gradient-to-r from-red-600 to-orange-600 text-white rounded-2xl flex items-center justify-center shadow-2xl shadow-red-600/50 z-50 group overflow-hidden"
      >
        <ArrowUp className="w-7 h-7 relative z-10 group-hover:-translate-y-1 transition-transform" />
        
        {/* Pulsing Ring */}
        <motion.div
          animate={{ 
            scale: [1, 1.5, 1],
            opacity: [0.5, 0, 0.5],
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute inset-0 bg-red-500 rounded-2xl"
        />
        
        {/* Rotating Border */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          className="absolute -inset-1 bg-gradient-to-r from-red-500 via-orange-500 to-red-500 rounded-2xl opacity-50 blur-lg"
        />
      </motion.button>

      {/* Animated Bottom Border */}
      <div className="relative h-1 overflow-hidden">
        <motion.div
          initial={{ x: '-100%' }}
          whileInView={{ x: '100%' }}
          viewport={{ once: true }}
          transition={{ duration: 2, ease: 'easeInOut' }}
          className="h-full w-1/2 bg-gradient-to-r from-transparent via-red-500 to-transparent"
        />
      </div>
    </footer>
  );
}