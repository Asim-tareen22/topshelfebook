'use client';

import Image from 'next/image';
import { motion } from 'framer-motion';
import { Sparkles, Star, Zap, Award, TrendingUp } from 'lucide-react';

export function PersonalBrand() {
  return (
    <section className="relative bg-black py-20 lg:py-32 overflow-hidden">
      {/* ANIMATED BACKGROUND */}
      <div className="absolute inset-0">
        {/* Base Gradient */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,#450a0a20,transparent_70%)]" />
        
        {/* Rotating Orbs */}
        <motion.div
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.15, 0.3, 0.15],
            rotate: [0, 360],
            x: [0, 100, 0],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -top-40 -left-40 w-[600px] h-[600px] bg-gradient-to-br from-red-900/30 to-red-950/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.5, 1, 1.5],
            opacity: [0.3, 0.15, 0.3],
            rotate: [360, 0],
            x: [0, -100, 0],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute -bottom-40 -right-40 w-[600px] h-[600px] bg-gradient-to-tl from-red-800/30 to-red-900/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.2, 0.4, 0.2],
            y: [0, -80, 0],
          }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-r from-red-600/20 to-red-900/20 rounded-full blur-3xl"
        />

        {/* Floating Particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            animate={{
              y: [0, -150, 0],
              x: [0, Math.random() * 100 - 50, 0],
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0],
            }}
            transition={{
              duration: 5 + i * 0.3,
              repeat: Infinity,
              delay: i * 0.4,
              ease: "easeInOut",
            }}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            className="absolute w-1 h-1 bg-red-500 rounded-full shadow-lg"
          />
        ))}

        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:48px_48px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-12">
        
        {/* Animated Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.5, y: -50 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, type: "spring", bounce: 0.4 }}
          className="text-center mb-16"
        >
          <motion.div
            animate={{
              boxShadow: [
                '0 0 20px rgba(127, 29, 29, 0.4)',
                '0 0 40px rgba(153, 27, 27, 0.7)',
                '0 0 20px rgba(127, 29, 29, 0.4)',
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-red-950/80 to-red-900/80 border-2 border-red-700/60 backdrop-blur-xl"
          >
            <motion.div
              animate={{ rotate: 360, scale: [1, 1.2, 1] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="w-5 h-5 text-white" />
            </motion.div>
            <p className="text-sm font-black tracking-widest text-white">WHY CHOOSE US</p>
            <motion.div
              animate={{ scale: [1, 1.3, 1], rotate: [0, 180, 360] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Star className="w-4 h-4 text-white" fill="white" />
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-2 gap-20 items-center">

          {/* LEFT CONTENT */}
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, type: "spring" }}
            className="space-y-8 relative z-10"
          >
            {/* Heading with Animated Underline */}
            <div className="space-y-4">
              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="text-5xl md:text-6xl lg:text-7xl font-black leading-[1.1] text-white"
              >
                Build Your{' '}
                <span className="relative inline-block">
                  <motion.span
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.4 }}
                    className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 via-red-700 to-red-900"
                  >
                    Author Identity
                  </motion.span>
                  <motion.div
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.6, duration: 0.8 }}
                    className="absolute -bottom-2 left-0 right-0 h-3 bg-gradient-to-r from-red-900/50 to-red-700/50 blur-sm origin-left"
                  />
                </span>
              </motion.h2>
            </div>

            {/* Description with Stagger */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="space-y-4"
            >
              <p className="text-xl md:text-2xl text-gray-300 leading-relaxed">
                We help authors like you create a{' '}
                <span className="text-white font-bold">strong presence</span>{' '}
                in the digital world. Our expert team handles everything —{' '}
                <span className="text-red-400 font-semibold">writing, editing, publishing, and branding</span>.
              </p>

              <p className="text-lg text-gray-400 leading-relaxed">
                Your story deserves to shine. We make sure it reaches the world with{' '}
                <span className="text-white font-semibold">impact, clarity, and style</span>.
              </p>
            </motion.div>

            {/* Animated Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.7 }}
              className="flex gap-8 pt-4"
            >
              {[
                { icon: Award, value: '500+', label: 'Books' },
                { icon: TrendingUp, value: '99%', label: 'Success' },
                { icon: Star, value: '5.0', label: 'Rating' },
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 0, rotate: -180 }}
                  whileInView={{ scale: 1, rotate: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.8 + i * 0.1, type: "spring" }}
                  whileHover={{ scale: 1.1, y: -5 }}
                  className="flex items-center gap-2"
                >
                  <div className="p-2 bg-red-900/40 rounded-lg border border-red-700/40">
                    <stat.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-black text-white">{stat.value}</p>
                    <p className="text-xs text-gray-400">{stat.label}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {/* Animated Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.9 }}
              className="flex gap-5 pt-4"
            >
              <motion.button
                whileHover={{ scale: 1.08, y: -5 }}
                whileTap={{ scale: 0.95 }}
                className="group relative px-10 py-4 bg-gradient-to-r from-red-800 to-red-900 text-white font-bold text-lg rounded-xl shadow-2xl overflow-hidden"
              >
                {/* Animated Background */}
                <motion.div
                  animate={{
                    backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                  className="absolute inset-0 bg-gradient-to-r from-red-700 via-red-600 to-red-700 bg-[length:200%_100%] opacity-0 group-hover:opacity-100 transition-opacity"
                />
                
                {/* Shine */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -skew-x-12"
                  animate={{ x: ['-200%', '200%'] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                />
                
                <span className="relative z-10 flex items-center gap-2">
                  Get Started
                  <motion.div
                    animate={{ x: [0, 5, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    <Zap className="w-5 h-5" fill="white" />
                  </motion.div>
                </span>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05, borderColor: 'rgba(255,255,255,1)' }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-4 border-2 border-white/30 hover:bg-white/10 text-white font-bold text-lg rounded-xl backdrop-blur-xl transition-all"
              >
                Learn More
              </motion.button>
            </motion.div>
          </motion.div>

          {/* RIGHT IMAGE - EQUAL HEIGHT */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotateY: -30 }}
            whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, type: "spring", damping: 20 }}
            className="relative h-full flex items-center justify-center"
            style={{ perspective: "1000px" }}
          >
            {/* Rotating Glow Rings */}
            <motion.div
              animate={{ rotate: 360, scale: [1, 1.2, 1] }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 bg-gradient-to-r from-red-600/30 via-transparent to-red-900/30 rounded-full blur-3xl"
            />
            <motion.div
              animate={{ rotate: -360, scale: [1.2, 1, 1.2] }}
              transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 bg-gradient-to-l from-red-500/20 via-transparent to-red-800/20 rounded-full blur-2xl"
            />

            {/* Orbiting Stars */}
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                animate={{ rotate: 360 }}
                transition={{
                  duration: 15 + i * 2,
                  repeat: Infinity,
                  ease: "linear",
                }}
                className="absolute inset-0"
                style={{ transformOrigin: 'center' }}
              >
                <motion.div
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                  className="absolute top-0 left-1/2 -translate-x-1/2"
                  style={{ transform: `translateY(${i * 60}px)` }}
                >
                  <Star className="w-3 h-3 text-white" fill="white" />
                </motion.div>
              </motion.div>
            ))}

            {/* Main Image with 3D Effect */}
            <motion.div
              whileHover={{
                scale: 1.05,
                rotateY: 5,
                rotateX: 5,
              }}
              transition={{ type: "spring", stiffness: 200 }}
              className="relative z-10 w-full h-[500px] lg:h-[600px]"
            >
              {/* Pulsing Glow */}
              <motion.div
                animate={{
                  boxShadow: [
                    '0 0 80px rgba(239, 68, 68, 0.4)',
                    '0 0 120px rgba(220, 38, 38, 0.6)',
                    '0 0 80px rgba(239, 68, 68, 0.4)',
                  ],
                }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -inset-6 rounded-3xl"
              />

              <div className="relative w-full h-full">
                <Image
                  src="/Assets/ip-incubation.4307345e.png"
                  alt="Author Identity"
                  fill
                  className="object-contain drop-shadow-[0_0_60px_rgba(239,68,68,0.5)]"
                  priority
                />
                
                {/* Animated Shine */}
                <motion.div
                  animate={{ x: ['-150%', '250%'] }}
                  transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
                />
              </div>

              {/* Floating Badges */}
              <motion.div
                animate={{
                  y: [0, -20, 0],
                  rotate: [0, 5, 0],
                }}
                transition={{ duration: 4, repeat: Infinity }}
                className="absolute -top-8 -right-8 bg-gradient-to-br from-red-600 to-red-900 text-white px-6 py-4 rounded-2xl shadow-2xl border-2 border-white/30 backdrop-blur-xl"
              >
                <p className="text-3xl font-black">500+</p>
                <p className="text-xs font-bold">Published</p>
              </motion.div>

              <motion.div
                animate={{
                  y: [0, 20, 0],
                  rotate: [0, -5, 0],
                }}
                transition={{ duration: 5, repeat: Infinity }}
                className="absolute -bottom-8 -left-8 bg-gradient-to-br from-white to-gray-100 text-red-900 px-6 py-4 rounded-2xl shadow-2xl border-2 border-red-500/40"
              >
                <p className="text-3xl font-black">99%</p>
                <p className="text-xs font-bold">Success</p>
              </motion.div>
            </motion.div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}