'use client'
import { motion } from 'framer-motion'
import { FaRocket, FaComments, FaPalette, FaSearch, FaPencilAlt, FaCheckCircle, FaClock, FaAward, FaLightbulb, FaHeadset, FaBook, FaCamera, FaMask, FaNewspaper, FaGraduationCap, FaTabletAlt, FaDollarSign } from 'react-icons/fa'
import Link from 'next/link'

export default function BookCoverDesign() {
  const designProcess = [
    {
      icon: <FaSearch />,
      title: 'Research & Conceptualization',
      desc: 'Our designers start by understanding your unique needs and preferences. We collect all the relevant information from you, like the genre your book falls into, your target audience, and the theme of your story. Next, we look for current design trends and gather inspiration from various sources that can align with your book\'s theme.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: <FaPencilAlt />,
      title: 'Drafting and Thumbnail Sketches',
      desc: 'Once our designers gather all the relevant concepts, they roll up their sleeves and dive into the sea of creativity. They transform their ideas into draftings and sketches. These drafts are just rough sketches or thumbnail concepts to explore different ideas and are focused on the composition and layout.',
      color: 'from-pink-500 to-rose-500'
    },
    {
      icon: <FaPalette />,
      title: 'Design Development and Refinement',
      desc: 'Now comes the real deal! Once you approve the basic sketch for your Online Book Cover Design, our team will dive into the world of design software and turn the rough sketch into a polished piece of art. We select the perfect fonts and images to bring your vision to life.',
      color: 'from-rose-500 to-orange-500'
    },
    {
      icon: <FaCheckCircle />,
      title: 'Finalization and Production',
      desc: 'And then comes the grand finale moment! Once you approve the cover design, our designers get down to the nitty-gritty details, like adjusting the layout for different formats and adding additional elements such as barcode, spine text, etc.',
      color: 'from-orange-500 to-yellow-500'
    }
  ]

  const whyChooseUs = [
    {
      icon: <FaAward />,
      title: 'Years of Experience',
      desc: 'Bringing years of experience and expertise to the table.'
    },
    {
      icon: <FaPalette />,
      title: 'Fully Customized',
      desc: 'Offering fully customized solutions tailored to your needs and preferences.'
    },
    {
      icon: <FaLightbulb />,
      title: 'Fresh & Innovative',
      desc: 'Delivering designs that are fresh, innovative, and eye-catching.'
    },
    {
      icon: <FaHeadset />,
      title: '24/7 Support',
      desc: 'We are available 24/7 for your assistance.'
    }
  ]

  const creativeForte = [
    {
      icon: <FaBook />,
      title: 'Printed Books',
      desc: 'Blend design elements, materials, and long-lasting finishes to captivate readers at first glance.',
      gradient: 'from-purple-600 to-blue-600'
    },
    {
      icon: <FaCamera />,
      title: 'Photography Book',
      desc: 'Showcase the collection\'s theme, mood, or style with our photography book covers.',
      gradient: 'from-blue-600 to-cyan-600'
    },
    {
      icon: <FaMask />,
      title: 'Comic Books',
      desc: 'Bring your heroes and stories to life with eye-catching visuals and dynamic artwork on our comic book covers.',
      gradient: 'from-cyan-600 to-teal-600'
    },
    {
      icon: <FaNewspaper />,
      title: 'Magazine',
      desc: 'We can craft visually captivating covers to entice your readers and reflect the essence of your publication.',
      gradient: 'from-teal-600 to-green-600'
    },
    {
      icon: <FaGraduationCap />,
      title: 'Year Books',
      desc: 'Capture the spirit and memories of each academic year with timeless and memorable covers.',
      gradient: 'from-green-600 to-lime-600'
    },
    {
      icon: <FaTabletAlt />,
      title: 'Ebooks',
      desc: 'Hire Book Cover Designers that will entice your readers with striking covers tailored to digital platforms.',
      gradient: 'from-lime-600 to-yellow-600'
    }
  ]

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      
      {/* ========== HERO SECTION ========== */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 z-0">
          <div className="absolute top-20 left-20 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
          <div className="absolute top-40 right-20 w-96 h-96 bg-pink-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
          <div className="absolute bottom-20 left-1/2 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-6 z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h1 
              className="text-5xl md:text-8xl font-black mb-6 leading-tight"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              Paint Your Narrative With <br />
              <span className="bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 bg-clip-text text-transparent">Professional</span>
              <br />
              Book Cover Design Services
            </motion.h1>

            <motion.p 
              className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              Are you ready to transform your manuscript into an eye-capturing masterpiece? Look no further! 
              <span className="text-purple-400 font-semibold"> Ghostwriting Squad</span>, one of the top Book Cover Design 
              Agency in USA is here to bring your story to life with Creative Book Cover Design.
            </motion.p>

            <motion.div 
              className="flex flex-col md:flex-row gap-6 justify-center items-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-5 rounded-full font-semibold text-lg hover:scale-105 transition-transform duration-300 shadow-lg hover:shadow-purple-500/50 flex items-center gap-3">
                <FaRocket /> Get Started
              </button>
              <button className="border-2 border-purple-500 text-purple-400 px-10 py-5 rounded-full font-semibold text-lg hover:bg-purple-500 hover:text-white transition-all duration-300 flex items-center gap-3">
                <FaComments /> Live Chat
              </button>
            </motion.div>

            {/* Stats */}
            <motion.div 
              className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 max-w-4xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.8 }}
            >
              {[
                { num: '1000+', label: 'Covers Designed' },
                { num: '95%', label: 'Client Satisfaction' },
                { num: '24/7', label: 'Support Available' },
                { num: '50+', label: 'Expert Designers' }
              ].map((stat, idx) => (
                <div key={idx} className="text-center">
                  <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">{stat.num}</div>
                  <div className="text-gray-400 mt-2 text-sm md:text-base">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ========== UNIQUE DESIGN SECTION ========== */}
      <section className="py-24 px-6 relative">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block bg-purple-500/20 text-purple-400 px-6 py-3 rounded-full mb-6 border border-purple-500/50">
              Book Cover Design Services
            </div>
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              A Design Which Is as <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Unique</span> As Your Story
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Looking to hire book cover designer who doesn't believe in one-size-fits-all solutions? Then you're at the right place! 
              Our team is dedicated to providing tailored Book Cover Design Services and ensuring that every design element 
              aligns perfectly with your story.
            </p>
          </motion.div>

          {/* Design Process */}
          <div className="grid md:grid-cols-2 gap-8 mt-16">
            {designProcess.map((process, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="relative bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20 group overflow-hidden"
              >
                {/* Number Badge */}
                <div className="absolute top-4 right-4 w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center font-black text-xl">
                  {index + 1}
                </div>

                {/* Icon */}
                <div className={`inline-block p-4 rounded-xl bg-gradient-to-r ${process.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <div className="text-4xl text-white">
                    {process.icon}
                  </div>
                </div>

                <h3 className="text-2xl font-bold mb-4">{process.title}</h3>
                <p className="text-gray-400 leading-relaxed">{process.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== WHY CHOOSE US SECTION ========== */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-pink-900/20"></div>
        
        <div className="container mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6 leading-tight">
              Why We Are One of the Best <br />
              <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Custom Book Covers</span> Companies?
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {whyChooseUs.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20 text-center group"
              >
                <div className="text-5xl mb-6 text-purple-500 group-hover:scale-110 transition-transform duration-300 flex justify-center">
                  {item.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            viewport={{ once: true }}
            className="flex flex-col md:flex-row gap-6 justify-center items-center"
          >
            <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-5 rounded-full font-semibold text-lg hover:scale-105 transition-transform duration-300 shadow-lg flex items-center gap-3">
              <FaRocket /> Get Started
            </button>
            <button className="border-2 border-purple-500 text-purple-400 px-10 py-5 rounded-full font-semibold text-lg hover:bg-purple-500 hover:text-white transition-all duration-300 flex items-center gap-3">
              <FaComments /> Live Chat
            </button>
          </motion.div>
        </div>
      </section>

      {/* ========== DUST JACKET SECTION ========== */}
      <section className="py-24 px-6 relative">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              Unlock Your Story's <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Style</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              With Unique Book Covers Crafted Just For You
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="inline-block bg-pink-500/20 text-pink-400 px-4 py-2 rounded-full mb-6 border border-pink-500/50">
                Premium Quality
              </div>
              
              <h3 className="text-4xl md:text-5xl font-black mb-6 leading-tight">
                Dust Jacket Cover
              </h3>
              
              <p className="text-lg text-gray-300 mb-6 leading-relaxed">
                Let your story make a grand entrance with the elegant dust jacket cover. With vibrant colors, intricate details, 
                and expert craftsmanship, our designers can help you capture your reader's attention with a captivating dust jacket cover.
              </p>

              <p className="text-lg text-gray-300 mb-8 leading-relaxed">
                Dust jacket covers are more than just protection; they are a work of art, a gateway to imagination, and a testament 
                to your storytelling power! So, are you ready to unveil your story's charm with our dust jacket covers?
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:scale-105 transition-transform duration-300 shadow-lg flex items-center justify-center gap-3">
                  <FaRocket /> Get Started
                </button>
                <button className="border-2 border-purple-500 text-purple-400 px-8 py-4 rounded-full font-semibold text-lg hover:bg-purple-500 hover:text-white transition-all duration-300 flex items-center justify-center gap-3">
                  <FaComments /> Live Chat
                </button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative w-full h-[500px] bg-gradient-to-br from-purple-600 via-pink-600 to-rose-600 rounded-2xl shadow-2xl shadow-purple-500/50 flex items-center justify-center overflow-hidden group">
                {/* Decorative Book Mockup */}
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-30"></div>
                
                <div className="relative z-10 text-center p-8">
                  <FaBook className="text-9xl text-white/80 mb-6 group-hover:scale-110 transition-transform duration-300" />
                  <h4 className="text-3xl font-black text-white">Beautiful Cover Designs</h4>
                  <p className="text-white/80 mt-4">That Tell Your Story</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ========== CREATIVE FORTE SECTION ========== */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/10 to-pink-900/10"></div>
        
        <div className="container mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block bg-pink-500/20 text-pink-400 px-6 py-3 rounded-full mb-6 border border-pink-500/50">
              Our Creative Forte
            </div>
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              We Design <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Every Type</span> of Book Cover
            </h2>
            <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
              Looking for a book cover designer for hire for your magazine or your comic or ebook? Look no further! 
              We are one of the Best Book Cover Design Agency that can bring your vision to life with eye-catching visuals 
              and innovative designs.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {creativeForte.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="relative bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20 group overflow-hidden"
              >
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
                
                <div className="relative z-10">
                  <div className={`inline-block p-4 rounded-xl bg-gradient-to-r ${item.gradient} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <div className="text-4xl text-white">
                      {item.icon}
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{item.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mt-16"
          >
            <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
              <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-5 rounded-full font-semibold text-lg hover:scale-105 transition-transform duration-300 shadow-lg flex items-center gap-3">
                <FaRocket /> Get Started
              </button>
              <button className="border-2 border-purple-500 text-purple-400 px-10 py-5 rounded-full font-semibold text-lg hover:bg-purple-500 hover:text-white transition-all duration-300 flex items-center gap-3">
                <FaComments /> Live Chat
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========== BUDGET SECTION ========== */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-pink-900/20"></div>
        
        <div className="container mx-auto relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="inline-block bg-purple-500/20 text-purple-400 px-4 py-2 rounded-full mb-6 border border-purple-500/50">
                <FaDollarSign className="inline mr-2" />
                Affordable Pricing
              </div>
              
              <h2 className="text-5xl md:text-6xl font-black mb-6 leading-tight">
                We Offer <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Budgeted</span> Book Cover Design Services In USA
              </h2>
              
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Have a story to tell, but you're on a budget? No worries! Our affordable book cover design services are at your service! 
                Our top-tier quality designers will make your cover shine brighter without you draining your wallet.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:scale-105 transition-transform duration-300 shadow-lg flex items-center justify-center gap-3">
                  <FaRocket /> Get Started
                </button>
                <button className="border-2 border-purple-500 text-purple-400 px-8 py-4 rounded-full font-semibold text-lg hover:bg-purple-500 hover:text-white transition-all duration-300 flex items-center justify-center gap-3">
                  <FaComments /> Live Chat
                </button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20">
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                    <span className="text-lg">Basic Cover Design</span>
                    <span className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">$99</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                    <span className="text-lg">Premium Cover Design</span>
                    <span className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">$199</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg">
                    <span className="text-lg font-semibold">Complete Package</span>
                    <span className="text-2xl font-bold">$349</span>
                  </div>
                </div>
                
                <div className="mt-8 pt-6 border-t border-slate-700">
                  <p className="text-gray-400 text-sm text-center">
                    ✨ All packages include unlimited revisions & source files
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ========== CTA SECTION ========== */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20"></div>
        
        <div className="container mx-auto relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              Ready to Create Your <br />
              <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Stunning Book Cover?</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-10">
              Let's transform your vision into a masterpiece that captivates readers and stands out on every shelf!
            </p>
            <div className="flex flex-col md:flex-row gap-6 justify-center">
              <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-12 py-6 rounded-full font-bold text-xl hover:scale-105 transition-transform duration-300 shadow-2xl hover:shadow-purple-500/50">
                Start Your Design Journey
              </button>
              <button className="border-2 border-purple-500 text-purple-400 px-12 py-6 rounded-full font-bold text-xl hover:bg-purple-500 hover:text-white transition-all duration-300">
                View Our Portfolio
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========== ANIMATIONS ========== */}
      <style jsx>{`
        @keyframes blob {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </main>
  )
}