'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import {
  BookOpen,
  Palette,
  TrendingUp,
  Pen,
  Edit,
  FileText,
  Globe,
  Newspaper,
  Megaphone,
  Search,
  Film,
  ArrowRight,
  Zap,
  Star,
  Check
} from 'lucide-react';

const services = [
  {
    id: 1,
    title: 'Ghostwriting',
    slug: 'ghostwriting',
    icon: Pen,
    color: 'from-red-600 to-red-800',
    description: 'Professional ghostwriters who bring your stories to life with compelling narratives and authentic voice.',
    features: ['Fiction & Non-Fiction', 'Biographies', 'Memoirs', 'Business Books'],
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&q=80',
    popular: true
  },
  {
    id: 2,
    title: 'Book Cover Design',
    slug: 'book-cover',
    icon: Palette,
    color: 'from-purple-600 to-purple-800',
    description: 'Eye-catching book covers that capture attention and reflect your story perfectly.',
    features: ['Custom Designs', 'Print & Digital', '3D Mockups', 'Unlimited Revisions'],
    image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=800&q=80',
  },
  {
    id: 3,
    title: 'Editing Services',
    slug: 'editing',
    icon: Edit,
    color: 'from-blue-600 to-blue-800',
    description: 'Comprehensive editing to polish your manuscript and make it publication-ready.',
    features: ['Developmental Editing', 'Copy Editing', 'Proofreading', 'Line Editing'],
    image: 'https://images.unsplash.com/photo-1455894127589-22f75500213a?w=800&q=80',
  },
  {
    id: 4,
    title: 'Marketing Service',
    slug: 'marketing',
    icon: TrendingUp,
    color: 'from-green-600 to-green-800',
    description: 'Strategic marketing campaigns to boost your book sales and build your author brand.',
    features: ['Social Media', 'Email Marketing', 'Amazon Ads', 'Book Launch'],
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80',
    popular: true
  },
  {
    id: 5,
    title: 'Article Writing',
    slug: 'article-writing',
    icon: FileText,
    color: 'from-orange-600 to-orange-800',
    description: 'Engaging articles that inform, educate, and captivate your target audience.',
    features: ['Blog Posts', 'News Articles', 'Features', 'How-To Guides'],
    image: 'https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?w=800&q=80',
  },
  {
    id: 6,
    title: 'Web Copywriting',
    slug: 'web-copywriting',
    icon: Globe,
    color: 'from-teal-600 to-teal-800',
    description: 'Persuasive web copy that converts visitors into customers and boosts conversions.',
    features: ['Landing Pages', 'Product Descriptions', 'About Pages', 'Sales Copy'],
    image: 'https://images.unsplash.com/photo-1432821596592-e2c18b78144f?w=800&q=80',
  },
  {
    id: 7,
    title: 'Magazine Writing',
    slug: 'magazine-writing',
    icon: Newspaper,
    color: 'from-pink-600 to-pink-800',
    description: 'Professional magazine content that engages readers and meets editorial standards.',
    features: ['Feature Articles', 'Interviews', 'Reviews', 'Opinion Pieces'],
    image: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&q=80',
  },
  {
    id: 8,
    title: 'Press Release',
    slug: 'press-release',
    icon: Megaphone,
    color: 'from-indigo-600 to-indigo-800',
    description: 'Newsworthy press releases that get media attention and build credibility.',
    features: ['Media Distribution', 'AP Style', 'News Angles', 'Follow-ups'],
    image: 'https://images.unsplash.com/photo-1504711331083-9c895941bf81?w=800&q=80',
  },
  {
    id: 9,
    title: 'SEO Writing',
    slug: 'seo-writing',
    icon: Search,
    color: 'from-yellow-600 to-yellow-800',
    description: 'Search-optimized content that ranks high and drives organic traffic to your site.',
    features: ['Keyword Research', 'Meta Descriptions', 'Content Strategy', 'Analytics'],
    image: 'https://images.unsplash.com/photo-1562577309-4932fdd64cd1?w=800&q=80',
    popular: true
  },
  {
    id: 10,
    title: 'Script Writing',
    slug: 'script-writing',
    icon: Film,
    color: 'from-red-700 to-red-900',
    description: 'Compelling scripts for video, film, podcasts, and multimedia productions.',
    features: ['Video Scripts', 'Screenplays', 'Podcast Scripts', 'YouTube Content'],
    image: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=800&q=80',
  },
];

export default function ServicesPage() {
  const popularServices = services.filter(s => s.popular);
  
  return (
    <div className="bg-white min-h-screen">
      
      {/* HERO SECTION */}
      <section className="relative py-20 lg:py-32 bg-gradient-to-br from-red-900 via-red-800 to-red-900 overflow-hidden">
        <motion.div
          animate={{ scale: [1, 1.2, 1], rotate: [0, 90, 0] }}
          transition={{ duration: 20, repeat: Infinity }}
          className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ scale: [1.2, 1, 1.2], rotate: [90, 0, 90] }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute bottom-0 left-0 w-80 h-80 bg-white/10 rounded-full blur-3xl"
        />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-xl px-6 py-3 rounded-full mb-6">
                <Zap className="w-5 h-5 text-white" />
                <span className="text-white font-bold">Our Services</span>
              </div>

              <h1 className="text-5xl lg:text-7xl font-black text-white mb-6">
                Professional Writing & Publishing Services
              </h1>

              <p className="text-xl text-white/90 mb-12">
                From ghostwriting to marketing, we offer comprehensive solutions to bring your literary dreams to life.
              </p>

              <div className="flex flex-wrap gap-4 justify-center">
                <Link href="/contact-us">
                  <motion.button
                    whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(0,0,0,0.3)' }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-white text-red-900 font-black rounded-full"
                  >
                    Get Started
                  </motion.button>
                </Link>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 border-2 border-white text-white font-bold rounded-full"
                >
                  View Pricing
                </motion.button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* POPULAR SERVICES */}
      <section className="py-20 bg-gradient-to-b from-white to-red-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-red-800 to-red-900 text-white px-6 py-3 rounded-full mb-4">
              <Star className="w-5 h-5" />
              <span className="font-bold">Most Popular</span>
            </div>
            <h2 className="text-4xl lg:text-6xl font-black text-gray-900 mb-4">
              Featured Services
            </h2>
            <p className="text-xl text-gray-600">
              Our most sought-after solutions for authors and businesses
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {popularServices.map((service, i) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="group"
                >
                  <Link href={`/services/${service.slug}`}>
                    <div className="bg-white rounded-2xl overflow-hidden shadow-2xl border-2 border-red-100 group-hover:border-red-800 transition-all h-full relative">
                      {/* Popular Badge */}
                      <div className="absolute top-4 right-4 z-10 bg-gradient-to-r from-red-800 to-red-900 text-white px-4 py-2 rounded-full text-sm font-bold">
                        Popular
                      </div>

                      {/* Image */}
                      <div className="relative h-64 overflow-hidden">
                        <motion.img
                          whileHover={{ scale: 1.1 }}
                          transition={{ duration: 0.6 }}
                          src={service.image}
                          alt={service.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                        
                        <div className={`absolute bottom-4 left-4 bg-gradient-to-br ${service.color} p-4 rounded-xl`}>
                          <Icon className="w-8 h-8 text-white" />
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-6">
                        <h3 className="text-2xl font-black text-gray-900 mb-3 group-hover:text-red-800 transition-colors">
                          {service.title}
                        </h3>

                        <p className="text-gray-600 mb-4">
                          {service.description}
                        </p>

                        {/* Features */}
                        <ul className="space-y-2 mb-6">
                          {service.features.map((feature, idx) => (
                            <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                              <Check className="w-4 h-4 text-red-800" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>

                        {/* CTA */}
                        <motion.div
                          whileHover={{ x: 5 }}
                          className="flex items-center gap-2 text-red-800 font-bold"
                        >
                          Learn More <ArrowRight className="w-5 h-5" />
                        </motion.div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ALL SERVICES GRID */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-black text-gray-900 mb-4">
              All Services
            </h2>
            <p className="text-xl text-gray-600">
              Complete solutions for every stage of your publishing journey
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {services.map((service, i) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  whileHover={{ y: -10, scale: 1.05 }}
                  className="group cursor-pointer"
                >
                  <Link href={`/services/${service.slug}`}>
                    <div className={`relative bg-gradient-to-br ${service.color} rounded-2xl p-6 text-white overflow-hidden h-full`}>
                      {/* Background Animation */}
                      <motion.div
                        animate={{
                          scale: [1, 1.5, 1],
                          opacity: [0.2, 0.4, 0.2],
                        }}
                        transition={{ duration: 5, repeat: Infinity }}
                        className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full blur-3xl"
                      />

                      <div className="relative z-10">
                        <Icon className="w-12 h-12 mb-4" />
                        <h3 className="text-xl font-black mb-2">{service.title}</h3>
                        <p className="text-white/90 text-sm mb-4 line-clamp-2">
                          {service.description}
                        </p>

                        <motion.div
                          initial={{ x: -10, opacity: 0 }}
                          whileHover={{ x: 0, opacity: 1 }}
                          className="flex items-center gap-2 font-bold"
                        >
                          Explore <ArrowRight className="w-4 h-4" />
                        </motion.div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="py-20 bg-gradient-to-b from-red-50 to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-black text-gray-900 mb-4">
              Why Choose Top Shelf Ebook?
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: BookOpen, title: '18,000+ Books Written', desc: 'Proven track record' },
              { icon: Star, title: '750+ Expert Writers', desc: 'Industry professionals' },
              { icon: TrendingUp, title: '450+ Bestsellers', desc: 'International acclaim' },
              { icon: Check, title: '100% Satisfaction', desc: 'Guaranteed quality' },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="bg-white rounded-2xl p-8 shadow-xl border-2 border-red-100 hover:border-red-800 transition-all text-center"
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-red-800 to-red-900 text-white rounded-xl mb-4">
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-black text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-red-900 via-red-800 to-red-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl lg:text-5xl font-black text-white mb-6">
              Ready to Bring Your Story to Life?
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join thousands of satisfied authors who trusted us with their publishing dreams
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/contact-us">
                <motion.button
                  whileHover={{ scale: 1.05, boxShadow: '0 30px 60px rgba(0,0,0,0.3)' }}
                  whileTap={{ scale: 0.95 }}
                  className="px-10 py-5 bg-white text-red-900 font-black rounded-full text-lg shadow-2xl"
                >
                  Get Started Now
                </motion.button>
              </Link>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 border-2 border-white text-white font-black rounded-full text-lg"
              >
                Schedule a Call
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}