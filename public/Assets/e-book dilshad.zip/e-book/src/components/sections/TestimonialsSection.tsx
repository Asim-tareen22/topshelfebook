"use client";

import React from "react";
import { motion } from "framer-motion";
import { InfiniteMovingCards } from "../ui/infinite-moving-cards";
import { BookOpen, Quote, Star, Sparkles, Award, CheckCircle2 } from "lucide-react";

export function TestimonialsSection() {
  return (
    <section className="relative py-20 lg:py-32 overflow-hidden bg-gradient-to-b from-red-950 via-red-900 to-red-950">
      
      {/* Animated Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_0%,#000,transparent)]" />
      
      {/* Animated Background Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          animate={{
            y: [0, -100, 0],
            opacity: [0, 0.6, 0],
            scale: [0, 1.5, 0],
          }}
          transition={{
            duration: 5 + Math.random() * 5,
            repeat: Infinity,
            delay: i * 0.3,
          }}
          style={{
            position: 'absolute',
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          className="w-1 h-1 bg-yellow-300/40 rounded-full pointer-events-none shadow-[0_0_10px_2px_rgba(253,224,71,0.3)]"
        />
      ))}

      {/* Floating Sparkles */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`sparkle-${i}`}
          animate={{
            rotate: [0, 360],
            scale: [1, 1.3, 1],
            opacity: [0.3, 1, 0.3],
          }}
          transition={{
            duration: 4 + Math.random() * 2,
            repeat: Infinity,
            delay: i * 0.5,
          }}
          style={{
            position: 'absolute',
            top: `${20 + Math.random() * 60}%`,
            left: `${10 + Math.random() * 80}%`,
          }}
          className="pointer-events-none"
        >
          <Sparkles className="w-4 h-4 text-yellow-300/50" />
        </motion.div>
      ))}

      {/* Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.15, 0.25, 0.15],
          x: [0, 100, 0],
        }}
        transition={{ duration: 14, repeat: Infinity }}
        className="absolute top-40 left-20 w-96 h-96 bg-red-800/30 rounded-full blur-3xl pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.2, 0.35, 0.2],
          x: [0, -100, 0],
        }}
        transition={{ duration: 16, repeat: Infinity }}
        className="absolute bottom-40 right-20 w-96 h-96 bg-yellow-600/20 rounded-full blur-3xl pointer-events-none"
      />

      {/* Header */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          {/* Badge */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            whileInView={{ scale: 1, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200, damping: 15 }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-yellow-500/20 to-red-500/20 backdrop-blur-md border-2 border-yellow-300/30 shadow-[0_0_30px_rgba(253,224,71,0.3)] mb-8"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            >
              <Award className="w-5 h-5 text-yellow-300" />
            </motion.div>
            <span className="text-white font-black text-sm tracking-widest">
              ⭐ TRUSTED BY 50,000+ READERS
            </span>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Sparkles className="w-4 h-4 text-yellow-300" />
            </motion.div>
          </motion.div>

          {/* Main Heading */}
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-5xl sm:text-6xl lg:text-7xl font-black leading-tight mb-6"
          >
            <span className="text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.3)]">
              Real Stories, Real 
            </span>
            <br />
            <motion.span
              animate={{
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
              }}
              transition={{ duration: 5, repeat: Infinity }}
              className="relative inline-block"
            >
              <span className="bg-gradient-to-r from-yellow-200 via-yellow-400 to-yellow-200 bg-clip-text text-transparent bg-[length:200%_auto] drop-shadow-[0_0_50px_rgba(253,224,71,0.5)]">
                Book Lovers
              </span>
              <motion.div
                animate={{ scaleX: [0, 1, 0] }}
                transition={{ duration: 3, repeat: Infinity, repeatDelay: 1 }}
                className="absolute bottom-2 left-0 right-0 h-2 bg-gradient-to-r from-transparent via-yellow-400 to-transparent"
              />
            </motion.span>
          </motion.h2>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-gray-200 text-lg lg:text-xl max-w-3xl mx-auto leading-relaxed"
          >
            Join thousands of satisfied readers who have transformed their reading experience with{" "}
            <span className="text-yellow-300 font-bold">TopShelf eBook</span>
          </motion.p>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="flex flex-wrap justify-center gap-8 mt-10"
          >
            {[
              { number: "50K+", label: "Happy Readers" },
              { number: "4.9/5", label: "Average Rating" },
              { number: "10K+", label: "Books Available" },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.6 + index * 0.1, type: "spring" }}
                className="text-center"
              >
                <div className="text-3xl lg:text-4xl font-black text-yellow-300 mb-1">
                  {stat.number}
                </div>
                <div className="text-sm text-gray-300">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Decorative Quote Icons */}
        <motion.div
          initial={{ opacity: 0, scale: 0, rotate: -180 }}
          whileInView={{ opacity: 0.08, scale: 1, rotate: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 1.2 }}
          className="absolute top-0 left-10 pointer-events-none hidden lg:block"
        >
          <Quote className="w-40 h-40 text-white fill-white/10" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0, rotate: 180 }}
          whileInView={{ opacity: 0.08, scale: 1, rotate: 180 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6, duration: 1.2 }}
          className="absolute top-0 right-10 pointer-events-none hidden lg:block"
        >
          <Quote className="w-40 h-40 text-white fill-white/10" />
        </motion.div>
      </div>

      {/* Infinite Moving Cards */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.7, duration: 0.8 }}
        className="relative w-full"
      >
        <InfiniteMovingCards
          items={testimonials}
          direction="right"
          speed="slow"
        />
      </motion.div>

      {/* Bottom Glow */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-yellow-500/50 to-transparent" />
    </section>
  );
}

const testimonials = [
  {
    quote:
      "TopShelf eBook has completely transformed my reading habits! The vast collection of books across all genres keeps me engaged every day. The user interface is smooth and the download speed is incredible.",
    name: "Sarah Johnson",
    title: "Book Enthusiast",
    rating: 5,
    image: "SJ",
    color: "from-pink-500 to-rose-500",
    books: 127,
  },
  {
    quote:
      "I've been using TopShelf eBook for over a year now, and I'm amazed by the quality of content. From classic literature to modern bestsellers, everything is just a click away. The multi-device sync feature is a game-changer!",
    name: "Michael Chen",
    title: "Digital Reader",
    rating: 5,
    image: "MC",
    color: "from-blue-500 to-cyan-500",
    books: 203,
  },
  {
    quote:
      "As an avid reader, I've tried many eBook platforms, but TopShelf stands out from the rest. The curated collections, regular updates, and exclusive releases make it worth every penny. My personal library has never looked better!",
    name: "Emily Rodriguez",
    title: "Literature Professor",
    rating: 5,
    image: "ER",
    color: "from-purple-500 to-violet-500",
    books: 412,
  },
  {
    quote:
      "TopShelf eBook's customer service is exceptional! They helped me set up my account and recommended books based on my interests. The reading experience is seamless across all my devices.",
    name: "David Thompson",
    title: "Tech Professional",
    rating: 5,
    image: "DT",
    color: "from-orange-500 to-amber-500",
    books: 89,
  },
  {
    quote:
      "The variety of books available on TopShelf is mind-blowing! From self-help to science fiction, mystery to romance - they have it all. The offline reading feature lets me enjoy books even during my commute.",
    name: "Jennifer Martinez",
    title: "Content Writer",
    rating: 5,
    image: "JM",
    color: "from-green-500 to-emerald-500",
    books: 156,
  },
  {
    quote:
      "I discovered TopShelf eBook last month and I'm already hooked! The personalized recommendations are spot-on, and the bookmark sync feature means I can start reading on my phone and continue on my tablet seamlessly.",
    name: "Robert Williams",
    title: "Business Owner",
    rating: 5,
    image: "RW",
    color: "from-red-500 to-pink-500",
    books: 64,
  },
];