'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import Link from 'next/link';
import {
  Calendar,
  Clock,
  ArrowRight,
  Tag,
  User,
  Search,
  Filter,
  BookOpen,
  TrendingUp,
  Star,
  Eye
} from 'lucide-react';

// Blog Data
const blogPosts = [
  {
    id: 1,
    title: 'The Ultimate Guide to Self-Publishing Your First eBook',
    excerpt: 'Discover the step-by-step process of turning your manuscript into a published eBook that reaches thousands of readers worldwide.',
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&q=80',
    category: 'Publishing',
    author: 'Sarah Johnson',
    date: '15 Mar 2024',
    readTime: '8 min read',
    views: '2.5K',
    featured: true,
  },
  {
    id: 2,
    title: 'How to Write Compelling Characters That Readers Love',
    excerpt: 'Learn the secrets of creating memorable characters that resonate with your audience and keep them turning pages.',
    image: 'https://images.unsplash.com/photo-1513001900722-370f803f498d?w=800&q=80',
    category: 'Writing Tips',
    author: 'Michael Chen',
    date: '12 Mar 2024',
    readTime: '6 min read',
    views: '3.1K',
    featured: true,
  },
  {
    id: 3,
    title: 'Marketing Your eBook: Strategies That Actually Work',
    excerpt: 'Proven marketing tactics to boost your eBook sales and build a loyal reader base in today\'s competitive market.',
    image: 'https://images.unsplash.com/photo-1432821596592-e2c18b78144f?w=800&q=80',
    category: 'Marketing',
    author: 'Emily Rodriguez',
    date: '10 Mar 2024',
    readTime: '10 min read',
    views: '1.8K',
    featured: false,
  },
  {
    id: 4,
    title: 'The Art of Ghostwriting: Behind the Scenes',
    excerpt: 'An inside look at the ghostwriting process and how professional writers bring your ideas to life.',
    image: 'https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?w=800&q=80',
    category: 'Ghostwriting',
    author: 'David Wilson',
    date: '08 Mar 2024',
    readTime: '7 min read',
    views: '2.2K',
    featured: false,
  },
  {
    id: 5,
    title: 'Book Cover Design Trends for 2024',
    excerpt: 'Stay ahead of the curve with the latest design trends that are capturing readers\' attention this year.',
    image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=800&q=80',
    category: 'Design',
    author: 'Lisa Anderson',
    date: '05 Mar 2024',
    readTime: '5 min read',
    views: '4.3K',
    featured: true,
  },
  {
    id: 6,
    title: 'From Idea to Bestseller: A Success Story',
    excerpt: 'How one author went from a simple idea to hitting the bestseller list with our ghostwriting services.',
    image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=800&q=80',
    category: 'Success Stories',
    author: 'James Parker',
    date: '02 Mar 2024',
    readTime: '12 min read',
    views: '5.7K',
    featured: false,
  },
  {
    id: 7,
    title: 'Editing Tips: Polish Your Manuscript Like a Pro',
    excerpt: 'Professional editing techniques to transform your rough draft into a polished, publication-ready manuscript.',
    image: 'https://images.unsplash.com/photo-1455894127589-22f75500213a?w=800&q=80',
    category: 'Writing Tips',
    author: 'Rachel Green',
    date: '28 Feb 2024',
    readTime: '9 min read',
    views: '1.9K',
    featured: false,
  },
  {
    id: 8,
    title: 'Amazon KDP vs Traditional Publishing: Which to Choose?',
    excerpt: 'A comprehensive comparison to help you decide the best publishing path for your book.',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&q=80',
    category: 'Publishing',
    author: 'Tom Harris',
    date: '25 Feb 2024',
    readTime: '11 min read',
    views: '3.6K',
    featured: false,
  },
  {
    id: 9,
    title: 'Building Your Author Brand on Social Media',
    excerpt: 'Essential social media strategies to grow your audience and establish yourself as an authority.',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&q=80',
    category: 'Marketing',
    author: 'Nina Patel',
    date: '22 Feb 2024',
    readTime: '8 min read',
    views: '2.8K',
    featured: false,
  },
];

const categories = ['All', 'Publishing', 'Writing Tips', 'Marketing', 'Ghostwriting', 'Design', 'Success Stories'];

export default function BlogsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredBlogs = blogPosts.filter(blog => {
    const matchesCategory = selectedCategory === 'All' || blog.category === selectedCategory;
    const matchesSearch = blog.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         blog.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredBlogs = blogPosts.filter(blog => blog.featured);

  return (
    <div className="bg-white min-h-screen">
      
      {/* ============================================
          HERO SECTION
      ============================================ */}
      <section className="relative py-20 lg:py-32 bg-gradient-to-br from-red-900 via-red-800 to-red-900 overflow-hidden">
        {/* Animated Background */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{ duration: 20, repeat: Infinity }}
          className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [90, 0, 90],
          }}
          transition={{ duration: 15, repeat: Infinity }}
          className="absolute bottom-0 left-0 w-80 h-80 bg-white/10 rounded-full blur-3xl"
        />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-xl px-6 py-3 rounded-full mb-6">
                <BookOpen className="w-5 h-5 text-white" />
                <span className="text-white font-bold">Our Blog</span>
              </div>

              <h1 className="text-5xl lg:text-7xl font-black text-white mb-6">
                Stories, Tips & Insights
              </h1>

              <p className="text-xl text-white/90 mb-12">
                Discover expert advice, success stories, and the latest trends in eBook writing, publishing, and marketing.
              </p>

              {/* Search Bar */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="max-w-2xl mx-auto"
              >
                <div className="relative">
                  <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search articles..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-14 pr-6 py-5 rounded-2xl bg-white/95 backdrop-blur-xl text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-4 focus:ring-white/50 transition-all"
                  />
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ============================================
          CATEGORIES FILTER
      ============================================ */}
      <section className="sticky top-0 z-40 bg-white/95 backdrop-blur-xl border-b border-gray-200 py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-hide">
            <Filter className="w-5 h-5 text-gray-600 flex-shrink-0" />
            {categories.map((category, i) => (
              <motion.button
                key={category}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2.5 rounded-full font-semibold whitespace-nowrap transition-all ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-red-800 to-red-900 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================
          FEATURED POSTS
      ============================================ */}
      <section className="py-20 bg-gradient-to-b from-white to-red-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-red-800 to-red-900 text-white px-6 py-3 rounded-full mb-4">
              <Star className="w-5 h-5" />
              <span className="font-bold">Featured Articles</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900">
              Editor's Picks
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {featuredBlogs.slice(0, 3).map((blog, i) => (
              <motion.div
                key={blog.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -10 }}
                className="group cursor-pointer"
              >
                <div className="bg-white rounded-2xl overflow-hidden shadow-xl border-2 border-red-100 group-hover:border-red-800 transition-all">
                  {/* Image */}
                  <div className="relative h-64 overflow-hidden">
                    <motion.img
                      whileHover={{ scale: 1.1 }}
                      transition={{ duration: 0.6 }}
                      src={blog.image}
                      alt={blog.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    
                    {/* Category Badge */}
                    <div className="absolute top-4 left-4">
                      <span className="bg-gradient-to-r from-red-800 to-red-900 text-white px-4 py-2 rounded-full text-sm font-bold">
                        {blog.category}
                      </span>
                    </div>

                    {/* Views */}
                    <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-black/50 backdrop-blur-xl px-3 py-1.5 rounded-full">
                      <Eye className="w-4 h-4 text-white" />
                      <span className="text-white text-sm font-semibold">{blog.views}</span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="text-2xl font-black text-gray-900 mb-3 group-hover:text-red-800 transition-colors line-clamp-2">
                      {blog.title}
                    </h3>

                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {blog.excerpt}
                    </p>

                    {/* Meta Info */}
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span>{blog.author}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>{blog.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{blog.readTime}</span>
                        </div>
                      </div>
                    </div>

                    {/* Read More Button */}
                    <motion.button
                      whileHover={{ x: 5 }}
                      className="flex items-center gap-2 text-red-800 font-bold group-hover:gap-4 transition-all"
                    >
                      Read More <ArrowRight className="w-5 h-5" />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================
          ALL BLOG POSTS
      ============================================ */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl lg:text-5xl font-black text-gray-900 mb-4">
              Latest Articles
            </h2>
            <p className="text-xl text-gray-600">
              {filteredBlogs.length} articles found
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredBlogs.map((blog, i) => (
              <motion.div
                key={blog.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group cursor-pointer"
              >
                <div className="bg-white rounded-2xl overflow-hidden shadow-lg border border-gray-200 group-hover:shadow-2xl group-hover:border-red-800 transition-all h-full flex flex-col">
                  {/* Image */}
                  <div className="relative h-56 overflow-hidden">
                    <motion.img
                      whileHover={{ scale: 1.1 }}
                      transition={{ duration: 0.6 }}
                      src={blog.image}
                      alt={blog.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    
                    {/* Category Badge */}
                    <div className="absolute top-3 left-3">
                      <span className="inline-flex items-center gap-1 bg-white/95 backdrop-blur-xl px-3 py-1.5 rounded-full text-xs font-bold text-red-800">
                        <Tag className="w-3 h-3" />
                        {blog.category}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-xl font-black text-gray-900 mb-2 group-hover:text-red-800 transition-colors line-clamp-2">
                      {blog.title}
                    </h3>

                    <p className="text-gray-600 mb-4 line-clamp-2 flex-1">
                      {blog.excerpt}
                    </p>

                    {/* Meta Info */}
                    <div className="flex items-center justify-between text-xs text-gray-500 pt-4 border-t border-gray-100">
                      <span className="font-semibold">{blog.author}</span>
                      <div className="flex items-center gap-3">
                        <span>{blog.date}</span>
                        <span>•</span>
                        <span>{blog.readTime}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* No Results */}
          {filteredBlogs.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-20"
            >
              <div className="inline-flex items-center justify-center w-20 h-20 bg-red-100 rounded-full mb-6">
                <Search className="w-10 h-10 text-red-800" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">No articles found</h3>
              <p className="text-gray-600 mb-6">Try adjusting your search or filter to find what you're looking for.</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                }}
                className="px-6 py-3 bg-gradient-to-r from-red-800 to-red-900 text-white font-bold rounded-full hover:shadow-xl transition-all"
              >
                Clear Filters
              </button>
            </motion.div>
          )}
        </div>
      </section>

      {/* ============================================
          NEWSLETTER CTA
      ============================================ */}
      <section className="py-20 bg-gradient-to-r from-red-900 via-red-800 to-red-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center text-white"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 backdrop-blur-xl rounded-full mb-6">
              <TrendingUp className="w-8 h-8" />
            </div>

            <h2 className="text-4xl lg:text-5xl font-black mb-4">
              Never Miss an Update
            </h2>

            <p className="text-xl text-white/90 mb-8">
              Subscribe to our newsletter and get the latest writing tips, publishing insights, and exclusive offers delivered to your inbox.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-6 py-4 rounded-full text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-4 focus:ring-white/50"
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white text-red-900 font-black rounded-full hover:shadow-2xl transition-all"
              >
                Subscribe
              </motion.button>
            </div>

            <p className="text-sm text-white/70 mt-4">
              Join 10,000+ authors who get our weekly insights
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}