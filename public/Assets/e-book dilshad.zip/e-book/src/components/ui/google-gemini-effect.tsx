'use client';

import React from 'react';
import { motion, MotionValue } from 'framer-motion';
import { cn } from '@/lib/utils';

export const GoogleGeminiEffect = React.forwardRef<
  HTMLDivElement,
  {
    pathLengths: MotionValue<number>[];
    className?: string;
    duration?: number;
  }
>(({ pathLengths, className, duration = 0.5 }, ref) => {
  const svgRef = React.useRef<SVGSVGElement>(null);

  return (
    <div ref={ref} className={cn('relative w-full h-full', className)}>
      <svg
        ref={svgRef}
        viewBox="0 0 1200 800"
        className="absolute inset-0 w-full h-full"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#dc2626" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#991b1b" stopOpacity="0.3" />
          </linearGradient>
          <linearGradient id="gradient2" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#b91c1c" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#7f1d1d" stopOpacity="0.2" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="4" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* First Path - Red */}
        <motion.path
          d="M 0,400 Q 300,200 600,150 T 1200,300"
          stroke="url(#gradient1)"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          filter="url(#glow)"
          style={{
            pathLength: pathLengths[0],
          }}
          initial={{ pathLength: 0 }}
        />

        {/* Second Path - Dark Red */}
        <motion.path
          d="M 0,450 Q 300,250 600,200 T 1200,350"
          stroke="url(#gradient2)"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          filter="url(#glow)"
          style={{
            pathLength: pathLengths[1],
          }}
          initial={{ pathLength: 0 }}
        />

        {/* Third Path - Red with opacity */}
        <motion.path
          d="M 0,500 Q 300,300 600,250 T 1200,400"
          stroke="#dc2626"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
          opacity="0.6"
          filter="url(#glow)"
          style={{
            pathLength: pathLengths[2],
          }}
          initial={{ pathLength: 0 }}
        />

        {/* Fourth Path - Accent */}
        <motion.path
          d="M 0,550 Q 300,350 600,300 T 1200,450"
          stroke="#b91c1c"
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
          opacity="0.5"
          filter="url(#glow)"
          style={{
            pathLength: pathLengths[3],
          }}
          initial={{ pathLength: 0 }}
        />

        {/* Fifth Path - Subtle */}
        <motion.path
          d="M 0,600 Q 300,400 600,350 T 1200,500"
          stroke="#991b1b"
          strokeWidth="1"
          fill="none"
          strokeLinecap="round"
          opacity="0.4"
          filter="url(#glow)"
          style={{
            pathLength: pathLengths[4],
          }}
          initial={{ pathLength: 0 }}
        />

        {/* Animated circles/nodes */}
        <motion.circle
          cx="600"
          cy="150"
          r="8"
          fill="#dc2626"
          filter="url(#glow)"
          animate={{
            r: [8, 12, 8],
            opacity: [1, 0.8, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        />

        <motion.circle
          cx="1200"
          cy="300"
          r="6"
          fill="#b91c1c"
          filter="url(#glow)"
          animate={{
            r: [6, 10, 6],
            opacity: [0.8, 0.6, 0.8],
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
          }}
        />
      </svg>
    </div>
  );
});

GoogleGeminiEffect.displayName = 'GoogleGeminiEffect';