'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import {
  Pen,
  BookOpen,
  Check,
  Star,
  Users,
  Award,
  Zap,
  ArrowRight
} from 'lucide-react';

const features = [
  { icon: BookOpen, title: 'Fiction & Non-Fiction', desc: 'Expert writers for all genres' },
  { icon: Users, title: 'Biographies & Memoirs', desc: 'Your life story, professionally told' },
  { icon: Award, title: 'Business Books', desc: 'Establish your authority' },
  { icon: Star, title: 'Self-Help & Motivational', desc: 'Inspire and empower readers' },
];

const packages = [
  {
    name: 'Starter',
    price: '$2,999',
    features: [
      'Up to 20,000 words',
      '1 Genre',
      'Basic Research',
      '2 Revisions',
      '30-Day Delivery'
    ],
    color: 'from-blue-600 to-blue-800'
  },
  {
    name: 'Professional',
    price: '$7,999',
    features: [
      'Up to 50,000 words',
      'Any Genre',
      'In-depth Research',
      'Unlimited Revisions',
      '60-Day Delivery',
      'Free Editing'
    ],
    color: 'from-red-600 to-red-900',
    popular: true
  },
  {
    name: 'Premium',
    price: '$15,999',
    features: [
      'Up to 100,000 words',
      'Multiple Genres',
      'Extensive Research',
      'Unlimited Revisions',
      '90-Day Delivery',
      'Free Editing & Formatting',
      'Marketing Consultation'
    ],
    color: 'from-purple-600 to-purple-900'
  },
];

export default function GhostwritingPage() {
  return (
    <div className="bg-white min-h-screen">
      
      {/* HERO */}
      <section className="relative py-20 lg:py-32 bg-gradient-to-br from-red-900 via-red-800 to-red-900 overflow-hidden">
        <motion.div
          animate={{ scale: [1, 1.2, 1], rotate: [0, 90, 0] }}
          transition={{ duration: 20, repeat: Infinity }}
          className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl"
        />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-xl px-6 py-3 rounded-full mb-6">
                <Pen className="w-5 h-5 text-white" />
                <span className="text-white font-bold">Ghostwriting Services</span>
              </div>

              <h1 className="text-5xl lg:text-7xl font-black text-white mb-6">
                Your Story, Our Expertise
              </h1>

              <p className="text-xl text-white/90 mb-8">
                Professional ghostwriters who transform your ideas into bestselling books. We write, you shine.
              </p>

              <div className="flex flex-wrap gap-4">
                <Link href="/contact">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-white text-red-900 font-black rounded-full"
                  >
                    Start Your Book
                  </motion.button>
                </Link>
                <Link href="/services">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 border-2 border-white text-white font-bold rounded-full"
                  >
                    All Services
                  </motion.button>
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
            >
              <img
                src="https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&q=80"
                alt="Ghostwriting"
                className="rounded-2xl shadow-2xl"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-20 bg-gradient-to-b from-white to-red-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-black text-gray-900 mb-4">
              What We Write
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="bg-white rounded-2xl p-8 shadow-xl border-2 border-red-100 hover:border-red-800 transition-all text-center"
                >
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-red-800 to-red-900 text-white rounded-xl mb-4">
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-black text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-black text-gray-900 mb-4">
              Pricing Packages
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {packages.map((pkg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="relative"
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-red-800 to-red-900 text-white px-6 py-2 rounded-full font-bold text-sm z-10">
                    Most Popular
                  </div>
                )}

                <div className={`bg-gradient-to-br ${pkg.color} rounded-2xl p-8 text-white h-full ${pkg.popular ? 'border-4 border-red-800' : ''}`}>
                  <h3 className="text-2xl font-black mb-2">{pkg.name}</h3>
                  <div className="text-5xl font-black mb-6">{pkg.price}</div>

                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Check className="w-5 h-5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Link href="/contact">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="w-full py-4 bg-white text-red-900 font-black rounded-full"
                    >
                      Choose Plan
                    </motion.button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-red-900 via-red-800 to-red-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl lg:text-5xl font-black text-white mb-6">
              Ready to Write Your Bestseller?
            </h2>
            <Link href="/contact">
              <motion.button
                whileHover={{ scale: 1.05 }}
                className="px-10 py-5 bg-white text-red-900 font-black rounded-full text-lg shadow-2xl"
              >
                Get Started Today
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}