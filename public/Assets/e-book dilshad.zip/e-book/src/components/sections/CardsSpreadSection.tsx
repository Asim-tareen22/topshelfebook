'use client';

import React, { useEffect, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Sparkles } from "lucide-react";
import Image from "next/image";
import { useRef } from "react";

export function CardsSpreadSection() {
  const [isSpread, setIsSpread] = useState(false);
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.3 });

  // Trigger spread when section comes in view
  useEffect(() => {
    if (isInView) {
      const timer = setTimeout(() => {
        setIsSpread(true);
      }, 1500); // Cards fall first, then spread
      return () => clearTimeout(timer);
    }
  }, [isInView]);

  const books = [
    { 
      id: 1, 
      name: "The Midnight Library", 
      author: "Matt Haig",
      image: "/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg",
      color: "from-purple-600 to-purple-900" 
    },
    { 
      id: 2, 
      name: "Atomic Habits", 
      author: "James Clear",
      image: "/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg",
      color: "from-blue-600 to-blue-900" 
    },
    { 
      id: 3, 
      name: "The Silent Patient", 
      author: "Alex Michaelides",
      image: "/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg",
      color: "from-red-600 to-red-900" 
    },
    { 
      id: 4, 
      name: "Where the Crawdads Sing", 
      author: "Delia Owens",
      image: "/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg",
      color: "from-green-600 to-green-900" 
    },
    { 
      id: 5, 
      name: "Becoming", 
      author: "Michelle Obama",
      image: "/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg",
      color: "from-yellow-600 to-yellow-900" 
    },
    { 
      id: 6, 
      name: "Educated", 
      author: "Tara Westover",
      image: "/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg",
      color: "from-pink-600 to-pink-900" 
    },
  ];

  // Wave positions - top left to bottom right
  const getWavePosition = (index: number, isSpread: boolean) => {
    if (!isSpread) {
      return { x: 0, y: 0, rotate: 0 };
    }

    // Wave pattern coordinates (top-left to bottom-right)
    const wavePositions = [
      { x: -240, y: -200, rotate: -10 },  // Top-left
      { x: -150, y: -100, rotate: -6 },   
      { x: -60, y: 0, rotate: -3 },       
      { x: 60, y: 60, rotate: 3 },        
      { x: 150, y: 140, rotate: 6 },      
      { x: 240, y: 220, rotate: 10 },     // Bottom-right
    ];

    return wavePositions[index] || { x: 0, y: 0, rotate: 0 };
  };

  return (
    <section 
      ref={sectionRef}
      className="relative min-h-screen overflow-hidden flex items-center py-20" 
      style={{ backgroundColor: '#FFFAE8' }}
    >
      
      {/* Animated Background Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          animate={{
            y: [0, -60, 0],
            opacity: [0, 0.5, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 5 + Math.random() * 3,
            repeat: Infinity,
            delay: i * 0.3,
          }}
          style={{
            position: 'absolute',
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          className="w-2 h-2 bg-red-900/20 rounded-full pointer-events-none"
        />
      ))}

      {/* Gradient Orbs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.2, 0.4, 0.2],
          x: [0, 60, 0],
        }}
        transition={{ duration: 10, repeat: Infinity }}
        className="absolute top-40 left-20 w-80 h-80 bg-gradient-to-r from-red-200/30 to-orange-200/30 rounded-full blur-3xl pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.3, 0.5, 0.3],
          x: [0, -60, 0],
        }}
        transition={{ duration: 12, repeat: Infinity }}
        className="absolute bottom-40 right-20 w-80 h-80 bg-gradient-to-r from-yellow-200/30 to-red-200/30 rounded-full blur-3xl pointer-events-none"
      />

      {/* Main Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          {/* Left Side - Content */}
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 1, type: "spring" }}
            className="space-y-8 z-10"
          >
            {/* Badge */}
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={isInView ? { scale: 1, rotate: 0 } : {}}
              transition={{ delay: 0.2, type: 'spring', damping: 10 }}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-red-900/80 to-red-950/80 border-2 border-red-800/60 shadow-xl"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="w-5 h-5 text-yellow-300" />
              </motion.div>
              <span className="text-white font-black text-sm tracking-wide">
                FEATURED COLLECTION
              </span>
            </motion.div>

            {/* Main Heading */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              <motion.h1
                className="text-5xl sm:text-6xl lg:text-7xl font-black leading-tight"
              >
                <span className="text-gray-900">Discover Your </span>
                <motion.span
                  animate={{
                    backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                  className="bg-gradient-to-r from-red-800 via-red-600 to-red-900 bg-clip-text text-transparent bg-[length:200%_auto]"
                >
                  Next Favorite
                </motion.span>
              </motion.h1>
            </motion.div>

            {/* Description */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="space-y-4"
            >
              <p className="text-gray-700 text-lg lg:text-xl leading-relaxed">
                Explore our handpicked collection of bestselling books.
              </p>
              <p className="text-gray-700 text-lg lg:text-xl leading-relaxed">
                From gripping thrillers to life-changing self-help guides.
              </p>
              <p className="text-gray-700 text-lg lg:text-xl leading-relaxed">
                Each book carefully selected to inspire and entertain.
              </p>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.6 }}
              className="flex items-center gap-8"
            >
              <div>
                <h3 className="text-4xl font-black text-red-900">6</h3>
                <p className="text-gray-600 text-sm font-semibold">Featured Books</p>
              </div>
              <div>
                <h3 className="text-4xl font-black text-red-900">4.9★</h3>
                <p className="text-gray-600 text-sm font-semibold">Average Rating</p>
              </div>
            </motion.div>

            {/* Progress Indicator */}
            {isInView && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="flex items-center gap-3"
              >
                <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 2, delay: 1 }}
                    className="h-full bg-gradient-to-r from-red-800 to-red-600"
                  />
                </div>
                <span className="text-sm font-bold text-gray-600">Loading Collection...</span>
              </motion.div>
            )}
          </motion.div>

          {/* Right Side - Card Fall & Wave Animation */}
          <div className="relative h-[750px] flex items-center justify-center z-10">
            {/* Cards Container */}
            <div className="relative w-full h-full flex items-center justify-center">
              {books.map((book, index) => {
                const wavePos = getWavePosition(index, isSpread);
                
                return (
                  <motion.div
                    key={book.id}
                    // Initial: Cards above screen
                    initial={{ 
                      x: 0,
                      y: -800,
                      rotate: Math.random() * 360 - 180,
                      scale: 0.5,
                      opacity: 0,
                    }}
                    // Fall animation when in view
                    animate={isInView ? {
                      // First fall to center
                      y: isSpread ? wavePos.y : 0,
                      x: isSpread ? wavePos.x : 0,
                      rotate: isSpread ? wavePos.rotate : 0,
                      scale: 1,
                      opacity: 1,
                    } : {}}
                    transition={{
                      // Fall effect with bounce
                      type: "spring",
                      stiffness: 100,
                      damping: isSpread ? 20 : 12,
                      mass: 1,
                      delay: isInView ? index * 0.1 : 0,
                      duration: 1.5,
                    }}
                    whileHover={{
                      scale: 1.25,
                      rotate: 0,
                      y: wavePos.y - 30,
                      zIndex: 50,
                      transition: { 
                        type: "spring",
                        stiffness: 300,
                        damping: 15
                      }
                    }}
                    className="absolute cursor-pointer"
                    style={{
                      zIndex: isSpread ? 10 + index : 20 - index,
                    }}
                  >
                    {/* Square Card with Image */}
                    <motion.div 
                      className="w-72 h-72 bg-white rounded-3xl shadow-2xl border-4 border-white overflow-hidden relative group"
                      whileHover={{
                        boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.5)",
                      }}
                    >
                      
                      {/* Book Cover Image - Full Size */}
                      <div className="relative w-full h-full">
                        <Image
                          src={book.image}
                          alt={book.name}
                          fill
                          className="object-cover transition-transform duration-500 group-hover:scale-110"
                          priority
                        />

                        {/* Gradient Overlay for Text Visibility */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                        {/* Shine Effect */}
                        <motion.div
                          animate={{ x: ['-100%', '200%'] }}
                          transition={{
                            duration: 3,
                            repeat: Infinity,
                            repeatDelay: 5,
                            delay: index * 0.3,
                          }}
                          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12 pointer-events-none"
                        />

                        {/* Book Title Overlay (Visible on Hover) */}
                        <motion.div 
                          className="absolute inset-0 flex flex-col items-center justify-end p-6 opacity-0 group-hover:opacity-100 transition-all duration-300"
                          initial={{ y: 20 }}
                          whileHover={{ y: 0 }}
                        >
                          <h3 className="text-white font-black text-2xl text-center mb-2 drop-shadow-2xl">
                            {book.name}
                          </h3>
                          <p className="text-white/90 font-semibold text-base text-center drop-shadow-lg">
                            by {book.author}
                          </p>
                        </motion.div>

                        {/* TopShelf Badge */}
                        <motion.div 
                          className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg"
                          whileHover={{ scale: 1.1 }}
                        >
                          <span className="text-red-900 font-black text-xs">TopShelf</span>
                        </motion.div>

                        {/* Rating Badge */}
                        <motion.div 
                          className="absolute bottom-4 left-4 bg-gray-900/90 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2 shadow-lg"
                          whileHover={{ scale: 1.1 }}
                        >
                          <span className="text-yellow-400 text-base">★</span>
                          <span className="text-white font-bold text-sm">4.9</span>
                        </motion.div>

                        {/* Glow effect on hover */}
                        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                          <div className={`absolute inset-0 bg-gradient-to-br ${book.color} opacity-20 blur-xl`} />
                        </div>
                      </div>
                    </motion.div>

                    {/* Floating Name Label (Enhanced) */}
                    <motion.div
                      initial={{ opacity: 0, y: 20, scale: 0.8 }}
                      whileHover={{ opacity: 1, y: -30, scale: 1 }}
                      className="absolute -top-28 left-1/2 -translate-x-1/2 bg-gradient-to-r from-gray-900 to-gray-800 text-white px-8 py-4 rounded-2xl shadow-2xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all pointer-events-none z-50 border-2 border-white/10"
                    >
                      <p className="font-black text-lg mb-1">{book.name}</p>
                      <p className="font-medium text-sm text-gray-300">by {book.author}</p>
                      <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-gray-900 rotate-45 border-r-2 border-b-2 border-white/10" />
                    </motion.div>
                  </motion.div>
                );
              })}
            </div>

            {/* Falling particles effect */}
            {isInView && [...Array(10)].map((_, i) => (
              <motion.div
                key={`fall-particle-${i}`}
                initial={{ 
                  y: -100,
                  x: Math.random() * 400 - 200,
                  opacity: 1,
                  scale: Math.random() * 0.5 + 0.5
                }}
                animate={{
                  y: 700,
                  opacity: 0,
                }}
                transition={{
                  duration: 2,
                  delay: i * 0.1,
                  ease: "easeIn"
                }}
                className="absolute w-2 h-2 bg-red-900/30 rounded-full pointer-events-none"
              />
            ))}
          </div>

        </div>
      </div>

      {/* Bottom indicator */}
      {isInView && isSpread && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.5 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-center"
        >
          <p className="text-gray-600 text-sm font-semibold mb-2">Hover to explore</p>
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="text-red-900"
          >
            <svg className="w-6 h-6 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </motion.div>
        </motion.div>
      )}

    </section>
  );
}