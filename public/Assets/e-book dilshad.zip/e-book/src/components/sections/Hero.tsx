'use client';

import { motion, useMotionValue, useTransform, useSpring } from 'framer-motion';
import { useState, useEffect, useRef } from 'react';
import { 
  ArrowRight, 
  BookOpen, 
  Sparkles, 
  Star, 
  Zap,
  Download,
  Play,
  TrendingUp,
  Users,
  Award
} from 'lucide-react';
import Image from 'next/image';

export function Hero() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  // Mouse tracking for parallax
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect();
        setMousePosition({
          x: (e.clientX - rect.left - rect.width / 2) / 20,
          y: (e.clientY - rect.top - rect.height / 2) / 20,
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section 
      ref={heroRef}
      className="relative min-h-screen overflow-hidden flex items-center"
      style={{ backgroundColor: '#0A0A0A' }}
    >
      {/* Animated Grid Background */}
      <div className="absolute inset-0 opacity-20">
        <div 
          className="absolute inset-0" 
          style={{
            backgroundImage: `
              linear-gradient(to right, #7f1d1d 1px, transparent 1px),
              linear-gradient(to bottom, #7f1d1d 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Floating Particles */}
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          animate={{
            y: [0, -1000],
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 8 + Math.random() * 10,
            repeat: Infinity,
            delay: i * 0.2,
            ease: 'linear',
          }}
          style={{
            position: 'absolute',
            left: `${Math.random() * 100}%`,
            bottom: -10,
          }}
          className="w-1 h-1 bg-red-500 rounded-full"
        />
      ))}

      {/* Morphing Blobs */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360],
          borderRadius: ['30% 70% 70% 30%', '70% 30% 30% 70%', '30% 70% 70% 30%'],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: 'linear',
        }}
        className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-r from-red-900/30 to-orange-900/30 blur-3xl"
      />
      <motion.div
        animate={{
          scale: [1.2, 1, 1.2],
          rotate: [360, 180, 0],
          borderRadius: ['70% 30% 30% 70%', '30% 70% 70% 30%', '70% 30% 30% 70%'],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: 'linear',
        }}
        className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-yellow-900/30 to-red-900/30 blur-3xl"
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Side - Content */}
          <div className="space-y-8">
            
            {/* Floating Badge */}
            <motion.div
              initial={{ opacity: 0, y: -50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, type: 'spring' }}
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-red-900/80 to-red-800/80 backdrop-blur-xl rounded-full border-2 border-red-700/50 shadow-2xl"
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                >
                  <Sparkles className="w-5 h-5 text-yellow-300" />
                </motion.div>
                <span className="text-white font-black text-sm tracking-wider">
                  #1 DIGITAL LIBRARY PLATFORM
                </span>
                <motion.div
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <TrendingUp className="w-4 h-4 text-green-400" />
                </motion.div>
              </motion.div>
            </motion.div>

            {/* Animated Heading */}
            <div className="space-y-4">
              <motion.h1
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-6xl sm:text-7xl lg:text-8xl font-black leading-none"
              >
                {/* Animated Words */}
                <motion.span
                  className="block text-white"
                  initial={{ x: -100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.4, type: 'spring', stiffness: 100 }}
                >
                  Discover
                </motion.span>
                
                <motion.span
                  className="block mt-2"
                  initial={{ x: 100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
                >
                  <motion.span
                    animate={{
                      backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                    }}
                    transition={{ duration: 5, repeat: Infinity }}
                    className="bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 bg-clip-text text-transparent bg-[length:200%_auto]"
                  >
                    Endless
                  </motion.span>
                </motion.span>

                <motion.span
                  className="block mt-2 text-white"
                  initial={{ x: -100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.6, type: 'spring', stiffness: 100 }}
                >
                  Stories
                </motion.span>
              </motion.h1>

              {/* Typing Effect Subheading */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="text-xl md:text-2xl text-gray-400 font-semibold max-w-xl"
              >
                Access 10,000+ premium eBooks. Read anywhere, anytime. 
                <motion.span
                  animate={{ opacity: [1, 0] }}
                  transition={{ duration: 0.8, repeat: Infinity }}
                  className="inline-block ml-1 w-0.5 h-6 bg-red-500"
                />
              </motion.p>
            </div>

            {/* Stats Row */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1 }}
              className="flex items-center gap-8 flex-wrap"
            >
              {[
                { value: '10K+', label: 'Books', icon: BookOpen },
                { value: '50K+', label: 'Readers', icon: Users },
                { value: '4.9', label: 'Rating', icon: Star },
              ].map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.1, y: -5 }}
                    className="flex items-center gap-3"
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-900 to-red-800 flex items-center justify-center shadow-xl">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-3xl font-black text-white">{stat.value}</p>
                      <p className="text-sm text-gray-400 font-semibold">{stat.label}</p>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              {/* Primary Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onHoverStart={() => setIsHovered(true)}
                onHoverEnd={() => setIsHovered(false)}
                className="group relative px-8 py-5 bg-gradient-to-r from-red-900 to-red-800 rounded-2xl font-black text-lg text-white overflow-hidden shadow-2xl"
              >
                {/* Animated Background */}
                <motion.div
                  animate={isHovered ? { x: ['0%', '100%'] } : {}}
                  transition={{ duration: 0.5 }}
                  className="absolute inset-0 bg-gradient-to-r from-red-800 to-orange-600"
                />
                
                {/* Content */}
                <span className="relative z-10 flex items-center gap-3">
                  <Download className="w-5 h-5" />
                  Start Reading Free
                  <motion.div
                    animate={{ x: [0, 5, 0] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    <ArrowRight className="w-5 h-5" />
                  </motion.div>
                </span>

                {/* Shine Effect */}
                <motion.div
                  animate={{ x: ['-100%', '200%'] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
                />
              </motion.button>

              {/* Secondary Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-5 bg-white/10 backdrop-blur-xl border-2 border-white/20 rounded-2xl font-black text-lg text-white hover:bg-white/20 transition-all shadow-xl flex items-center gap-3 justify-center"
              >
                <Play className="w-5 h-5" />
                Watch Demo
              </motion.button>
            </motion.div>

            {/* Trust Badges */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.4 }}
              className="flex items-center gap-6 flex-wrap"
            >
              <p className="text-sm text-gray-500 font-semibold">Trusted by:</p>
              {['Amazon', 'Google', 'Microsoft', 'Apple'].map((brand, i) => (
                <motion.div
                  key={i}
                  whileHover={{ scale: 1.1 }}
                  className="px-4 py-2 bg-white/5 backdrop-blur-xl rounded-lg border border-white/10"
                >
                  <span className="text-gray-400 font-bold text-sm">{brand}</span>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Right Side - 3D Book Display */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
            className="relative"
          >
            {/* 3D Book Container */}
            <motion.div
              animate={{
                y: [0, -20, 0],
                rotateY: [0, 5, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              style={{
                x: mousePosition.x,
                y: mousePosition.y,
                transformStyle: 'preserve-3d',
              }}
              className="relative"
            >
              {/* Glow Effect */}
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 0.8, 0.5],
                }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute inset-0 bg-gradient-to-r from-red-500/50 via-orange-500/50 to-yellow-500/50 blur-3xl rounded-full"
              />

              {/* Main Book Stack */}
              <div className="relative">
                {/* Book 1 - Front */}
                <motion.div
                  whileHover={{ scale: 1.05, rotateY: 10 }}
                  className="relative w-80 h-[500px] bg-white rounded-2xl shadow-2xl border-4 border-white overflow-hidden"
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  <Image
                    src="/Assets/WhatsApp Image 2025-11-15 at 04.57.16_185ad9fe.jpg"
                    alt="Featured Book"
                    fill
                    className="object-cover"
                    priority
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                  
                  {/* Book Info Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 1.5 }}
                    >
                      <div className="flex items-center gap-2 mb-3">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                        <span className="text-white text-sm font-bold ml-2">4.9</span>
                      </div>
                      <h3 className="text-2xl font-black text-white mb-2">
                        The Midnight Library
                      </h3>
                      <p className="text-gray-300 text-sm">by Matt Haig</p>
                    </motion.div>
                  </div>

                  {/* Bestseller Badge */}
                  <div className="absolute top-4 right-4 bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-4 py-2 rounded-full text-xs font-black shadow-xl">
                    🏆 Bestseller
                  </div>

                  {/* Shine Effect */}
                  <motion.div
                    animate={{ x: ['-100%', '200%'] }}
                    transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
                  />
                </motion.div>

                {/* Book 2 - Behind (Offset) */}
                <motion.div
                  initial={{ x: -20, y: 20, opacity: 0.7 }}
                  animate={{ x: -15, y: 15, opacity: 0.8 }}
                  className="absolute top-0 left-0 w-80 h-[500px] bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl shadow-xl -z-10"
                  style={{ transform: 'translateZ(-50px)' }}
                />

                {/* Book 3 - Behind (More Offset) */}
                <motion.div
                  initial={{ x: -40, y: 40, opacity: 0.5 }}
                  animate={{ x: -30, y: 30, opacity: 0.6 }}
                  className="absolute top-0 left-0 w-80 h-[500px] bg-gradient-to-br from-purple-600 to-purple-800 rounded-2xl shadow-xl -z-20"
                  style={{ transform: 'translateZ(-100px)' }}
                />
              </div>

              {/* Floating Icons Around Book */}
              {[
                { icon: BookOpen, delay: 0, radius: 200, angle: 0 },
                { icon: Star, delay: 0.5, radius: 220, angle: 120 },
                { icon: Sparkles, delay: 1, radius: 210, angle: 240 },
              ].map((item, i) => {
                const Icon = item.icon;
                const x = Math.cos(item.angle * Math.PI / 180) * item.radius;
                const y = Math.sin(item.angle * Math.PI / 180) * item.radius;
                
                return (
                  <motion.div
                    key={i}
                    animate={{
                      y: [y, y - 20, y],
                      rotate: [0, 360],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      delay: item.delay,
                    }}
                    style={{
                      position: 'absolute',
                      left: `calc(50% + ${x}px)`,
                      top: `calc(50% + ${y}px)`,
                    }}
                    className="w-12 h-12 bg-gradient-to-br from-red-900 to-red-800 rounded-full flex items-center justify-center shadow-xl"
                  >
                    <Icon className="w-6 h-6 text-white" />
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="flex flex-col items-center gap-2"
        >
          <p className="text-gray-500 text-sm font-semibold">Scroll to explore</p>
          <div className="w-6 h-10 border-2 border-gray-600 rounded-full flex justify-center p-2">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1 h-2 bg-red-500 rounded-full"
            />
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}