'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { Check, Sparkles, Star, Trophy, Rocket, Zap } from 'lucide-react';

const PRICING_PLANS = [
  {
    id: 1,
    name: 'Basic',
    description: 'Perfect for casual readers',
    price: 9,
    period: 'month',
    icon: Sparkles,
    features: [
      '10 Books per month',
      'Standard quality downloads',
      'Email support (24-48 hours)',
      'Single device access',
      'Basic recommendations',
      'Mobile app access',
      'Bookmark sync',
    ],
    highlighted: false,
    buttonText: 'Get Started',
  },
  {
    id: 2,
    name: 'Professional',
    description: 'Best for avid readers',
    price: 19,
    period: 'month',
    icon: Trophy,
    features: [
      'Unlimited Books',
      'HD Quality downloads',
      '24/7 Priority support',
      'Up to 5 Devices',
      'AI-Powered Recommendations',
      'Exclusive early releases',
      'Offline reading mode',
      'Advanced search filters',
      'Reading statistics',
      'Custom collections',
      'No ads experience',
      'Audiobook integration',
    ],
    highlighted: true,
    buttonText: 'Start Free Trial',
  },
  {
    id: 3,
    name: 'Enterprise',
    description: 'For teams & organizations',
    price: 49,
    period: 'month',
    icon: Rocket,
    features: [
      'Everything in Professional',
      'Unlimited devices',
      'Custom team collections',
      'Advanced analytics dashboard',
      'API access for developers',
      'Dedicated account manager',
      'White-label options',
      'Priority feature requests',
      'Custom integrations',
      'Team collaboration tools',
      'Admin panel access',
      'SLA guarantee',
    ],
    highlighted: false,
    buttonText: 'Contact Sales',
  },
];

export function Pricing() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  return (
    <section className="relative py-24 overflow-hidden bg-gradient-to-b from-[#FFFAE8] to-[#FFF5E1]">
      
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.04]">
        <div 
          className="absolute inset-0" 
          style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, #7f1d1d 1px, transparent 0)`,
            backgroundSize: '40px 40px',
          }}
        />
      </div>

      {/* Gradient Orbs - Maroon Theme */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-red-900/10 to-red-800/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-orange-900/10 to-red-900/10 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block mb-4"
          >
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-red-900 to-red-800 rounded-full shadow-lg">
              <Zap className="w-4 h-4 text-yellow-300 fill-yellow-300" />
              <span className="text-white text-sm font-black tracking-wide">PRICING PLANS</span>
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl lg:text-6xl font-black mb-4"
          >
            <span className="text-gray-900">Choose Your </span>
            <span className="bg-gradient-to-r from-red-900 via-red-700 to-red-900 bg-clip-text text-transparent">
              Perfect Plan
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-gray-700 max-w-2xl mx-auto mb-8"
          >
            Start with a 14-day free trial. No credit card required. Cancel anytime.
          </motion.p>

          {/* Billing Toggle - Maroon Theme */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-4 bg-white p-2 rounded-full shadow-xl border-2 border-red-100"
          >
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-8 py-3 rounded-full font-bold transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-gradient-to-r from-red-900 to-red-800 text-white shadow-lg'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-8 py-3 rounded-full font-bold transition-all ${
                billingCycle === 'yearly'
                  ? 'bg-gradient-to-r from-red-900 to-red-800 text-white shadow-lg'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Yearly
              <span className="ml-2 text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full font-black">
                Save 20%
              </span>
            </button>
          </motion.div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {PRICING_PLANS.map((plan, index) => (
            <PricingCard 
              key={plan.id} 
              plan={plan} 
              index={index}
              billingCycle={billingCycle}
            />
          ))}
        </div>

        {/* Bottom Info */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex flex-wrap items-center justify-center gap-8 bg-white px-8 py-4 rounded-2xl shadow-lg border-2 border-red-100">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center">
                <Check className="w-4 h-4 text-white" strokeWidth={3} />
              </div>
              <span className="text-gray-800 font-semibold">No credit card required</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center">
                <Check className="w-4 h-4 text-white" strokeWidth={3} />
              </div>
              <span className="text-gray-800 font-semibold">14-day free trial</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center">
                <Check className="w-4 h-4 text-white" strokeWidth={3} />
              </div>
              <span className="text-gray-800 font-semibold">Cancel anytime</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function PricingCard({ 
  plan, 
  index,
  billingCycle 
}: { 
  plan: typeof PRICING_PLANS[0]; 
  index: number;
  billingCycle: 'monthly' | 'yearly';
}) {
  const [isHovered, setIsHovered] = useState(false);
  const Icon = plan.icon;
  
  const displayPrice = billingCycle === 'yearly' 
    ? Math.floor(plan.price * 0.8) 
    : plan.price;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`relative ${plan.highlighted ? 'md:-mt-4' : ''}`}
    >
      {/* Popular Badge - Maroon */}
      {plan.highlighted && (
        <motion.div
          animate={{ y: [0, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute -top-4 left-0 right-0 flex justify-center z-10"
        >
          <div className="bg-gradient-to-r from-red-900 to-red-800 text-white px-6 py-2 rounded-full text-sm font-black shadow-xl border-2 border-white flex items-center gap-2">
            <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
            MOST POPULAR
            <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
          </div>
        </motion.div>
      )}

      {/* Card */}
      <motion.div
        whileHover={{ y: -8, scale: 1.02 }}
        className={`relative h-full bg-white rounded-3xl overflow-hidden transition-all ${
          plan.highlighted
            ? 'border-4 border-red-800 shadow-2xl shadow-red-900/20'
            : 'border-2 border-gray-200 shadow-xl hover:border-red-300'
        }`}
      >
        {/* Background Gradient - Maroon */}
        <div className={`absolute inset-0 ${
          plan.highlighted 
            ? 'bg-gradient-to-br from-red-50/80 to-orange-50/80' 
            : 'bg-gradient-to-br from-gray-50/50 to-white'
        }`} />

        {/* Shine Effect on Hover */}
        {isHovered && (
          <motion.div
            animate={{ x: ['-100%', '200%'] }}
            transition={{ duration: 1.5 }}
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12 pointer-events-none"
          />
        )}

        <div className="relative p-8">
          {/* Icon - Maroon */}
          <motion.div
            animate={isHovered ? { rotate: 360, scale: 1.1 } : {}}
            transition={{ duration: 0.6 }}
            className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-6 shadow-lg ${
              plan.highlighted
                ? 'bg-gradient-to-br from-red-900 to-red-800'
                : 'bg-gradient-to-br from-gray-700 to-gray-900'
            }`}
          >
            <Icon className="w-8 h-8 text-white" />
          </motion.div>

          {/* Plan Name */}
          <h3 className="text-3xl font-black text-gray-900 mb-2">
            {plan.name}
          </h3>

          {/* Description */}
          <p className="text-gray-600 text-base mb-6 font-medium">
            {plan.description}
          </p>

          {/* Price - Maroon */}
          <div className="mb-8">
            <div className="flex items-baseline gap-1">
              <span className={`text-6xl font-black ${
                plan.highlighted
                  ? 'bg-gradient-to-r from-red-900 to-red-700 bg-clip-text text-transparent'
                  : 'text-gray-900'
              }`}>
                ${displayPrice}
              </span>
              <span className="text-gray-600 font-bold text-lg">
                /{plan.period}
              </span>
            </div>
            {billingCycle === 'yearly' && (
              <motion.p
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-sm text-green-600 font-bold mt-2 bg-green-50 inline-block px-3 py-1 rounded-full"
              >
                💰 Save ${plan.price * 12 - displayPrice * 12}/year
              </motion.p>
            )}
          </div>

          {/* Features with Custom Scrollbar */}
          <div className="mb-8">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-4">
              What's Included:
            </p>
            <div 
              className="space-y-3 max-h-64 overflow-y-auto pr-2 custom-scrollbar"
              style={{
                scrollbarWidth: 'thin',
                scrollbarColor: plan.highlighted ? '#7f1d1d #fee2e2' : '#9ca3af #f3f4f6',
              }}
            >
              {plan.features.map((feature, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 + i * 0.03 }}
                  className="flex items-start gap-3 group"
                >
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: 360 }}
                    transition={{ type: 'spring', stiffness: 400 }}
                    className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center mt-0.5 ${
                      plan.highlighted 
                        ? 'bg-gradient-to-br from-red-900 to-red-800 shadow-md' 
                        : 'bg-gradient-to-br from-gray-700 to-gray-900'
                    }`}
                  >
                    <Check className="w-3 h-3 text-white" strokeWidth={3} />
                  </motion.div>
                  <span className="text-gray-700 font-medium text-sm leading-relaxed group-hover:text-gray-900 transition-colors">
                    {feature}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* CTA Button - Maroon */}
          <motion.button
            whileHover={{ scale: 1.03, y: -2 }}
            whileTap={{ scale: 0.97 }}
            className={`w-full py-4 rounded-xl font-black text-base transition-all relative overflow-hidden ${
              plan.highlighted
                ? 'bg-gradient-to-r from-red-900 to-red-800 text-white shadow-xl shadow-red-900/30 hover:shadow-2xl hover:shadow-red-900/40'
                : 'bg-gray-900 text-white hover:bg-gray-800 shadow-lg'
            }`}
          >
            {/* Button Shine */}
            <motion.div
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
            />
            <span className="relative z-10">{plan.buttonText}</span>
          </motion.button>
        </div>

        {/* Bottom Accent - Maroon */}
        {plan.highlighted && (
          <motion.div
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r from-red-900 via-red-700 to-red-900"
          />
        )}
      </motion.div>
    </motion.div>
  );
}