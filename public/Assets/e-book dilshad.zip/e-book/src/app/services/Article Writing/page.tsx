'use client'
import { motion } from 'framer-motion'
import { FaAward, FaPen, FaUsers, FaRocket, FaHeart, FaLightbulb, FaCheckCircle, FaQuoteLeft, FaStar, FaHandshake, FaGlobe, FaShieldAlt } from 'react-icons/fa'
import Link from 'next/link'

export default function AboutUs() {
  const stats = [
    { number: '1000+', label: 'Articles Written', icon: <FaPen /> },
    { number: '500+', label: 'Happy Clients', icon: <FaUsers /> },
    { number: '50+', label: 'Expert Writers', icon: <FaAward /> },
    { number: '98%', label: 'Success Rate', icon: <FaRocket /> }
  ]

  const values = [
    {
      icon: <FaHeart />,
      title: 'Passion for Writing',
      desc: 'We breathe words and live stories. Every article we craft comes from a place of genuine passion and dedication to the art of writing.'
    },
    {
      icon: <FaLightbulb />,
      title: 'Innovation & Creativity',
      desc: 'We don\'t just follow trends—we create them. Our team brings fresh perspectives and innovative ideas to every project.'
    },
    {
      icon: <FaCheckCircle />,
      title: 'Quality Guaranteed',
      desc: 'Excellence is not negotiable. We maintain the highest standards in every piece we deliver, ensuring perfection every time.'
    },
    {
      icon: <FaHandshake />,
      title: 'Client-Centric Approach',
      desc: 'Your success is our success. We work closely with you to understand your vision and bring it to life with precision.'
    },
    {
      icon: <FaGlobe />,
      title: 'Global Reach',
      desc: 'From local stories to international narratives, we craft content that resonates across borders and cultures.'
    },
    {
      icon: <FaShieldAlt />,
      title: 'Trust & Transparency',
      desc: 'We believe in honest communication, fair pricing, and complete ownership of your content. No hidden agendas.'
    }
  ]

  const team = [
    {
      name: 'Sarah Mitchell',
      role: 'Chief Content Officer',
      experience: '15+ Years',
      specialty: 'Tech & Business Writing'
    },
    {
      name: 'James Rodriguez',
      role: 'Senior Editor',
      experience: '12+ Years',
      specialty: 'Creative & Feature Articles'
    },
    {
      name: 'Emily Chen',
      role: 'Lead Copywriter',
      experience: '10+ Years',
      specialty: 'Marketing & SEO Content'
    },
    {
      name: 'Michael Brown',
      role: 'Content Strategist',
      experience: '8+ Years',
      specialty: 'Brand Storytelling'
    }
  ]

  const testimonials = [
    {
      text: "Ghost Writing Squad transformed our content strategy completely. Their writers understand our brand voice perfectly!",
      author: "Jennifer Lee",
      company: "Tech Innovators Inc.",
      rating: 5
    },
    {
      text: "Professional, reliable, and incredibly talented. They've been our go-to writing service for over 2 years now.",
      author: "Robert Johnson",
      company: "Marketing Pro Solutions",
      rating: 5
    },
    {
      text: "The quality of writing is exceptional. They deliver on time, every time. Highly recommended!",
      author: "Amanda White",
      company: "Creative Ventures LLC",
      rating: 5
    }
  ]

  const milestones = [
    { year: '2015', event: 'Ghost Writing Squad Founded' },
    { year: '2017', event: 'Reached 100+ Clients Milestone' },
    { year: '2019', event: 'Expanded to International Markets' },
    { year: '2021', event: 'Won Best Content Agency Award' },
    { year: '2023', event: '1000+ Projects Completed' },
    { year: '2024', event: 'Leading Article Writing Service in USA' }
  ]

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      
      {/* ========== HERO SECTION ========== */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
        {/* Background Animation */}
        <div className="absolute inset-0 z-0">
          <div className="absolute top-20 left-20 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
          <div className="absolute top-40 right-20 w-96 h-96 bg-pink-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
          <div className="absolute bottom-20 left-1/2 w-96 h-96 bg-blue-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
        </div>

        <div className="container mx-auto px-6 z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-block bg-purple-500/20 text-purple-400 px-6 py-3 rounded-full mb-6 border border-purple-500/50"
            >
              About Ghost Writing Squad
            </motion.div>

            <motion.h1 
              className="text-6xl md:text-8xl font-black mb-6 leading-tight"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              We Are <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Storytellers</span>
              <br />
              Word Wizards & Dream Weavers
            </motion.h1>

            <motion.p 
              className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto leading-relaxed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
            >
              Founded with a passion for powerful prose and compelling content, <span className="text-purple-400 font-semibold">Ghost Writing Squad</span> has 
              been transforming ideas into impactful articles since 2015. We're not just writers—we're your creative partners in success.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.8 }}
            >
              <Link href="/contact">
                <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-5 rounded-full font-semibold text-lg hover:scale-105 transition-transform duration-300 shadow-lg hover:shadow-purple-500/50">
                  Start Your Story Today
                </button>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ========== STATS SECTION ========== */}
      <section className="py-20 px-6 relative">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20 text-center group"
              >
                <div className="text-5xl mb-4 text-purple-500 group-hover:scale-110 transition-transform duration-300 flex justify-center">
                  {stat.icon}
                </div>
                <div className="text-5xl font-black bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-400 text-lg">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== OUR STORY SECTION ========== */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/10 to-pink-900/10"></div>
        
        <div className="container mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              Our <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Story</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="space-y-6 text-lg text-gray-300 leading-relaxed">
                <p>
                  <span className="text-2xl text-purple-400 font-bold">It all started with a simple belief:</span> every business, 
                  every individual, every idea deserves to be heard—and heard powerfully.
                </p>
                <p>
                  In 2015, a group of passionate writers came together with a mission to democratize quality content creation. 
                  We saw businesses struggling to find their voice, entrepreneurs unable to articulate their vision, and amazing 
                  stories going untold.
                </p>
                <p>
                  So we built <span className="text-purple-400 font-semibold">Ghost Writing Squad</span>—a creative powerhouse 
                  where words meet strategy, where content meets conversion, and where your ideas transform into impactful narratives.
                </p>
                <p className="text-xl font-semibold text-white">
                  Today, we're proud to be one of USA's leading article writing services, trusted by hundreds of clients worldwide.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700">
                <h3 className="text-3xl font-bold mb-6 text-purple-400">Our Journey</h3>
                <div className="space-y-4">
                  {milestones.map((milestone, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="flex items-center gap-4 p-4 bg-slate-700/30 rounded-lg hover:bg-slate-700/50 transition"
                    >
                      <div className="text-2xl font-bold text-pink-500 min-w-[80px]">{milestone.year}</div>
                      <div className="text-gray-300">{milestone.event}</div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ========== OUR VALUES SECTION ========== */}
      <section className="py-24 px-6 relative">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              Our Core <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Values</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              These principles guide everything we do, from the first brainstorm to the final draft.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20 group"
              >
                <div className="text-5xl mb-6 text-pink-500 group-hover:scale-110 transition-transform duration-300">
                  {value.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4">{value.title}</h3>
                <p className="text-gray-400 leading-relaxed">{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== TEAM SECTION ========== */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/10 to-pink-900/10"></div>
        
        <div className="container mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              Meet Our <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Dream Team</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Talented writers, editors, and strategists working together to bring your vision to life.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20 text-center group"
              >
                <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full mx-auto mb-6 flex items-center justify-center text-4xl font-black group-hover:scale-110 transition-transform duration-300">
                  {member.name.charAt(0)}
                </div>
                <h3 className="text-2xl font-bold mb-2">{member.name}</h3>
                <p className="text-purple-400 font-semibold mb-2">{member.role}</p>
                <p className="text-gray-400 text-sm mb-2">{member.experience}</p>
                <p className="text-gray-500 text-sm italic">{member.specialty}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== TESTIMONIALS SECTION ========== */}
      <section className="py-24 px-6 relative">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              What Our <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Clients Say</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-2xl border border-slate-700 hover:border-purple-500 transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/20"
              >
                <FaQuoteLeft className="text-4xl text-purple-500 mb-4" />
                <p className="text-gray-300 mb-6 leading-relaxed italic">{testimonial.text}</p>
                <div className="flex items-center gap-2 mb-2">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <FaStar key={i} className="text-yellow-500" />
                  ))}
                </div>
                <p className="font-bold text-white">{testimonial.author}</p>
                <p className="text-sm text-gray-400">{testimonial.company}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== CTA SECTION ========== */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20"></div>
        
        <div className="container mx-auto relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl md:text-6xl font-black mb-6">
              Ready to <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Work Together?</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-10">
              Let's create something amazing together. Your story deserves to be told—and we're here to help you tell it powerfully.
            </p>
            <div className="flex flex-col md:flex-row gap-6 justify-center">
              <Link href="/contact">
                <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-5 rounded-full font-semibold text-lg hover:scale-105 transition-transform duration-300 shadow-lg hover:shadow-purple-500/50">
                  Get Started Today
                </button>
              </Link>
              <Link href="/services">
                <button className="border-2 border-purple-500 text-purple-400 px-10 py-5 rounded-full font-semibold text-lg hover:bg-purple-500 hover:text-white transition-all duration-300">
                  Explore Our Services
                </button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========== ANIMATIONS ========== */}
      <style jsx>{`
        @keyframes blob {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </main>
  )
}