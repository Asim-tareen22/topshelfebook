'use client';

import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export function Card({ children, className, hover = false }: CardProps) {
  return (
    <div
      className={cn(
        'p-6 rounded-lg border border-cyan-500/30',
        hover && 'hover:border-cyan-500 hover:bg-cyan-500/10 transition',
        className
      )}
    >
      {children}
    </div>
  );
}