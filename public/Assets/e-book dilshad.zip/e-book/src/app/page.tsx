'use client';

import { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Loader } from '@/components/common/Loader';
import { Navbar } from '@/components/common/Navbar';
import { Hero } from '@/components/sections/Hero';
import { Services } from '@/components/sections/Services';
import { NewTrending } from '@/components/sections/NewTrending';
import { Pricing } from '@/components/sections/Pricing';
import { PersonalBrand } from '@/components/sections/PersonalBrand';
import { BookShelfSection } from '@/components/sections/BookShelfSection';
import { BooksShowcase } from '@/components/sections/BooksShowcase';
import { CardsSpreadSection } from '@/components/sections/CardsSpreadSection';
import { TestimonialsSection } from '@/components/sections/TestimonialsSection';
import { FAQs } from '@/components/sections/FAQs';
import { Footer } from '@/components/common/Footer';

export default function Home() {
  const [loading, setLoading] = useState(true);

  return (
    <>
      <AnimatePresence mode="wait">
        {loading && <Loader onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {!loading && (
        <main className="min-h-screen bg-black text-white overflow-hidden">
          <Navbar />
          <Hero />
          <Services />
          <PersonalBrand />      {/* Author Identity section */}
          <BookShelfSection />   {/* Digital Library */}
          <BooksShowcase />      {/* Books Display */}
          <CardsSpreadSection /> {/* Card Spread Animation */}
          <TestimonialsSection /> {/* Reader Testimonials */}
          <NewTrending />
          <Pricing />
          <FAQs />               {/* FAQs Section */}
          <Footer />
        </main>
      )}
    </>
  );
}