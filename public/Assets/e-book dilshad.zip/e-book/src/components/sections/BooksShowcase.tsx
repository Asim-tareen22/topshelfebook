'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { BookOpen } from 'lucide-react';
import Image from 'next/image';

export function BooksShowcase() {
  const [activeIndex, setActiveIndex] = useState(5);
  
  const books = [
    'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1589998059171-988d887df646?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1551029506-0807df4e2031?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1576872381149-7847515ce5d8?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1592496431122-2349e0fbc666?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1491841550275-ad7854e35ca6?w=400&h=600&fit=crop',
    'https://images.unsplash.com/photo-1495640388908-05fa85288e61?w=400&h=600&fit=crop',
  ];

  return (
    <motion.section 
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="relative py-20 bg-gradient-to-br from-[#4a0e0e] via-[#3d0a0a] to-[#2d0707] overflow-hidden"
    >
      {/* Background Effects */}
      <div className="absolute inset-0">
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-0 left-1/3 w-[500px] h-[500px] bg-[#8b0000]/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.3, 1, 1.3],
            opacity: [0.25, 0.15, 0.25],
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute bottom-0 right-1/3 w-[500px] h-[500px] bg-[#660000]/20 rounded-full blur-3xl"
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, type: 'spring', damping: 10 }}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#8b0000]/20 border border-[#8b0000]/40 mb-6 backdrop-blur-sm"
          >
            <BookOpen className="w-4 h-4 text-[#ff6b6b]" />
            <span className="text-[#ff9999] font-bold text-sm tracking-wide">FEATURED COLLECTION</span>
          </motion.div>

          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-5xl sm:text-6xl lg:text-7xl font-black text-white mb-4 tracking-tight"
          >
            Our{' '}
            <span className="bg-gradient-to-r from-[#ff6b6b] via-[#ee5a6f] to-[#c44569] bg-clip-text text-transparent">
              Bestsellers
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-[#ffcccc]/70 text-lg font-medium"
          >
            Explore Our Premium Book Collection
          </motion.p>
        </motion.div>

        {/* V-SHAPE CAROUSEL - PERFECTLY CENTERED */}
        <motion.div 
          className="relative h-[700px] flex flex-col"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {/* Books Container - ABSOLUTE CENTER */}
          <div className="relative flex-1 w-full flex items-center justify-center" style={{ perspective: '2000px' }}>
            {books.map((image, index) => {
              const position = index - activeIndex;
              const isActive = index === activeIndex;
              const absPosition = Math.abs(position);
              
              const xOffset = position * 130;
              const yOffset = absPosition * 80;
              const rotation = position * -8;
              const scale = isActive ? 1.15 : Math.max(0.7, 0.95 - absPosition * 0.06);
              const zIndex = 100 - absPosition * 10;
              const opacity = Math.max(0.5, 1 - absPosition * 0.15);

              return (
                <motion.div
                  key={index}
                  animate={{
                    x: xOffset,
                    y: -yOffset,
                    rotateY: rotation,
                    rotateZ: position * -1.2,
                    scale: scale,
                    opacity: opacity,
                  }}
                  transition={{
                    type: 'spring',
                    damping: 22,
                    stiffness: 100,
                  }}
                  onClick={() => setActiveIndex(index)}
                  className="absolute cursor-pointer"
                  style={{
                    perspective: '1500px',
                    transformStyle: 'preserve-3d',
                    zIndex: zIndex,
                    left: '50%',
                    top: '50%',
                    marginLeft: '-104px', // Half of card width (208/2)
                    marginTop: '-160px',  // Half of card height (320/2)
                  }}
                >
                  <motion.div
                    whileHover={{ 
                      scale: 1.12,
                      y: -15,
                      rotateY: 0,
                      zIndex: 200,
                    }}
                    whileTap={{ scale: 0.98 }}
                    className="relative w-52 h-80 rounded-2xl overflow-hidden shadow-2xl group"
                  >
                    <Image
                      src={image}
                      alt={`Book ${index + 1}`}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      sizes="208px"
                      priority={isActive}
                    />

                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    {isActive && (
                      <>
                        <motion.div
                          animate={{
                            boxShadow: [
                              '0 0 40px rgba(139, 0, 0, 0.8)',
                              '0 0 80px rgba(139, 0, 0, 1)',
                              '0 0 40px rgba(139, 0, 0, 0.8)',
                            ],
                          }}
                          transition={{ duration: 2.5, repeat: Infinity }}
                          className="absolute inset-0 rounded-2xl"
                        />
                        <motion.div
                          initial={{ scale: 0, y: -20 }}
                          animate={{ scale: 1, y: 0 }}
                          transition={{ type: 'spring', damping: 10 }}
                          className="absolute top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-gradient-to-r from-[#8b0000] to-[#c44569] rounded-full text-white text-xs font-bold shadow-xl border border-white/20"
                        >
                          ⭐ FEATURED
                        </motion.div>
                      </>
                    )}

                    <div className={`absolute inset-0 rounded-2xl border-2 transition-all duration-300 ${
                      isActive 
                        ? 'border-[#ff6b6b]/90 shadow-[0_0_30px_rgba(255,107,107,0.5)]' 
                        : 'border-white/10 group-hover:border-[#ff6b6b]/50'
                    }`} />
                  </motion.div>
                </motion.div>
              );
            })}
          </div>

          {/* Dots Navigation - Bottom Center */}
          <motion.div 
            className="w-full flex justify-center pb-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
          >
            <div className="flex gap-2.5 px-6 py-4 bg-black/40 backdrop-blur-xl rounded-full border-2 border-[#8b0000]/40 shadow-2xl">
              {books.map((_, index) => (
                <motion.button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  whileHover={{ scale: 1.4 }}
                  whileTap={{ scale: 0.9 }}
                  className="transition-all"
                  aria-label={`Go to book ${index + 1}`}
                >
                  <div
                    className={`rounded-full transition-all duration-500 ${
                      index === activeIndex
                        ? 'w-12 h-3.5 bg-gradient-to-r from-[#8b0000] via-[#ff6b6b] to-[#c44569] shadow-lg shadow-[#8b0000]/60'
                        : 'w-3.5 h-3.5 bg-[#ffcccc]/30 hover:bg-[#ff6b6b]/60'
                    }`}
                  />
                </motion.button>
              ))}
            </div>
          </motion.div>
        </motion.div>

        {/* CTA with Animated Border */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="text-center mt-12"
        >
          <motion.button
            whileHover={{ scale: 1.05, y: -3 }}
            whileTap={{ scale: 0.98 }}
            className="relative px-14 py-5 bg-gradient-to-r from-[#8b0000] via-[#a01010] to-[#8b0000] text-white font-bold text-lg rounded-2xl shadow-2xl shadow-[#8b0000]/40 hover:shadow-[#8b0000]/70 transition-all overflow-hidden group"
          >
            {/* Rotating Border Effect */}
            <motion.div
              className="absolute inset-0 rounded-2xl"
              style={{
                background: 'conic-gradient(from 0deg, transparent, #ff6b6b, transparent, transparent)',
              }}
              animate={{
                rotate: 360,
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: 'linear',
              }}
            />

            {/* Inner Background */}
            <div className="absolute inset-[2px] rounded-2xl bg-gradient-to-r from-[#8b0000] via-[#a01010] to-[#8b0000]" />

            {/* Shine Effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/25 to-white/0"
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
            />

            <span className="relative z-10 tracking-wide">Explore All Books →</span>
          </motion.button>
        </motion.div>
      </div>
    </motion.section>
  );
}