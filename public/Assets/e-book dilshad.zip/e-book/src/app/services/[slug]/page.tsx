'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { ArrowLeft, ArrowRight, Check, Star } from 'lucide-react';

const servicesData: Record<string, any> = {
  'ghostwriting': {
    title: 'Ghostwriting Services',
    description: 'Professional ghostwriters who bring your stories to life with compelling narratives and authentic voice.',
    features: [
      'Fiction & Non-Fiction Writing',
      'Biography & Memoir Writing',
      'Business Books & eBooks',
      'Fully Customized Content',
      'Multiple Rounds of Revisions',
      'Confidentiality Agreement'
    ],
    price: '$2,999',
    rating: 4.9,
    reviews: 245
  },
  'book-cover': {
    title: 'Book Cover Design',
    description: 'Eye-catching book covers that capture attention and reflect your story perfectly.',
    features: [
      'Custom Cover Design',
      'Print & Digital Formats',
      '3D Mockups Included',
      'Unlimited Revisions',
      'Commercial License',
      'Fast Turnaround'
    ],
    price: '$499',
    rating: 4.8,
    reviews: 189
  },
  'editing': {
    title: 'Editing Services',
    description: 'Comprehensive editing to polish your manuscript and make it publication-ready.',
    features: [
      'Developmental Editing',
      'Copy Editing & Proofreading',
      'Line Editing',
      'Formatting & Layout',
      'Detailed Feedback',
      'Publication Guidelines'
    ],
    price: '$1,499',
    rating: 4.9,
    reviews: 312
  },
  'article-writing': {
    title: 'Article Writing Services',
    description: 'Engaging articles that inform, educate, and captivate your target audience.',
    features: [
      'Blog Post Writing',
      'News Article Creation',
      'Feature Articles',
      'How-To Guides',
      'SEO Optimized',
      'Professional Research'
    ],
    price: '$799',
    rating: 4.7,
    reviews: 128
  },
  'marketing': {
    title: 'Book Marketing Services',
    description: 'Strategic marketing campaigns to boost your book sales and build your author brand.',
    features: [
      'Social Media Marketing',
      'Email Marketing Campaigns',
      'Amazon Ads Management',
      'Book Launch Strategy',
      'Author Branding',
      'Sales Analytics & Reporting'
    ],
    price: '$1,999',
    rating: 4.7,
    reviews: 156
  },
  'web-copywriting': {
    title: 'Web Copywriting Services',
    description: 'Persuasive web copy that converts visitors into customers and boosts conversions.',
    features: [
      'Landing Page Copy',
      'Product Descriptions',
      'About Page Content',
      'Sales Copy Writing',
      'CTA Optimization',
      'Conversion Focused'
    ],
    price: '$1,299',
    rating: 4.8,
    reviews: 95
  },
  'magazine-writing': {
    title: 'Magazine Writing Services',
    description: 'Professional magazine content that engages readers and meets editorial standards.',
    features: [
      'Feature Article Writing',
      'Interview Articles',
      'Review Pieces',
      'Opinion Articles',
      'Editorial Standards',
      'Timely Content'
    ],
    price: '$899',
    rating: 4.6,
    reviews: 72
  },
  'press-release': {
    title: 'Press Release Services',
    description: 'Newsworthy press releases that get media attention and build credibility.',
    features: [
      'Press Release Writing',
      'Media Distribution',
      'AP Style Compliance',
      'News Angle Creation',
      'Follow-up Strategies',
      'Media Relations'
    ],
    price: '$599',
    rating: 4.7,
    reviews: 104
  },
  'seo-writing': {
    title: 'SEO Writing Services',
    description: 'Search-optimized content that ranks high and drives organic traffic to your site.',
    features: [
      'Keyword Research & Optimization',
      'Meta Description Writing',
      'Content Strategy',
      'SEO Best Practices',
      'Analytics Reporting',
      'Rank Tracking'
    ],
    price: '$1,199',
    rating: 4.8,
    reviews: 187
  },
  'script-writing': {
    title: 'Script Writing Services',
    description: 'Compelling scripts for video, film, podcasts, and multimedia productions.',
    features: [
      'Video Script Writing',
      'Screenplay Writing',
      'Podcast Scripts',
      'YouTube Content Scripts',
      'Commercial Scripts',
      'Professional Formatting'
    ],
    price: '$1,399',
    rating: 4.9,
    reviews: 142
  }
};

export default function ServicePage() {
  const params = useParams();
  const slug = params.slug as string;
  const service = servicesData[slug] || servicesData['ghostwriting'];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <section className="relative py-20 bg-gradient-to-r from-red-900 via-red-800 to-red-900 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff10_1px,transparent_1px),linear-gradient(to_bottom,#ffffff10_1px,transparent_1px)] bg-[size:40px_40px]" />
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <Link href="/services" className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-6 transition">
            <ArrowLeft className="w-5 h-5" />
            Back to Services
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <h1 className="text-5xl lg:text-6xl font-black mb-6">{service.title}</h1>
            <p className="text-xl text-white/90 mb-8">{service.description}</p>

            <div className="flex flex-wrap gap-8 items-center">
              <div>
                <div className="text-4xl font-black text-white mb-2">{service.price}</div>
                <p className="text-white/80">Starting price</p>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <div>
                  <div className="font-black text-white">{service.rating}</div>
                  <p className="text-white/80">{service.reviews} reviews</p>
                </div>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="mt-10 px-8 py-4 bg-white text-red-900 font-black rounded-full shadow-lg hover:shadow-xl transition"
            >
              <Link href="/contact-us">Get Started Now</Link>
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 lg:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl"
          >
            <h2 className="text-4xl font-black text-gray-900 mb-12">What's Included</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {service.features.map((feature: string, i: number) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-start gap-4 p-4 rounded-lg bg-red-50 hover:bg-red-100 transition"
                >
                  <div className="flex-shrink-0 mt-1">
                    <Check className="w-6 h-6 text-red-800" />
                  </div>
                  <p className="text-gray-800 font-medium">{feature}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-red-900 to-red-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl lg:text-5xl font-black text-white mb-6">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join thousands of satisfied authors and content creators who have transformed their ideas into reality.
            </p>

            <div className="flex flex-wrap gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 bg-white text-red-900 font-black rounded-full text-lg shadow-xl hover:shadow-2xl transition"
              >
                <Link href="/contact-us">Get Started Now</Link>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 border-2 border-white text-white font-black rounded-full text-lg hover:bg-white/10 transition"
              >
                Schedule a Call
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
