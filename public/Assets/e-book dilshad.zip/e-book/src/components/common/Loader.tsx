'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export function Loader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<'walking' | 'opening' | 'pages' | 'welcome' | 'complete'>('walking');

  useEffect(() => {
    const timeline = [
      { delay: 3000, nextPhase: 'opening' },
      { delay: 5000, nextPhase: 'pages' },
      { delay: 7000, nextPhase: 'welcome' },
      { delay: 9500, nextPhase: 'complete' },
    ];

    timeline.forEach(({ delay, nextPhase }) => {
      setTimeout(() => setPhase(nextPhase as any), delay);
    });

    // Progress bar
    const timer = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 1500);
          return 100;
        }
        return p + 0.45;
      });
    }, 35);

    return () => clearInterval(timer);
  }, [onComplete]);

  // Floating particles
  const particles = Array.from({ length: 60 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 4 + 2,
    delay: Math.random() * 2,
    duration: Math.random() * 3 + 2,
  }));

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.2, filter: 'blur(20px)' }}
      transition={{ duration: 1.2, ease: [0.43, 0.13, 0.23, 0.96] }}
      className="fixed inset-0 bg-gradient-to-br from-[#3d0814] via-[#5c1126] to-[#7f1d1d] flex items-center justify-center z-[9999] overflow-hidden"
    >
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <motion.div
          className="w-full h-full"
          style={{
            backgroundImage: `
              radial-gradient(circle at 2px 2px, rgba(251, 191, 36, 0.3) 1px, transparent 0)
            `,
            backgroundSize: '40px 40px',
          }}
          animate={{
            backgroundPosition: ['0px 0px', '40px 40px'],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        />
      </div>

      {/* Floating Golden Particles */}
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute rounded-full"
          style={{
            width: particle.size,
            height: particle.size,
            background: 'radial-gradient(circle, rgba(251, 191, 36, 0.6), transparent)',
            boxShadow: '0 0 8px rgba(251, 191, 36, 0.4)',
          }}
          initial={{ x: `${particle.x}vw`, y: `${particle.y}vh`, opacity: 0 }}
          animate={{
            y: [`${particle.y}vh`, `${particle.y - 50}vh`, `${particle.y}vh`],
            x: [`${particle.x}vw`, `${particle.x + 10}vw`, `${particle.x}vw`],
            opacity: [0, 0.6, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            delay: particle.delay,
            ease: 'easeInOut',
          }}
        />
      ))}

      {/* Main Container */}
      <div className="relative flex flex-col items-center justify-center">
        {/* Ambient Glow */}
        <motion.div
          className="absolute w-[600px] h-[600px] rounded-full"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.3, 0.2],
          }}
          transition={{ duration: 4, repeat: Infinity }}
          style={{
            background: 'radial-gradient(circle, rgba(251, 191, 36, 0.3), transparent 70%)',
            filter: 'blur(60px)',
          }}
        />

        <AnimatePresence mode="wait">
          {/* Phase 1: Walking Character */}
          {phase === 'walking' && (
            <motion.div
              key="walking"
              className="absolute left-0"
              initial={{ x: '-100vw' }}
              animate={{ x: '0vw' }}
              exit={{ opacity: 0 }}
              transition={{ duration: 2.5, ease: [0.43, 0.13, 0.23, 0.96] }}
            >
              {/* Walking Character/Icon */}
              <div className="relative">
                {/* Character Body */}
                <motion.div
                  animate={{
                    y: [0, -10, 0],
                  }}
                  transition={{
                    duration: 0.6,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                  className="relative"
                >
                  {/* Glow Effect */}
                  <div className="absolute inset-0 blur-2xl bg-yellow-500/30 rounded-full scale-150" />
                  
                  {/* Character Circle */}
                  <div className="relative w-32 h-32 rounded-full bg-gradient-to-br from-yellow-400 via-amber-500 to-orange-600 flex items-center justify-center shadow-2xl border-4 border-yellow-200/50">
                    {/* Character Icon - Book with Person */}
                    <svg
                      className="w-16 h-16 text-white"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                    </svg>
                  </div>
                </motion.div>

                {/* Walking Legs Animation */}
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
                  <motion.div
                    className="w-3 h-8 bg-yellow-600 rounded-full"
                    animate={{
                      rotate: [0, 30, 0, -30, 0],
                      y: [0, -5, 0, -3, 0],
                    }}
                    transition={{
                      duration: 0.6,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                  />
                  <motion.div
                    className="w-3 h-8 bg-yellow-600 rounded-full"
                    animate={{
                      rotate: [0, -30, 0, 30, 0],
                      y: [0, -3, 0, -5, 0],
                    }}
                    transition={{
                      duration: 0.6,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                  />
                </div>

                {/* Book in Hand */}
                <motion.div
                  className="absolute -right-16 top-8 w-12 h-16 bg-gradient-to-br from-amber-800 to-red-900 rounded-sm shadow-lg"
                  animate={{
                    rotate: [0, 5, 0, -5, 0],
                    y: [0, -2, 0],
                  }}
                  transition={{
                    duration: 0.6,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                  style={{
                    border: '2px solid rgba(251, 191, 36, 0.3)',
                  }}
                >
                  {/* Book Pages */}
                  <div className="absolute right-0 top-1 bottom-1 w-1 bg-yellow-100" />
                </motion.div>

                {/* Walking Shadow */}
                <motion.div
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-24 h-3 rounded-full bg-black/30 blur-sm"
                  animate={{
                    scaleX: [1, 1.2, 1],
                    opacity: [0.3, 0.5, 0.3],
                  }}
                  transition={{
                    duration: 0.6,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                />
              </div>

              {/* Walking Text */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="absolute -bottom-24 left-1/2 -translate-x-1/2 whitespace-nowrap"
              >
                <p className="text-yellow-200 text-lg font-semibold animate-pulse">
                  Coming with your story...
                </p>
              </motion.div>
            </motion.div>
          )}

          {/* Phase 2: Book Opening */}
          {(phase === 'opening' || phase === 'pages') && (
            <motion.div
              key="opening"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="relative"
              style={{ perspective: '3000px' }}
            >
              <div className="relative w-[600px] h-96 flex">
                {/* Left Page (Fixed) */}
                <motion.div
                  className="w-1/2 h-full bg-gradient-to-br from-amber-50 to-orange-100 shadow-2xl relative rounded-l-lg"
                  style={{
                    transformStyle: 'preserve-3d',
                    transformOrigin: 'right center',
                    backgroundImage: `
                      linear-gradient(90deg, rgba(0,0,0,0.05) 0%, transparent 10%),
                      repeating-linear-gradient(0deg, transparent, transparent 25px, rgba(139, 92, 46, 0.03) 25px, rgba(139, 92, 46, 0.03) 26px)
                    `,
                  }}
                  animate={{
                    boxShadow: [
                      '10px 0 30px rgba(0, 0, 0, 0.3)',
                      '15px 0 40px rgba(0, 0, 0, 0.4)',
                      '10px 0 30px rgba(0, 0, 0, 0.3)',
                    ],
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  {/* Left Page Content */}
                  <div className="p-12 h-full flex flex-col justify-center">
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.8, duration: 0.8 }}
                    >
                      <h3 className="text-4xl font-black text-amber-900 mb-6 font-serif">
                        Welcome To
                      </h3>
                      <p className="text-amber-800 leading-relaxed font-serif italic text-lg">
                        A world where words dance,<br />
                        stories breathe,<br />
                        and imagination knows<br />
                        no bounds...
                      </p>
                      
                      <div className="mt-8 space-y-3">
                        {['Creativity', 'Excellence', 'Passion'].map((word, i) => (
                          <motion.div
                            key={word}
                            initial={{ x: -20, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            transition={{ delay: 1.5 + i * 0.2 }}
                            className="flex items-center gap-3"
                          >
                            <div className="w-3 h-3 bg-yellow-600 rounded-full" />
                            <span className="text-amber-700 font-semibold text-lg">{word}</span>
                          </motion.div>
                        ))}
                      </div>
                    </motion.div>
                  </div>

                  {/* Page Edge Shading */}
                  <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-black/10 to-transparent" />
                  
                  {/* Left Cover Decoration */}
                  <div className="absolute inset-4 border-2 border-yellow-600/20 rounded-lg pointer-events-none" />
                </motion.div>

                {/* Right Page (Opening with Character) */}
                <motion.div
                  className="absolute left-1/2 w-1/2 h-full bg-gradient-to-bl from-amber-50 to-orange-100 shadow-2xl rounded-r-lg"
                  style={{
                    transformStyle: 'preserve-3d',
                    transformOrigin: 'left center',
                    backgroundImage: `
                      linear-gradient(270deg, rgba(0,0,0,0.05) 0%, transparent 10%),
                      repeating-linear-gradient(0deg, transparent, transparent 25px, rgba(139, 92, 46, 0.03) 25px, rgba(139, 92, 46, 0.03) 26px)
                    `,
                  }}
                  initial={{ rotateY: 0 }}
                  animate={{ 
                    rotateY: phase === 'opening' ? -120 : -170,
                  }}
                  transition={{ 
                    duration: 1.5, 
                    ease: [0.43, 0.13, 0.23, 0.96],
                  }}
                >
                  {/* Right Page Content */}
                  <div className="p-12 h-full flex flex-col justify-center">
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: phase === 'pages' ? 1 : 0 }}
                      transition={{ delay: 1, duration: 0.8 }}
                    >
                      <h3 className="text-4xl font-black text-amber-900 mb-6 font-serif">
                        Your Story
                      </h3>
                      <p className="text-amber-800 leading-relaxed font-serif italic text-lg">
                        Every great story<br />
                        begins with a single word.<br />
                        Let us help you write yours...
                      </p>

                      {/* Decorative Quote */}
                      <div className="mt-8 p-4 border-l-4 border-yellow-600">
                        <p className="text-amber-700 text-sm italic">
                          "There is no greater agony than bearing an untold story inside you."
                        </p>
                        <p className="text-amber-600 text-xs mt-2">— Maya Angelou</p>
                      </div>
                    </motion.div>
                  </div>

                  {/* Page Edge Shading */}
                  <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-black/10 to-transparent" />

                  {/* Character on Page */}
                  {phase === 'opening' && (
                    <motion.div
                      className="absolute right-12 bottom-12"
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.5, duration: 0.8 }}
                    >
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-yellow-400 to-orange-600 flex items-center justify-center shadow-lg">
                        <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                        </svg>
                      </div>
                    </motion.div>
                  )}
                </motion.div>

                {/* Animated Turning Pages */}
                {phase === 'pages' && (
                  <>
                    {Array.from({ length: 3 }).map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute left-1/2 w-1/2 h-full bg-gradient-to-bl from-white to-amber-50 rounded-r-lg"
                        style={{
                          transformStyle: 'preserve-3d',
                          transformOrigin: 'left center',
                          zIndex: 10 - i,
                          boxShadow: '0 0 20px rgba(0, 0, 0, 0.2)',
                        }}
                        initial={{ rotateY: 0 }}
                        animate={{
                          rotateY: [-180, 0, -180],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: i * 0.4,
                          ease: [0.43, 0.13, 0.23, 0.96],
                        }}
                      >
                        {/* Page Lines */}
                        <div className="p-8 space-y-3">
                          {Array.from({ length: 12 }).map((_, lineIndex) => (
                            <div
                              key={lineIndex}
                              className="h-0.5 bg-amber-200/50 rounded"
                              style={{ width: `${Math.random() * 30 + 70}%` }}
                            />
                          ))}
                        </div>
                      </motion.div>
                    ))}
                  </>
                )}
              </div>

              {/* Book Cover (When Closed) */}
              <motion.div
                className="absolute inset-0 rounded-lg"
                initial={{ opacity: 1 }}
                animate={{ opacity: 0 }}
                transition={{ duration: 1, delay: 0.5 }}
                style={{
                  background: 'linear-gradient(135deg, #7f1d1d 0%, #991b1b 50%, #450a0a 100%)',
                  boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
                }}
              >
                {/* Book Title on Cover */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <svg className="w-24 h-24 mx-auto mb-4 text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
                    </svg>
                    <h1 className="text-3xl font-black text-yellow-100 font-serif">GHOST WRITING</h1>
                    <h2 className="text-xl font-bold text-yellow-200 font-serif">SQUAD</h2>
                  </div>
                </div>
                
                {/* Cover Border */}
                <div className="absolute inset-4 border-4 border-yellow-600/30 rounded-lg" />
              </motion.div>

              {/* Book Shadow */}
              <motion.div 
                className="absolute -bottom-12 left-1/2 -translate-x-1/2 w-96 h-12 rounded-full"
                style={{
                  background: 'radial-gradient(ellipse, rgba(0, 0, 0, 0.4), transparent)',
                  filter: 'blur(15px)',
                }}
                animate={{
                  scale: [1, 1.1, 1],
                  opacity: [0.4, 0.5, 0.4],
                }}
                transition={{ duration: 3, repeat: Infinity }}
              />
            </motion.div>
          )}

          {/* Phase 3: Most Welcome Message */}
          {phase === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1, ease: [0.43, 0.13, 0.23, 0.96] }}
              className="text-center relative"
            >
              {/* Golden Explosion Background */}
              <motion.div
                className="absolute inset-0"
                initial={{ scale: 0 }}
                animate={{ scale: 2, opacity: 0 }}
                transition={{ duration: 1.5 }}
              >
                <div className="w-96 h-96 rounded-full bg-yellow-400/30 blur-3xl" />
              </motion.div>

              {/* Rotating Golden Rings */}
              {[1, 2, 3].map((ring) => (
                <motion.div
                  key={ring}
                  className="absolute inset-0 flex items-center justify-center"
                  animate={{ rotate: 360 }}
                  transition={{
                    duration: 10 + ring * 2,
                    repeat: Infinity,
                    ease: 'linear',
                  }}
                >
                  <div 
                    className="rounded-full border-2 border-yellow-500/30"
                    style={{
                      width: `${ring * 150}px`,
                      height: `${ring * 150}px`,
                    }}
                  />
                </motion.div>
              ))}

              {/* Main Welcome Text */}
              <div className="relative z-10">
                <motion.div
                  initial={{ y: 50, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3, duration: 0.8 }}
                >
                  <motion.h1 
                    className="text-9xl font-black mb-8"
                    style={{
                      background: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 50%, #d97706 100%)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      textShadow: '0 0 80px rgba(251, 191, 36, 0.5)',
                      fontFamily: 'Georgia, serif',
                      letterSpacing: '0.05em',
                    }}
                    animate={{
                      textShadow: [
                        '0 0 40px rgba(251, 191, 36, 0.3)',
                        '0 0 80px rgba(251, 191, 36, 0.6)',
                        '0 0 40px rgba(251, 191, 36, 0.3)',
                      ],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    MOST
                  </motion.h1>

                  <motion.div
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ delay: 0.8, duration: 0.8 }}
                    className="w-96 h-2 bg-gradient-to-r from-transparent via-yellow-500 to-transparent mx-auto mb-8 rounded-full"
                    style={{
                      boxShadow: '0 0 20px rgba(251, 191, 36, 0.5)',
                    }}
                  />

                  <motion.h2
                    className="text-9xl font-black"
                    style={{
                      background: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 50%, #d97706 100%)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      textShadow: '0 0 80px rgba(251, 191, 36, 0.5)',
                      fontFamily: 'Georgia, serif',
                      letterSpacing: '0.05em',
                    }}
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ 
                      y: 0, 
                      opacity: 1,
                      textShadow: [
                        '0 0 40px rgba(251, 191, 36, 0.3)',
                        '0 0 80px rgba(251, 191, 36, 0.6)',
                        '0 0 40px rgba(251, 191, 36, 0.3)',
                      ],
                    }}
                    transition={{ 
                      y: { delay: 1, duration: 0.8 },
                      opacity: { delay: 1, duration: 0.8 },
                      textShadow: { duration: 2, repeat: Infinity },
                    }}
                  >
                    WELCOME
                  </motion.h2>
                </motion.div>

                {/* Subtitle */}
                <motion.p
                  className="mt-8 text-2xl text-yellow-200 font-serif italic"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.5, duration: 0.8 }}
                >
                  To Your Story's New Beginning
                </motion.p>

                {/* Sparkle Burst */}
                {Array.from({ length: 30 }).map((_, i) => {
                  const angle = (i / 30) * 360;
                  const distance = 200;
                  return (
                    <motion.div
                      key={i}
                      className="absolute w-3 h-3 rounded-full"
                      style={{
                        left: '50%',
                        top: '50%',
                        background: i % 3 === 0 ? '#fbbf24' : i % 3 === 1 ? '#f59e0b' : '#d97706',
                        boxShadow: '0 0 10px rgba(251, 191, 36, 0.8)',
                      }}
                      initial={{ 
                        x: 0, 
                        y: 0, 
                        scale: 0, 
                        opacity: 0 
                      }}
                      animate={{
                        x: Math.cos((angle * Math.PI) / 180) * distance,
                        y: Math.sin((angle * Math.PI) / 180) * distance,
                        scale: [0, 1.5, 0],
                        opacity: [0, 1, 0],
                      }}
                      transition={{
                        duration: 2,
                        delay: 0.5 + i * 0.03,
                        ease: 'easeOut',
                      }}
                    />
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Phase 4: Complete Checkmark */}
          {phase === 'complete' && (
            <motion.div
              key="complete"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="text-center"
            >
              <motion.div
                className="w-40 h-40 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center mx-auto"
                style={{
                  boxShadow: '0 20px 60px rgba(16, 185, 129, 0.5)',
                }}
                animate={{
                  scale: [1, 1.1, 1],
                  boxShadow: [
                    '0 20px 60px rgba(16, 185, 129, 0.5)',
                    '0 25px 80px rgba(16, 185, 129, 0.7)',
                    '0 20px 60px rgba(16, 185, 129, 0.5)',
                  ],
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <svg
                  className="w-20 h-20 text-white"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <motion.path
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={3}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Progress Bar */}
        {phase !== 'complete' && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-32 w-[500px]"
          >
            {/* Percentage */}
            <div className="flex justify-between items-center mb-4">
              <motion.span
                key={Math.floor(progress / 10)}
                initial={{ scale: 1.2, y: -5 }}
                animate={{ scale: 1, y: 0 }}
                className="text-yellow-300 text-3xl font-black font-serif"
                style={{
                  textShadow: '0 0 20px rgba(251, 191, 36, 0.5)',
                }}
              >
                {Math.round(progress)}%
              </motion.span>
              
              <span className="text-yellow-200/80 text-sm font-serif italic">
                {phase === 'walking' && 'Approaching...'}
                {phase === 'opening' && 'Opening the book...'}
                {phase === 'pages' && 'Turning pages...'}
                {phase === 'welcome' && 'Preparing welcome...'}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="relative h-3 bg-red-950/50 rounded-full overflow-hidden backdrop-blur-sm border-2 border-yellow-900/30">
              <motion.div
                className="absolute top-0 left-0 h-full rounded-full"
                initial={{ width: '0%' }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3, ease: 'easeOut' }}
                style={{
                  background: 'linear-gradient(90deg, #fbbf24 0%, #f59e0b 50%, #d97706 100%)',
                  boxShadow: '0 0 20px rgba(251, 191, 36, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                }}
              >
                {/* Shimmer Effect */}
                <motion.div
                  className="absolute inset-0"
                  style={{
                    background: 'linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.5) 50%, transparent 100%)',
                    backgroundSize: '200% 100%',
                  }}
                  animate={{
                    backgroundPosition: ['0% 0%', '200% 0%'],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: 'linear',
                  }}
                />
              </motion.div>

              {/* Progress Dot */}
              <motion.div
                className="absolute top-1/2 -translate-y-1/2 w-6 h-6 rounded-full"
                style={{ 
                  left: `calc(${progress}% - 12px)`,
                  background: 'radial-gradient(circle, #fff 0%, #fbbf24 100%)',
                  boxShadow: '0 0 20px rgba(251, 191, 36, 1)',
                }}
                animate={{
                  scale: [1, 1.3, 1],
                }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                }}
              />
            </div>
          </motion.div>
        )}

        {/* Inspirational Quote */}
        {phase !== 'welcome' && phase !== 'complete' && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.8 }}
            transition={{ delay: 2 }}
            className="mt-16 text-yellow-200/80 text-sm italic max-w-md text-center font-serif"
          >
            {phase === 'walking' && '"A journey of a thousand pages begins with a single word."'}
            {phase === 'opening' && '"Books are the quietest and most constant of friends." - Charles W. Eliot'}
            {phase === 'pages' && '"There is no friend as loyal as a book." - Ernest Hemingway'}
          </motion.p>
        )}
      </div>

      {/* Corner Ornaments */}
      {[
        { top: '2rem', left: '2rem', rotate: 0 },
        { top: '2rem', right: '2rem', rotate: 90 },
        { bottom: '2rem', right: '2rem', rotate: 180 },
        { bottom: '2rem', left: '2rem', rotate: 270 },
      ].map((pos, i) => (
        <motion.div
          key={i}
          className="absolute"
          style={pos}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 0.4, scale: 1 }}
          transition={{ delay: i * 0.1, duration: 0.6 }}
        >
          <svg width="60" height="60" viewBox="0 0 60 60">
            <path
              d="M 10 10 L 50 10 L 50 15 L 15 15 L 15 50 L 10 50 Z"
              fill="#fbbf24"
              opacity="0.3"
              transform={`rotate(${pos.rotate} 30 30)`}
            />
            <circle cx="30" cy="30" r="3" fill="#d97706" />
          </svg>
        </motion.div>
      ))}
    </motion.div>
  );
}